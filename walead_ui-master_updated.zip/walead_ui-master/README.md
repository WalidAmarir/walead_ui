# Project Title
Walead
## Table of Contents
- Dashboard
- Deal
- Post
- Accelerator
- Workspace
## Introduction
Increase your sales and productivity with our standard features
## Prerequisites
List the software and tools that need to be installed before setting up the project.
- Node.js and npm
- Docker
- Git
## Getting Started
### Development
1. Clone the repository:
   ```bash
   git clone https://git.devtrust.biz/gitlab-instance-7e50b380/linkedin_tools_ui.git
   cd your-repo
2. Install dependencies:
    npm install
3. Run the development server:
    npm run dev
4. Run the development server with docker:
    docker compose up