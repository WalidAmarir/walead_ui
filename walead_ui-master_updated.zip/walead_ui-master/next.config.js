/** @type {import('next').NextConfig} */
const nextConfig = {
  compiler: { styledComponents: true },
  swcMinify: true,
  experimental: {
    esmExternals: false,
    serverActions: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**",
      },
    ],
  },
  env: {
    SITE_KEY: process.env.SITE_KEY,
    SECRETKEY: process.env.SECRETKEY,
    API_BASE_URL: process.env.API_BASE_URL,
    CLIENT_ID: process.env.CLIENT_ID,
    GRAPHQL_BASE_URL: process.env.GRAPHQL_BASE_URL,
    AWS_ACCESS_KEY: process.env.AWS_ACCESS_KEY,
    AWS_SECRET_KEY: process.env.AWS_SECRET_KEY,
    AWS_REGION: process.env.AWS_REGION,
    AWS_BUCKET_NAME: process.env.AWS_BUCKET_NAME,
    LINKEDIN_URL: process.env.LINKEDIN_URL,
    EXTENSION_ID: process.env.EXTENSION_ID,
    EXTENSION_URL: process.env.EXTENSION_URL,
    AWS_S3_URL: process.env.AWS_S3_URL,
    CHAT_URL: process.env.AWS_IMAGE_URL,
  },
  future: { webpack5: true },
  webpack: (config) => {
    config.resolve.alias.canvas = false;
    config.resolve.alias.encoding = false;
    return config;
  },
};
module.exports = nextConfig;
