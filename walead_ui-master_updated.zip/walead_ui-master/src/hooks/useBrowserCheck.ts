import { isBrowser } from "@/utils/helperUtils";
import { useState, useEffect } from "react";

export const useBrowserCheck = () => {
  const [isLoaded, setIsLoded] = useState(false);

  useEffect(() => {
    if (isBrowser) {
      setIsLoded(true);
    }
  }, []);

  return isLoaded;
};
