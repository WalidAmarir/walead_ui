import { useState } from "react";
import dayjs from "dayjs";

export interface CalendarTimeErr {
  hours: string | null;
  minutes: string | null;
}

function useIsValidTime() {
  const initialValues = {
    hours: null,
    minutes: null,
  };
  const [calenderTimeErr, setCalenderTimeErr] =
    useState<CalendarTimeErr>(initialValues);
  const handleClearErr = () => {
    setCalenderTimeErr(initialValues);
  };
  let isValid = false;
  function isValidTime(str: string, str1: string, str3: string) {
    const value = Number(str1);
    const isHours = str === "hours";
    const isMinutes = str === "minutes";
    const isCurrentTime = dayjs().get("hour");

    function isNotFutureDate() {
      const now = dayjs();
      const inputDate = dayjs(str3);
      return inputDate.isBefore(now);
    }

    if (isHours && isNaN(value)) {
      setCalenderTimeErr({ ...calenderTimeErr, hours: "Enter valid hour" });
      isValid = true;
      return;
    }
    if (isMinutes && isNaN(value)) {
      setCalenderTimeErr({
        ...calenderTimeErr,
        minutes: "Enter valid minutes",
      });
      isValid = true;
      return;
    }
    if (isHours && isNotFutureDate() && value < isCurrentTime) {
      isValid = true;
      setCalenderTimeErr({
        ...calenderTimeErr,
        hours: "Scheduled time can't be below current time",
      });
    } else if (isHours && (value > 24 || value < 0 || str1.trim() === "")) {
      isValid = true;
      setCalenderTimeErr({ ...calenderTimeErr, hours: "Enter valid hour" });
    } else if (isMinutes && (value > 60 || value < 0 || str1.trim() === "")) {
      isValid = true;
      setCalenderTimeErr({
        ...calenderTimeErr,
        minutes: "Enter valid minutes",
      });
    } else {
      isValid = false;
      setCalenderTimeErr({ ...calenderTimeErr, [str]: "" });
    }
  }

  return { isValidTime, handleClearErr, calenderTimeErr, isValid };
}

export default useIsValidTime;
