import { useState } from "react";

type DialogState = Record<string, boolean>;

interface DialogActions {
  handleCloseDialog: (dialogKey: string) => void;
  handleOpenDialog: (dialogKey: string) => void;
}

const useDialogState = (
  initialState: DialogState = {},
): [DialogState, DialogActions] => {
  const [dialogState, setDialogState] = useState<DialogState>(initialState);

  const handleCloseDialog = (dialogKey: string) => {
    setDialogState((prevState) => ({ ...prevState, [dialogKey]: false }));
  };

  const handleOpenDialog = (dialogKey: string) => {
    setDialogState((prevState) => ({ ...prevState, [dialogKey]: true }));
  };

  const dialogActions: DialogActions = {
    handleCloseDialog,
    handleOpenDialog,
  };

  return [dialogState, dialogActions];
};

export default useDialogState;
