import { useFormik, FormikHelpers } from "formik";

// Define the interface for form values
export interface FormValues {
  [key: string]: any;
}

// Define the type for the onSubmit function
type SubmitHandler = (
  values: FormValues,
  formikHelpers: FormikHelpers<FormValues>,
) => void | Promise<any>;

// Define the return type of the hook
interface FormikFormReturnType {
  values: FormValues;
  errors: any;
  handleChange: (event: React.ChangeEvent<any>) => void;
  resetForm: (nextValues?: FormValues) => void;
  handleSubmit: (event?: React.FormEvent<HTMLFormElement> | undefined) => void;
}

// Define the hook function
const useFormikForm = (
  initialValues: FormValues,
  onSubmit: SubmitHandler,
): FormikFormReturnType => {
  // Use useFormik to manage form state and handlers
  const { values, errors, handleChange, resetForm, handleSubmit } = useFormik({
    initialValues,
    onSubmit,
  });

  // Return the form state and handlers
  return { values, errors, handleChange, resetForm, handleSubmit };
};

export default useFormikForm;
