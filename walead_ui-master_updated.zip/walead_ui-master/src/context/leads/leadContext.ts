"use client";

import React, { useContext } from "react";

export const LeadsContext = React.createContext({} as any);
export const LeadsContextContainer = LeadsContext.Provider;
export const useLeadsContext = () => useContext(LeadsContext);
