import { SAVE_SEARCH_LIST } from "@/lib/graphql/queries/SaveSearchList";
import { getDataFromEdgesKey } from "@/utils/helperUtils";
import { useQuery } from "@apollo/client";
import React, { PropsWithChildren, useState } from "react";
import { LeadsContextContainer } from "./leadContext";

function LeadsContextProvider({ children }: PropsWithChildren) {
  const [allFields, setAllFields] = useState({});
  const { data: savelistdata, refetch: savelistrefetch } = useQuery(
    SAVE_SEARCH_LIST,
    {
      fetchPolicy: "no-cache",
    },
  );
  const filterSaveListData = getDataFromEdgesKey(savelistdata?.SaveSearchList);
  const setAllFieldsValue = (value: React.SetStateAction<{}>) =>
    setAllFields(value);
  const contextValues: any = {
    setAllFieldsValue,
    allFields,
    savelistdata,
    filterSaveListData,
    savelistrefetch,
  };

  return (
    <LeadsContextContainer value={contextValues}>
      {children}
    </LeadsContextContainer>
  );
}

export default LeadsContextProvider;
