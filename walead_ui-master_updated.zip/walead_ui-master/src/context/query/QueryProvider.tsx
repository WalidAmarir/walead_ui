import { UPDATE_DEAL_STATUS } from "@/lib/graphql/mutation/deleteDealStatus";
import { GET_TEAM_MEMEBRS_BY_COMPANY_ID } from "@/lib/graphql/queries/getteamMemberById";
import { BOARD_DATA } from "@/lib/graphql/queries/KanbanBoard";
import { errorToast, successToast } from "@/styles/toaster";
import { useLazyQuery, useMutation, useQuery } from "@apollo/client";
import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from "react";
import { QueryContextContainer } from "./queryContext";
import { DealArray, Subscription } from "@/types/global";
import { GET_DEALS } from "@/lib/graphql/queries/getDeals";
import { ROUTE_NAMES } from "@/shared/routeNames";
import { usePathname } from "next/navigation";
import { BoardObj } from "@/types/user";
import {
  convertArrayToKanbanBoards,
  mapBoardDataToStage,
} from "@/utils/helperUtils";
import { createInitialState, debounce } from "@/utils/optionUtils";

interface ActionProps {
  delete: boolean;
  won: boolean;
  lost: boolean;
  [key: string]: boolean;
}
export interface PipeLineList {
  label: string;
  value: string;
}
export interface DashboardDetails {
  DealsDetail: {
    name: string;
    value: number;
    percentageChange: number;
    determine: string;
  }[];
  MoreInformation: {
    name: string;
    value: number;
  }[];
}

const initial = {
  status: [],
  memberIds: [],
  pipelineId: null,
};
export interface ExtendedWorkOption extends PropsWithChildren {
  icon?: any;
  userDetails?: any;
}
const initialAction = {
  delete: false,
  won: false,
  lost: false,
  other: false,
};
function QueryProvider({ children, userDetails }: ExtendedWorkOption) {
  const { profiledata, profileLoading, profileRefecth, isEmptyDeal } =
    userDetails;
  const [dealStage, setDealStage] = useState<PipeLineList[]>([]);
  const [membersByPipelineId, setMembersByPipelineId] = useState([]);
  const [dealDetailModal, setDealDetailModal] = useState(false);
  const [dealData, setDealData] = useState<any>(null);
  const [dealfilterData, setDealfilterData] = useState(initial);
  const [dealactions, setDealActions] = useState<ActionProps>(initialAction);
  const [isPipelineAction, setIsPipelineAction] = useState(false);
  const [saveSearchData, setSaveSearchData] = useState<DealArray | null>(null);
  const [dealListData, setDealListData] = useState<Record<string, BoardObj>>(
    {},
  );
  const [state, setState] = useState({});
  const [dashboardData, setDashboardData] = useState<
    Record<string, DashboardDetails>
  >({});
  const [dealId, setDealId] = useState("");
  const [loader, setLoader] = useState(false);
  const [DealTime, setDealTime] = useState("Current month");
  const [accountActionType, setAccountActionType] = useState<string>("");
  const [subscriptionDetails, setSubscriptionDetails] =
    useState<Subscription | null>(null);
  const [handlelistData, { data, refetch }] = useLazyQuery(BOARD_DATA, {
    fetchPolicy: "no-cache",
  });
  const pathname = usePathname();
  const handleSubscriptionDetails = (subscriptionData: Subscription) =>
    setSubscriptionDetails(subscriptionData);
  function findItemById(id: string) {
    for (const board of data?.kanbanBoard) {
      for (const deal of board.dealdata) {
        if (deal.id === id) {
          setDealData(deal);
          return deal;
        }
      }
    }
    return null;
  }

  const [getSearchData] = useLazyQuery(GET_DEALS, {
    fetchPolicy: "no-cache",
  });

  const searchData = async (searchDeal: string = "") => {
    const { data: searchresponse } = await getSearchData({
      variables: { search: searchDeal, pipelineId: dealfilterData?.pipelineId },
    });
    if (searchresponse?.getDeals) {
      saveSearchFieldValues(searchresponse?.getDeals?.edges);
    }
  };
  const handleSearchDebounced = debounce(searchData, 300);

  const setListName = (listsObj: Record<string, BoardObj>) => {
    const initialState = createInitialState(listsObj);
    setState(initialState);
  };
  const listData = async () => {
    if (!dealfilterData?.pipelineId) {
      return;
    }
    const { data: boarddata } = await handlelistData({
      variables: dealfilterData,
    });
    if (boarddata) {
      const list = convertArrayToKanbanBoards(boarddata?.kanbanBoard);
      setListName(list);
      const stagebyPipeLine = mapBoardDataToStage(boarddata?.kanbanBoard);
      setDealStage(stagebyPipeLine);
      setDealListData(list);
    }
  };

  const [dealActions] = useMutation(UPDATE_DEAL_STATUS, {
    onCompleted: listData,
  });
  const {
    data: teammembers,
    refetch: membersRefecth,
    loading: teamMemberLoading,
  } = useQuery(GET_TEAM_MEMEBRS_BY_COMPANY_ID, {
    fetchPolicy: "no-cache",
  });

  const handleDealActions = (name: keyof ActionProps, value: boolean) => {
    const updatedActions: any = Object.fromEntries(
      Object.entries(initialAction).map(([key]) => [
        key,
        key === name ? value : false,
      ]),
    );
    setDealActions(updatedActions);
  };

  const dealActionsClose = () => {
    setDealActions(initialAction);
  };

  const onDealActionSubmit = async (statusvalues: any, reset: () => void) => {
    try {
      const { data: dealResponse } = await dealActions({
        variables: { input: statusvalues },
      });
      if (dealResponse) {
        successToast(dealResponse?.updateDealStatus);
        reset();
        dealActionsClose();
      }
    } catch (error: any) {
      errorToast(error?.message);
    }
  };

  const isLoading = profileLoading || teamMemberLoading;

  useEffect(() => {
    setLoader(isLoading);
  }, [profileLoading, teamMemberLoading, isLoading]);

  const handleListData = useCallback(() => {
    if (pathname === ROUTE_NAMES.DEALS) {
      listData();
    } else {
      setDealfilterData(initial);
    }
  }, [pathname, initial, dealfilterData]);

  useEffect(() => {
    handleListData();
  }, [handleListData, dealfilterData]);

  const saveSearchFieldValues = (values: DealArray) =>
    setSaveSearchData(values);
  const handleAccountActionType = (actionType: string) => {
    setAccountActionType(actionType);
  };
  const allStage = Object.keys(dealListData);
  const contextValues = {
    teammembers,
    dealactions,
    profiledata,
    loader,
    dealDetailModal,
    saveSearchData,
    dealId,
    data,
    dealData,
    dealListData,
    dashboardData,
    DealTime,
    accountActionType,
    subscriptionDetails,
    userDetails,
    isEmptyDeal,
    dealfilterData,
    dealStage,
    isPipelineAction,
    membersByPipelineId,
    state,
    setState,
    setListName,
    handleSearchDebounced,
    setDealStage,
    setDealfilterData,
    allStage,
    refetch,
    setMembersByPipelineId,
    findItemById,
    setLoader,
    searchData,
    membersRefecth,
    handleDealActions,
    onDealActionSubmit,
    dealActionsClose,
    listData,
    setDealListData,
    setDealDetailModal,
    setDealTime,
    profileRefecth,
    saveSearchFieldValues,
    setDealId,
    setDashboardData,
    handleAccountActionType,
    setDealData,
    handleSubscriptionDetails,
    setIsPipelineAction,
  };

  return (
    <QueryContextContainer value={contextValues}>
      {children}
    </QueryContextContainer>
  );
}

export default QueryProvider;
