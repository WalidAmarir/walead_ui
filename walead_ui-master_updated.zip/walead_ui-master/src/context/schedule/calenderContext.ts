"use client";

import { ICalender } from "@/types/global";
import React, { useContext } from "react";

export const CalenderContextContext = React.createContext({} as ICalender);
export const CalenderContextContainer = CalenderContextContext.Provider;
export const useCalenderContext = () => useContext(CalenderContextContext);
