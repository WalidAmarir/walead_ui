import useFormikForm from "@/hooks/useFormikForm";
import { GET_POST_BY_TEAM_ID } from "@/lib/graphql/queries/getPostbByTeamId";
import { GET_SCHEDULE_POST } from "@/lib/graphql/queries/getSchdeulePosts";
import { GET_TEAMS } from "@/lib/graphql/queries/getTeams";
import {
  ActionProps,
  IScheduler,
  SchedulePostProp,
  TeamsProp,
} from "@/types/global";
import { calenderName, defaultValueOfMembers } from "@/utils/constant";
import { useLazyQuery, useQuery } from "@apollo/client";
import React, { PropsWithChildren, useMemo, useState } from "react";
import { ScheduledContextContainer } from "./scheduledContext";

interface Event {
  date: string;
}

const initaialFilter = {
  search: "",
  members: "All members",
  data: "All",
};

function ScheduledContextProvider({ children }: PropsWithChildren) {
  const { values, errors, handleChange, resetForm } = useFormikForm(
    initaialFilter,
    () => console.log(""),
  );
  const [fetchPosts, { data, refetch }] = useLazyQuery(GET_SCHEDULE_POST, {
    fetchPolicy: "no-cache",
  });
  const [fetchPostsByTeam, { data: databyteam }] = useLazyQuery(
    GET_POST_BY_TEAM_ID,
    { fetchPolicy: "no-cache" },
  );

  const { data: teamsData, refetch: teamsDataRefetch } = useQuery(GET_TEAMS, {
    fetchPolicy: "network-only",
  });
  const [calenderType, setCalenderType] = useState<string>(calenderName.Weekly);
  const [isMember, setIsMember] = useState<boolean>(false);
  const [isMemberFilter, setIsMemberFilter] = useState<boolean>(false);
  const [editorState, setEditorState] = useState({});
  const [editorErr, setEditorError] = useState({});
  const [isLoader, setIsLoader] = useState(false);
  const [postactionType, setPostactionType] = useState<ActionProps>({
    isPreview: false,
    isComment: false,
  });
  const [onSecheduleOpen, setOnScheduleOpen] = useState(false);
  const [weeklyDates, setWeeklyDates] = useState<Event[]>([]);
  const handleScheduleType = (value: string) => {
    setCalenderType(value);
  };
  const handleSetWeeklyDates = (dates: Event[]) => {
    setWeeklyDates(dates);
  };
  const handleSetOnScheduleOpen = (value: boolean) => {
    setOnScheduleOpen(value);
  };
  const handleScheduleActions = (name: keyof ActionProps, value: boolean) => {
    Object.keys(postactionType).forEach((item) => {
      if (item === name) {
        postactionType[item] = value;
      } else {
        postactionType[item] = false;
      }
    });
    setPostactionType({ ...postactionType });
  };

  const getEditorErr = (name: string, value: string) => {
    const err = value === "<p><br></p>" || value === "";
    setEditorError({
      ...editorErr,
      [name]: err ? "This field cannot be empty" : null,
    });
    return err;
  };

  const searchPosts = (
    value: { search?: string; teamMembers?: string[] },
    isMemberSearch = false,
  ) => {
    setIsMemberFilter(isMemberSearch);
    if (isMemberSearch) {
      fetchPostsByTeam({ variables: { teamId: value?.search } });
    } else {
      fetchPosts({ variables: value });
    }
  };

  const filteredData = useMemo(() => {
    const mapNode = ({ node }: { node: SchedulePostProp }) => ({ ...node });
    let filteredPosts = data?.posts?.edges?.map(mapNode) ?? [];

    if (isMemberFilter && values.members !== "All members") {
      filteredPosts = databyteam?.getPostsByTeam?.edges?.map(mapNode) ?? [];
    }

    if (values.data !== "All") {
      filteredPosts = filteredPosts.filter(
        (item: { status: any }) => item.status === values.data,
      );
    }

    if (values.search) {
      filteredPosts = filteredPosts.filter(
        (item: { createdFor: { fullName: string } }) =>
          item?.createdFor?.fullName
            ?.toLowerCase()
            .includes(values.search.toLowerCase()),
      );
    }

    return filteredPosts;
  }, [data, databyteam, isMemberFilter, values]);

  const filteredTeams = useMemo(() => {
    const { teams } = teamsData ?? {};
    const filterValue = teams?.edges?.map(({ node }: { node: TeamsProp }) => ({
      ...node,
    }));
    return filterValue ?? [];
  }, [teamsData]);

  const filterteamMembers = filteredTeams?.map(
    (item: { teamName: string; id: string }) => ({
      label: `Team: ${item.teamName}`,
      value: item.id,
      name: item.teamName,
    }),
  );
  const teamMembers = [defaultValueOfMembers, ...filterteamMembers];

  const contextValues: IScheduler = {
    calenderType,
    editorState,
    editorErr,
    weeklyDates,
    onSecheduleOpen,
    postactionType,
    teamMembers,
    filteredData,
    values,
    errors,
    handleScheduleActions,
    handleChange,
    resetForm,
    setEditorState,
    handleScheduleType,
    handleSetWeeklyDates,
    setEditorError,
    getEditorErr,
    setIsMember,
    handleSetOnScheduleOpen,
    refetch,
    teamsDataRefetch,
    searchPosts,
    setIsLoader,
    isLoader,
    isMember,
  };

  return (
    <ScheduledContextContainer value={contextValues}>
      {children}
    </ScheduledContextContainer>
  );
}

export default ScheduledContextProvider;
