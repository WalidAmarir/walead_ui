import { ICalender, WeekProp } from "@/types/global";
import {
  getCurrentMonthDates,
  getCurrentWeekDates,
  getPrevMonthDates,
  getNextMonthDates,
  getSelectedMonthDates,
} from "@/utils/helperUtils";
import dayjs from "dayjs";
import moment from "moment";
import React, { PropsWithChildren, useState } from "react";
import { CalenderContextContainer } from "./calenderContext";
moment.updateLocale("en", {
  week: {
    dow: 1,
  },
});

function CalenderContextProvider({ children }: PropsWithChildren) {
  let cWeek = getCurrentWeekDates();
  const allMonths = getCurrentMonthDates();
  const [months, setMonths] = useState(allMonths || []);
  const [dates, setDates] = useState(new Date());
  const [weeks, setWeeks] = useState<WeekProp>({
    from: cWeek.from,
    to: cWeek.to,
  });
  const handlePrevWeekClick = () => {
    const prevWeek = {
      from: new Date(
        weeks.from.getFullYear(),
        weeks.from.getMonth(),
        weeks.from.getDate() - 7,
      ),
      to: new Date(
        weeks.to.getFullYear(),
        weeks.to.getMonth(),
        weeks.to.getDate() - 7,
      ),
    };
    setWeeks(prevWeek);
  };

  const getCurrentWeek = (cweekdate: string | number | Date) => {
    const startDate = moment(cweekdate).startOf("week");
    const endDate = moment(cweekdate).endOf("week");
    let selectedWeek = {
      from: new Date(startDate.format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ (z)")),
      to: new Date(endDate.format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ (z)")),
    };
    setWeeks(selectedWeek);
  };

  const handleNextWeekClick = () => {
    const nextWeekFrom1 = new Date(
      weeks.to.getFullYear(),
      weeks.to.getMonth(),
      weeks.to.getDate() + 1,
    );
    const nextWeekTo2 = new Date(
      nextWeekFrom1.getFullYear(),
      nextWeekFrom1.getMonth(),
      nextWeekFrom1.getDate() + 6,
    );
    setWeeks({ from: nextWeekFrom1, to: nextWeekTo2 });
  };
  const handlePrevMonthClick = () => {
    const prevmonthdate = new Date(months[0]);
    const getmonth = prevmonthdate.getMonth();
    const getyear = prevmonthdate.getFullYear();
    const getPrev = getPrevMonthDates(getyear, getmonth);
    setMonths(getPrev);
  };

  const handleSelectedMonth = (monthvalue: Date) => {
    let selectedMonth = getSelectedMonthDates(monthvalue?.toString());
    setMonths(selectedMonth);
  };
  const handleSelectedDate = (selectedDatevalue: string | Date) => {
    const selectedDate = new Date(selectedDatevalue);
    setDates(selectedDate);
  };

  const handleNextMonthClick = () => {
    const nextmonthdate = new Date(months[0]);
    const getmonth = nextmonthdate.getMonth();
    const getyear = nextmonthdate.getFullYear();
    const getNext = getNextMonthDates(getyear, getmonth);
    setMonths(getNext);
  };
  const handleNextDate = () => {
    const nextDate = new Date(
      dates.getFullYear(),
      dates.getMonth(),
      dates.getDate() + 1,
    );
    setDates(nextDate);
  };
  const handlePrevDate = () => {
    const nextDate = new Date(
      dates.getFullYear(),
      dates.getMonth(),
      dates.getDate() - 1,
    );
    setDates(nextDate);
  };
  const handleCurrentWeek = () => {
    setWeeks({ from: cWeek.from, to: cWeek.to });
  };
  const handleCurrentMonth = () => {
    setMonths(allMonths);
  };
  const handleCurrentDay = () => {
    setDates(new Date());
  };
  const timestamp = months[0];
  const date = dayjs(timestamp);
  const monthName = date.format("MMMM");

  const contextValue: ICalender = {
    weeks,
    months,
    monthName,
    dates,
    handlePrevWeekClick,
    handleNextWeekClick,
    handleCurrentWeek,
    handleNextMonthClick,
    handlePrevMonthClick,
    handleCurrentMonth,
    handlePrevDate,
    handleNextDate,
    handleCurrentDay,
    getCurrentWeek,
    handleSelectedMonth,
    handleSelectedDate,
  };

  return (
    <CalenderContextContainer value={contextValue}>
      {children}
    </CalenderContextContainer>
  );
}

export default CalenderContextProvider;
