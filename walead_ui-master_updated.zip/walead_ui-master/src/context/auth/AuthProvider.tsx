import { useLocalStorage } from "@/hooks/useLocalStorage";
import { PROFILE_DATA } from "@/lib/graphql/queries/profileData";
import { IAuth, LocalStorageKey } from "@/types/global";
import { useLazyQuery } from "@apollo/client";
import { usePathname, useRouter } from "next/navigation";
import React, { PropsWithChildren, useState } from "react";
import { AuthContextContainer } from "./authContext";

interface UseLocalStorageResult {
  item: string | null;
  setItem: (value: string) => void;
  clearStorage: () => void;
}

function AuthProvider({ children }: PropsWithChildren) {
  const { setItem, item, clearStorage }: UseLocalStorageResult =
    useLocalStorage<LocalStorageKey>("AUTH_TOKEN");
  const [isLoggedIn, setIsLoggedIn] = useState<string | null>(item);
  const [handleDealdata, { data, loading, refetch }] = useLazyQuery(
    PROFILE_DATA,
    { fetchPolicy: "no-cache" },
  );
  const pathname = usePathname();
  const router = useRouter();
  const isDashboard = pathname === "/dashboard";
  const authenticateUser = (token: string) => {
    setItem(token);
    setIsLoggedIn(token);
  };

  const logout = () => {
    clearStorage();
    setIsLoggedIn(null);
    router.push("/login");
  };

  const contextValues: IAuth = {
    authenticateUser,
    handleDealdata,
    logout,
    isDashboard,
    data,
    loading,
    refetch,
    isLoggedIn: !!isLoggedIn,
  };

  return (
    <AuthContextContainer value={contextValues}>
      {children}
    </AuthContextContainer>
  );
}

export default AuthProvider;
