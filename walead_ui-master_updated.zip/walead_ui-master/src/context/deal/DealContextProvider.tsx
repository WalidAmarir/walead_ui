import { GET_PIPELINES } from "@/lib/graphql/queries/pipelines";
import {
  getDataFromEdgesKey,
  mapToPipeLineLabelValue,
} from "@/utils/helperUtils";
import { useQuery } from "@apollo/client";
import React, { PropsWithChildren, useEffect, useMemo, useState } from "react";
import { DealContextContainer } from "./dealContext";
import { useQueryContext } from "../query/queryContext";

interface ActionProps {
  isEdit: boolean;
  isAdd: boolean;
  [key: string]: boolean;
}

const initalValueActValue = { isEdit: false, isAdd: false };

function DealContextProvider({ children }: PropsWithChildren) {
  const { setIsPipelineAction, listData } = useQueryContext();
  const [headerActions, setHeaderActions] =
    useState<ActionProps>(initalValueActValue);
  const { data: pipelinesData, refetch: refetchPipeLine } = useQuery(
    GET_PIPELINES,
    { onCompleted: listData, fetchPolicy: "no-cache" },
  );
  const handleheaderActions = (
    name: keyof ActionProps = "",
    value: boolean = false,
  ) => {
    if (!name || !value) {
      setHeaderActions(initalValueActValue);
      return;
    }
    setHeaderActions((prevHeaderActions) => {
      const updatedActions = Object.fromEntries(
        Object.entries(prevHeaderActions).map(
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          ([key, _]) => [key, key === name ? value : false],
        ),
      );
      return updatedActions as ActionProps;
    });
  };

  const isAction = headerActions?.isAdd || headerActions?.isEdit;
  const filteredPipeLines = useMemo(() => {
    return getDataFromEdgesKey(pipelinesData?.pipelines) ?? [];
  }, [pipelinesData]);

  const filteredPipeLinesList = mapToPipeLineLabelValue(filteredPipeLines);
  const isDefaultID = filteredPipeLines?.find(
    (item: { isDefault: boolean }) => item?.isDefault,
  );

  // Extract the stages from the pipeline object and filter out null stages

  useEffect(() => {
    setIsPipelineAction(isAction);
  }, [isAction, setIsPipelineAction]);

  const contextValues = {
    filteredPipeLines,
    filteredPipeLinesList,
    headerActions,
    isAction,
    isDefaultID,
    refetchPipeLine,
    handleheaderActions,
  };
  return (
    <DealContextContainer value={contextValues}>
      {children}
    </DealContextContainer>
  );
}
export default DealContextProvider;
