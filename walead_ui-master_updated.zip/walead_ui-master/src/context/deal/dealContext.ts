"use client";
import React, { useContext } from "react";
export const DealContextContext = React.createContext({} as any);
export const DealContextContainer = DealContextContext.Provider;
export const useDealContext = () => useContext(DealContextContext);
