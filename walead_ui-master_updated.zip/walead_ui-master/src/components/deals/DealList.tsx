import { useQueryContext } from "@/context/query/queryContext";
import { UPDATE_DEAL } from "@/lib/graphql/mutation/updateDeal";
import { useRouter } from "next/navigation";
import {
  gutters,
  guttersPx,
  whiteColor,
  darkblueColor,
} from "@/styles/variables";
import { isBrowser } from "@/utils/helperUtils";
import { useMutation } from "@apollo/client";
import { css } from "@emotion/core";
import styled from "@emotion/styled";
import React, { useEffect, useMemo, useState } from "react";

import { DragDropContext, Droppable, DropResult } from "react-beautiful-dnd";
import ButtonNewDeal from "../ui/button/ButtonNewDeal";
import { SkeletonLoading } from "../ui/loader/SkeletonLoading";
import Modal from "../ui/modal/Modal";
import DealAction, { ActionComponents } from "./DealAction";
import DealDetailByUsers from "./dealdetails/DealDetailByUsers";
import { chekIndex } from "@/shared/UserMenu/SharedUserMenuComponents";
import { BoardObj } from "@/types/user";
import DroppableDealCard from "@/layouts/deals/dragdrop/droppable/DroppableDealCard";
import { AllTeamMember } from "@/types/global";

export const AllSections = styled.div<{
  index: string | number;
  lastIndex: number | string;
  length: number;
  isPipelineAction?: boolean;
  iscurrentItem?: boolean;
}>(
  ({ index, lastIndex, length, isPipelineAction, iscurrentItem }) => css`
    background: #a8d8cc;
    padding: 10px 0;
    position: relative;
    width: calc(${100 / length}% + 25px);
    min-width: ${!isPipelineAction ? "237px" : "240px"};
    cursor: ${!isPipelineAction && !iscurrentItem ? "none" : "pointer"};
    opacity: ${!isPipelineAction && !iscurrentItem ? "0.5" : "1"};
    &:not(:last-child) {
      margin-right: 10x; /* Add some spacing between child elements */
    }
    ${chekIndex(index, lastIndex)};
  `,
);

const Sections = styled.div<{
  height?: string | number;
}>(
  ({ height = "auto" }) => css`
    display: flex;
    flex-wrap: nowrap;
    align-items: strech;
    gap: 15px;
    overflow-x: auto;
    max-width: 100%;
    height: ${height};
  `,
);

const ActionWrapper = styled.div<{
  isAction: boolean;
}>(
  ({ isAction }) => css`
    position: fixed;
    z-index: ${!isAction ? 0 : 10};
    display: flex;
    visibility: ${isAction ? "visible" : "hidden"};
    bottom: 0;
    box-shadow: 0px 0.5px 4px 0px rgba(0, 0, 0, 0.25);
    border-top: 2px solid #000;
    background: ${whiteColor};
    padding: 0 ${gutters.large}px;
    width: calc(100% - 114px);
    gap: ${guttersPx.medium};
    height: 120px;
  `,
);
const ListWrapper = styled.div`
  position: relative;
  width: 100%;
`;

const DealPostButton = styled.div<{
  isAction: boolean;
}>(
  ({ isAction }) => css`
    position: fixed;
    top: 11px;
    right: 165px;
    z-index: ${isAction ? "999" : "0"};
    button {
      background: transparent;
      color: ${darkblueColor};
      border: 1px solid ${darkblueColor};
    }
  `,
);

const DealList = ({
  isPipelineAction,
  membersByPipelineId,
}: {
  isPipelineAction: boolean;
  membersByPipelineId: AllTeamMember[];
}) => {
  const {
    dealListData,
    listData,
    setDealListData,
    handleDealActions,
    dealDetailModal,
    setDealDetailModal,
    setDealId,
    dealId,
    findItemById,
    setListName,
  } = useQueryContext();
  const [handleDealupdate] = useMutation(UPDATE_DEAL, {
    onCompleted: listData,
  });
  const router = useRouter();
  const [isopen, setIsopen] = useState(false);
  const [actiontext, setActionText] = useState<any>(null);
  const [isAction, setIsAction] = useState(false);
  const lastlength = Object.entries(dealListData || {})?.length;
  const onDragEnd = (
    result: DropResult,
    allListdata: { [key: string]: any },
    listFun: {
      (value: React.SetStateAction<Record<string, BoardObj>>): void;
      (arg0: { [x: string]: any }): void;
    },
  ) => {
    if (!result.destination) {
      setIsAction(false);
      return;
    }
    if (result?.type === "column") {
      const updatedItems = swapItems(
        result?.source?.index,
        result?.destination?.index,
        allListdata,
      );
      setListName(updatedItems);
      listFun(updatedItems);
      return;
    }
    if (result.destination.droppableId === "add to post") {
      findItemById(result?.draggableId);
      router.push("/schedulePost");
      return;
    }
    const { source, destination } = result;

    if (destination?.droppableId === "lost") {
      setActionText({ type: "lost", id: result.draggableId });
      handleDealActions(destination?.droppableId, true);
      setIsAction(false);
      return;
    }
    if (destination?.droppableId === "won") {
      handleDealActions(destination?.droppableId, true);
      setActionText({ type: "won", id: result.draggableId });
      setIsAction(false);
      return;
    }
    if (destination?.droppableId === "delete") {
      handleDealActions(destination?.droppableId, true);
      setActionText({ type: "delete", id: result.draggableId });
      setIsAction(false);
      return;
    }
    if (destination?.droppableId === "other") {
      handleDealActions(destination?.droppableId, true);
      setActionText({ type: "other", id: result.draggableId });
      setIsAction(false);
      return;
    }
    const sourceColumn = allListdata?.[source.droppableId];
    const destColumn = allListdata?.[destination.droppableId];
    setIsAction(false);
    if (source.droppableId !== destination.droppableId) {
      handleDealupdate({
        variables: {
          input: {
            stage: destColumn.id,
            id: result.draggableId,
          },
        },
      });
      const sourceItems = [...sourceColumn.item];
      const destItems = [...destColumn.item];
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);
      listFun({
        ...allListdata,
        [source.droppableId]: {
          ...sourceColumn,
          item: sourceItems,
        },
        [destination.droppableId]: {
          ...destColumn,
          item: destItems,
        },
      });
    } else {
      const column = allListdata[source.droppableId];
      const copiedItems = [...column.item];
      const [removed] = copiedItems.splice(source.index, 1);
      copiedItems.splice(destination.index, 0, removed);
      listFun({
        ...allListdata,
        [source.droppableId]: {
          ...column,
          item: copiedItems,
        },
      });
    }
  };
  useEffect(() => {
    if (isBrowser) {
      listData();
      setIsopen(true);
    }
  }, []);

  const handleDragStart = (item: { type: string; source: any }) => {
    if (!item.source) return;
    if (item.type !== "column") {
      setIsAction(true);
    }
  };

  const onProfileOpen = (id: string) => {
    if (isPipelineAction) {
      setDealDetailModal(true);
      setDealId(id);
    }
  };

  const modalComponents = useMemo(() => {
    return (
      <Modal
        open={dealDetailModal}
        maxWidth={false}
        width="1000"
        closeModal={() => {
          setDealDetailModal(false);
        }}
      >
        <DealDetailByUsers
          id={dealId}
          handleProfileModal={setDealDetailModal}
          membersByPipelineId={membersByPipelineId}
        />
      </Modal>
    );
  }, [dealDetailModal, dealId, membersByPipelineId]);

  if (!isopen || !dealListData) {
    const skeletonCount = 5;
    const skeletonItems = Array.from({ length: skeletonCount }, (_, index) => (
      <AllSections
        key={index}
        index={index}
        lastIndex={lastlength - 1}
        length={5}
      >
        <SkeletonLoading />
      </AllSections>
    ));

    return <Sections height="100vh">{skeletonItems}</Sections>;
  }
  return (
    <ListWrapper>
      <DragDropContext
        onDragStart={handleDragStart}
        onDragEnd={(result) => onDragEnd(result, dealListData, setDealListData)}
      >
        <Droppable
          droppableId="all-column"
          type="column"
          direction="horizontal"
        >
          {(provided) => (
            <Sections {...provided.droppableProps} ref={provided.innerRef}>
              {Object.entries(dealListData as BoardObj)?.map(
                ([listId, list], index) => {
                  const { item } = list;
                  const prices: string =
                    Object.entries(dealListData as Record<string, any>)[
                      index
                    ][1]?.price ?? "";
                  return isopen ? (
                    <DroppableDealCard
                      id={list?.id}
                      key={list?.id}
                      isPipelineAction={isPipelineAction}
                      listId={listId}
                      title={listId}
                      item={item}
                      index={index}
                      lastlength={lastlength}
                      prices={prices}
                      onProfileOpen={onProfileOpen}
                    />
                  ) : null;
                },
              )}
            </Sections>
          )}
        </Droppable>
        <ActionWrapper isAction={isAction}>
          <DealAction isopen={isopen} />
        </ActionWrapper>
        <Droppable droppableId="add to post" key="add to post">
          {(provided) => {
            return (
              <DealPostButton
                isAction={isAction}
                {...provided.droppableProps}
                ref={provided.innerRef}
              >
                <ButtonNewDeal>Add to post</ButtonNewDeal>
              </DealPostButton>
            );
          }}
        </Droppable>
      </DragDropContext>
      <ActionComponents type={actiontext?.type} id={actiontext?.id} />
      {modalComponents}
    </ListWrapper>
  );
};

export default DealList;

function swapItems(
  index1: number,
  index2: number,
  obj: { [key: string]: any },
) {
  const entries = Object.entries(obj);
  if (
    index1 < 0 ||
    index1 >= entries.length ||
    index2 < 0 ||
    index2 >= entries.length
  ) {
    return obj;
  }

  const temp = entries[index1];
  entries[index1] = entries[index2];
  entries[index2] = temp;

  return Object.fromEntries(entries);
}
