import HeaderLeftComponent from "@/layouts/deals/dealheader/HeaderLeftComponent";
import HeaderRightComponent from "@/layouts/deals/dealheader/HeaderRightComponent";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import { guttersPx } from "@/styles/variables";
import { AllTeamMember } from "@/types/global";
import styled from "@emotion/styled";
import { SelectChangeEvent } from "@mui/material/Select";
import React from "react";

interface DealListHeaderProp {
  handleChange: (e: SelectChangeEvent<unknown>) => void;
  budgeData: AllTeamMember[];
  values: { [key: string]: any };
  errors: { [key: string]: string };
  isValid: boolean;
  handleSelect: (e: SelectChangeEvent<unknown>) => void;
  isAction: boolean;
  isAdd: boolean;
  isEdit: boolean;
  setFieldValue: (arg: string, arg1: any) => void;
  resetForm: () => void;
  handleheaderActions: (arg?: string, arg1?: boolean) => void;
  handleSubmit: any;
}

// * DealListHeader component represents the header section of the Deal List view.

const DealListHeader = ({
  handleChange,
  budgeData,
  values,
  errors,
  isValid,
  handleSelect,
  handleheaderActions,
  isAction,
  isAdd,
  isEdit,
  setFieldValue,
  resetForm,
  handleSubmit,
}: DealListHeaderProp) => {
  return (
    <Users>
      {/* HeaderRightComponent section */}
      <HeaderRightComponent
        handleChange={handleChange}
        budgeData={budgeData}
        inputvalue={values}
        isAction={isAction}
        isEdit={isEdit}
        setFieldValue={setFieldValue}
        resetForm={resetForm}
        errors={errors}
        isValid={isValid}
      />
      {/* HeaderLeftComponent section */}
      <HeaderLeftComponent
        isValid={isValid}
        handleChange={handleSelect}
        values={values}
        isAction={isAction}
        isAdd={isAdd}
        handleheaderActions={handleheaderActions}
        resetForm={resetForm}
        setFieldValue={setFieldValue}
        handleSubmit={handleSubmit}
      />
    </Users>
  );
};

export default DealListHeader;

// Styled component for the wrapper div

const Users = styled.div`
  ${flexStyle};
  justify-content: space-between;
  padding-bottom: ${guttersPx.medium};
  & div {
    margin: 0;
  }
`;
