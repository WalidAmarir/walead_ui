import { successToast } from "@/styles/toaster";
import { fontFamily, fontSizeBody1, fontWeightBold } from "@/styles/variables";
import styled from "@emotion/styled";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import React, { useState } from "react";

interface StyledToggleButtonProps {
  isSelected: boolean;
  backgroundColor: string;
  textColor: string;
}

interface StatusContentProps {
  onUpdate: (args: {
    variables: { input: { estimate: string; id: string } };
  }) => Promise<any>;
  dealValue: { getDealById?: { estimate?: string } };
  id: string;
}

const DealStatus: React.FC<StatusContentProps> = ({
  onUpdate,
  dealValue,
  id,
}) => {
  const [value, setValue] = useState("pending");

  const handleChange = async (
    _event: React.MouseEvent<HTMLElement>,
    nextView: string,
  ) => {
    const isPending = nextView === null;
    const finalValue = isPending ? "pending" : nextView;
    setValue(finalValue);
    const { data } = await onUpdate({
      variables: { input: { estimate: finalValue, id: id } },
    });
    if (data?.updateDeal) {
      successToast("Estimate updated successfully");
    }
  };

  const isWon = dealValue?.getDealById?.estimate?.toLowerCase() === "won";
  const isLost = dealValue?.getDealById?.estimate?.toLowerCase() === "lost";
  return (
    <ToggleButtonGroup
      value={value}
      exclusive
      onChange={handleChange}
      aria-label="result"
      sx={{ gap: "5px" }}
    >
      <StyledToggleButton
        value="won"
        aria-label="won"
        isSelected={isWon}
        backgroundColor="rgba(103, 214, 75, 0.70)"
        textColor="#21680F"
      >
        Won
      </StyledToggleButton>
      <StyledToggleButton
        value="lost"
        aria-label="lost"
        isSelected={isLost}
        backgroundColor="rgba(214, 75, 75, 0.70)"
        textColor="#8A0C0C"
      >
        Lost
      </StyledToggleButton>
    </ToggleButtonGroup>
  );
};

export default DealStatus;

const StyledToggleButton = styled(ToggleButton)<StyledToggleButtonProps>`
  opacity: ${({ isSelected }) => (isSelected ? 1 : 0.5)} !important;
  background: ${({ backgroundColor }) => backgroundColor} !important;
  color: ${({ isSelected, textColor }) =>
    isSelected ? textColor : "rgba(0, 0, 0, 0.5)"} !important;
  font-size: ${fontSizeBody1} !important;
  font-weight: ${fontWeightBold} !important;
  font-family: ${fontFamily} !important;
  border-radius: 2px !important;
  width: 103px !important;
  max-height: 35px !important;
  display: grid;
  place-content: center;
`;
