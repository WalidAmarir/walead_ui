import { typographyParagraph } from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
} from "@/styles/variables";
import styled from "@emotion/styled";
import { useState } from "react";

const ExpandableHTMLContent = ({
  content,
  length,
}: {
  content: string;
  length: number;
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isLength = content?.length >= length;

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  const renderContent = () => {
    if (!isLength) {
      return <PostContent dangerouslySetInnerHTML={{ __html: content }} />;
    }

    const truncatedContent = content.slice(0, length) + "...";
    return (
      <PostContent
        dangerouslySetInnerHTML={{
          __html: isExpanded ? content : truncatedContent,
        }}
      />
    );
  };

  return (
    <div>
      {renderContent()}
      {isLength && (
        <ToggleBtn onClick={toggleExpand}>
          {isExpanded ? "See Less" : "See More"}
        </ToggleBtn>
      )}
    </div>
  );
};
export default ExpandableHTMLContent;

const ToggleBtn = styled.button`
  display: block;
  margin-left: auto;
  background: transparent;
  border: 0;
  color: ${greyColor};
  cursor: pointer;
`;

const PostContent = styled.p`
  color: ${darkCharcoalColor};
  ${typographyParagraph};
  margin-bottom: ${guttersPx.medium};
  padding: 0px ${guttersPx.medium};
  word-wrap: break-word;
  a {
    text-decoration: underline;
    color: ${darkblueColor};
  }
`;
