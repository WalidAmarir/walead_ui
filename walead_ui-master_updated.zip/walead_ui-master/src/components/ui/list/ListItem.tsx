import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import { typographyCaptionNormal } from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  guttersPx,
  lightGreyColor,
  whiteColor,
} from "@/styles/variables";
import styled from "@emotion/styled";
import React from "react";
import { AvatarInitials } from "../avatar/Avatar";

// Define types for props
type ListItemProps = {
  selected?: boolean;
  onClick?: () => void;
  avatarUrl?: string;
  name: string;
  maxWidth?: string;
};

// Styled components for the ListItem
const ListItemWrapper = styled.div<{ selected: boolean; maxWidth?: string }>`
  ${flexStyle};
  gap: ${guttersPx.small};
  padding: ${guttersPx.smallHalf} ${guttersPx.small};
  background-color: ${(props) =>
    props.selected ? darkblueColor : lightGreyColor};
  color: ${(props) => (props.selected ? whiteColor : darkCharcoalColor)};
  border-radius: 2px;
  cursor: pointer;
  margin-bottom: ${guttersPx.small};
  max-width: ${(props) => (props.maxWidth ? props.maxWidth : "auto")};
`;

const Name = styled.span`
  ${typographyCaptionNormal};
`;

// ListItem component
const ListItem: React.FC<ListItemProps> = ({
  selected = false,
  onClick,
  avatarUrl,
  name,
  maxWidth,
}) => {
  return (
    <ListItemWrapper selected={selected} onClick={onClick} maxWidth={maxWidth}>
      <AvatarInitials
        profilePicture={avatarUrl}
        w="22"
        h="22"
        name={name}
        textSize="8px"
      />
      <Name>{name}</Name>
    </ListItemWrapper>
  );
};

export default ListItem;
