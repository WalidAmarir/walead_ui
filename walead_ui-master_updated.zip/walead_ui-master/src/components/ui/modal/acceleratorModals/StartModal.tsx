import styled from "@emotion/styled";
import React, { useState } from "react";
import Modal from "../Modal";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ComboButtons from "@/components/schedulePost/ComboButtons";
import {
  darkCharcoalColor,
  darkblueColor,
  whiteColor,
  guttersPx,
  greyColor,
  redColor,
} from "@/styles/variables";
import StartModalSkeleton from "../../loader/AcceleratorSkeletors/StartModalSkeleton";
import StarRating from "../../input/StarRating";
import { typographyH4Regular, typographyParagraph } from "@/styles/typography";
import { DownloadIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { checkLinkType, handleDownload } from "@/utils/helperUtils";
import IframeComponent from "../../iframe/IframeComponent";
import { DetailsProps } from "@/app/(dashboard)/accelerator/page";

interface ContainerProp {
  isLast: boolean;
}

const ModalContainer = styled.div<ContainerProp>`
  width: ${(props) => (!props.isLast ? "816px" : "auto")};
  padding: ${guttersPx.medium};
`;

const HR = styled.hr`
  width: 100%;
  height: 0.5px;
  background: ${greyColor};
`;
const Subtext = styled.p`
  color: #333;
  ${typographyParagraph};
  word-wrap: break-word;
  margin: 30px 0;
`;
const StartModal = ({
  open,
  closeHandler,
  onUpdate,
  updateRating,
  setOpen,
  data,
  currentId,
  acceleratorValues,
}: {
  open: boolean;
  closeHandler: () => void;
  onUpdate: (arg: string, arg1: boolean) => void;
  updateRating: (arg: string, arg1: string) => void;
  setOpen: () => void;
  data: any;
  currentId: string;
  acceleratorValues: DetailsProps;
}) => {
  const [step, setStep] = useState(0); // Initialize with the first step

  const nextStep = () => {
    setStep((prevStep) => Math.min(prevStep + 1, data.length));
  };
  const handleUpdate = async () => {
    const response: any = onUpdate(currentId, true);
    if (response) {
      setStep(0);
      setOpen();
    }
  };
  const onClose = () => {
    setStep(0);
    closeHandler();
  };
  const currentStepData = data?.[step];
  const isLastStep = step === data.length;

  const handleSubmit = isLastStep ? handleUpdate : nextStep;
  const linkType = checkLinkType(currentStepData?.link);
  const buttonsConfig = [
    {
      backgroundColor: whiteColor,
      color: redColor,
      outlineColor: redColor,
      outline: true,
      buttonText: "PDF",
      buttonIcon: <DownloadIcon />,
      onclick: () => {
        handleDownload(currentStepData?.link);
      },
      isHide: !linkType.isPdf || isLastStep,
    },
    {
      backgroundColor: whiteColor,
      color: darkCharcoalColor,
      outline: true,
      buttonText: "Skip",
      onclick: handleSubmit,
    },
    {
      backgroundColor: darkblueColor,
      color: whiteColor,
      outline: false,
      buttonText: "Next",
      onclick: handleSubmit,
    },
  ];

  const loading = false;
  const heading = isLastStep ? "Review" : currentStepData?.title;
  const renderContent = () => {
    if (loading) {
      return <StartModalSkeleton />;
    }
    const height = currentStepData?.type === "Video" ? "300px" : "100%";
    return (
      <>
        <HR />
        {currentStepData?.description && (
          <Subtext>{currentStepData?.description}</Subtext>
        )}
        {!isLastStep ? (
          <div style={{ maxHeight: "350px", overflow: "auto" }}>
            <IframeComponent
              url={currentStepData?.link}
              width="100%"
              height={height}
              type={currentStepData?.type}
            />
          </div>
        ) : (
          <RatingComponent
            acceleratorValues={acceleratorValues}
            updateRating={updateRating}
          />
        )}
      </>
    );
  };

  return (
    <Modal
      open={open}
      width="1100"
      closeModal={onClose}
      maxWidth={isLastStep ? "sm" : "xl"}
    >
      <ModalContainer isLast={isLastStep}>
        <ModalHeader
          component={
            <ModalHeading
              headingColor={greyColor}
              heading={`${step + 1}. ${heading}`}
            />
          }
          showClose={true}
          onclose={onClose}
        />
        {renderContent()}
        <ModalFooter
          componentRight={<ComboButtons buttons={buttonsConfig} />}
        />
      </ModalContainer>
    </Modal>
  );
};

export default StartModal;

const RatingComponent = ({
  acceleratorValues,
  updateRating,
}: {
  acceleratorValues: DetailsProps;
  updateRating: (arg: string, arg1: string) => void;
}) => {
  const updateStarRating = (ratingValue: number | string) => {
    updateRating(acceleratorValues?.id, ratingValue?.toString());
  };
  return (
    <RightContentWrapper>
      <RatingDescription>
        If you have found our course helpful, would you mind leaving a review?
        It will help us improve and provide better service. Thank you for your
        collaboration!
      </RatingDescription>
      <StarRating
        onchange={updateStarRating}
        initalValue={Number(acceleratorValues?.avgRating)}
        readonly={false}
        size={65}
      />
    </RightContentWrapper>
  );
};

const RightContentWrapper = styled.div`
  padding: ${guttersPx.extraLarge};
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: ${guttersPx.small};
`;

const RatingDescription = styled.p`
  color: ${darkCharcoalColor};
  padding: ${guttersPx.large};
  text-align: center;
  ${typographyH4Regular};
  word-break: break-word;
`;
