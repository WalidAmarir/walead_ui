import ModalHeader from "@/components/schedulePost/ModalHeader";
import SmallButton from "../../button/SmallButton";
import InputBox from "../../input/InputBox";
import ListItem from "../../list/ListItem";
import Modal from "../Modal";
import {
  Container,
  flexStyle,
  InputWrapperWithBottomBorder,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { typographyH3 } from "@/styles/typography";
import { searchIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import styled from "@emotion/styled";
import React, { useEffect, useState } from "react";
import { AllTeamMember } from "@/types/global";
import { useQueryContext } from "@/context/query/queryContext";

interface AddTeamMemberProps {
  open: boolean;
  onClose: () => void;
  onOpen: () => void;
  listData: AllTeamMember[];
  defaultvalue: string[];
  setFieldValue: (arg: string, arg1: any) => void;
  resetForm: () => void;
}

const AddTeamMember: React.FC<AddTeamMemberProps> = ({
  open,
  onClose,
  onOpen,
  listData,
  defaultvalue,
  setFieldValue,
  resetForm,
}) => {
  const [list, setList] = useState<AllTeamMember[]>(listData);
  const [searchValue, setSearchValue] = useState<string>("");
  const [selectedItems, setSelectedItems] = useState<string[]>(defaultvalue);
  const { profiledata } = useQueryContext();
  useEffect(() => {
    setSelectedItems(defaultvalue ? defaultvalue : []);
  }, [defaultvalue]);

  const handleItemClick = (id: string) => {
    setSelectedItems((prevSelectedItems) => {
      if (
        prevSelectedItems.includes(id) &&
        profiledata?.getUserDetailsById?.id !== id
      ) {
        return prevSelectedItems.filter((item) => item !== id);
      } else {
        return [...prevSelectedItems, id];
      }
    });
  };

  const handleClose = () => {
    setSelectedItems([]);
    onClose();
  };

  const onCancel = () => {
    handleClose();
    resetForm();
  };

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value } = event.target;
    setSearchValue(value);
    setList(() =>
      listData.filter(
        (item) => item?.fullName?.toLowerCase().includes(value.toLowerCase()),
      ),
    );
  };

  const addTeamMember = () => {
    setFieldValue("memberIds", selectedItems);
    handleClose();
  };

  return (
    <Modal
      isTransition
      open={open}
      maxWidth="auto"
      width="1000"
      closeModal={onOpen}
    >
      <Container minWidth="716px" padding="16px">
        <ModalHeader
          component={
            <ModelHeaderComp handleSearch={handleSearch} value={searchValue} />
          }
          showClose
          onclose={onCancel}
        />
        <ListContainer maxHeight="250px">
          {list?.map((item) => (
            <ListItem
              key={item.id}
              selected={selectedItems.includes(item.id)}
              onClick={() => handleItemClick(item.id)}
              avatarUrl={item.profilePicture}
              name={item.fullName}
            />
          ))}
        </ListContainer>
        <ButtonWrapper>
          <SmallButton onClick={addTeamMember}>Add</SmallButton>
        </ButtonWrapper>
      </Container>
    </Modal>
  );
};

export default AddTeamMember;

interface ModelHeaderCompProps {
  handleSearch: (event: React.ChangeEvent<HTMLInputElement>) => void;
  value: string;
}

const ModelHeaderComp: React.FC<ModelHeaderCompProps> = ({
  handleSearch,
  value,
}) => (
  <Wrapper>
    <Heading>Add team member</Heading>
    <InputWrapperWithBottomBorder>
      <InputBox
        onChange={handleSearch}
        noBorder
        Icon={searchIcon}
        type="search"
        placeholder="Search"
        name="membername"
        value={value}
        error=""
        autocomplete=""
      />
    </InputWrapperWithBottomBorder>
  </Wrapper>
);

const Heading = styled.div`
  ${typographyH3}
`;

const Wrapper = styled.div`
  ${flexStyle};
  justify-content: space-between;
  width: 100%;
  min-width: 600px;
`;

const ListContainer = styled.div<{ maxHeight: string }>`
  max-height: ${(props) => props.maxHeight};
  overflow-y: auto;
  max-width: 280px;
`;

const ButtonWrapper = styled.div`
  display: flex;
  justify-content: end;
`;
