import LinkedinImport from "@/layouts/dealimport/linkedinImport/LinkedinImport";
import ManuallyImport from "@/layouts/dealimport/manuall/ManuallyImport";
import { ROUTE_NAMES } from "@/shared/routeNames";
import {
  flexStyle,
  StyledLink,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import {
  typographyCaptionSmall,
  typographyH2,
  typographyParagraph,
} from "@/styles/typography";
import { blackColor, darkblueColor } from "@/styles/variables";
import styled from "@emotion/styled";
import React from "react";
import Modal from "../Modal";

const WelcomeModal = ({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) => {
  return (
    <Modal open={isOpen} width="711px" closeModal={onClose} maxWidth="md">
      <Content>
        <Title>Welcome</Title>
        <SubTitle>Thank you for being part of WaLead</SubTitle>
        <ImportWrapper>
          <LinkedinImport />
          <ManuallyImport />
        </ImportWrapper>
        <BottomContent>
          If you need it, contact us at{" "}
          <StyledLink href={ROUTE_NAMES.WALEAD_LINKEDIN} target="_blank">
            wamarir@insurgente.es
          </StyledLink>
        </BottomContent>
      </Content>
    </Modal>
  );
};

export default WelcomeModal;

const Title = styled.h2(
  [typographyH2],
  `
    color:${darkblueColor};
    text-align:center;
    margin-bottom:7px;
  `,
);
const SubTitle = styled.p(
  [typographyParagraph],
  `
  color:${blackColor};
  text-align:center
  
  `,
);
const Content = styled.div`
  padding: 30px 40px;
`;
const ImportWrapper = styled.div`
  ${flexStyle};
  gap: 70px;
  padding: 60px 30px 30px 30px;
`;
const BottomContent = styled.p(
  [typographyCaptionSmall],
  `
    color:${blackColor};
    text-align:center
  `,
);
