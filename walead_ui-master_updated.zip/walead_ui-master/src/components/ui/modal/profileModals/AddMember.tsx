import ModalHeader from "@/components/schedulePost/ModalHeader";
import ContentContainer from "@/layouts/userprofile/profileactions/ContentContainer";
import {
  ButtonContainer,
  InputContainer,
  InputFlex,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { guttersPx } from "@/styles/variables";
import { memberType } from "@/utils/constant";
import { forgetPasswordSchema } from "@/utils/formUtils/validations/ValidationUtils";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React, { useState } from "react";
import SmallButton from "../../button/SmallButton";
import InputBox from "../../input/InputBox";
import Label from "../../input/Label";
import SelectBox from "../../selectBox/SelectBox";
import Modal from "../Modal";
import { errorToast, successToast } from "@/styles/toaster";
import { useMutation } from "@apollo/client";
import { ADD_A_MEMBER } from "@/lib/graphql/mutation/addMember";
import { Role } from "@/types/global";

const AddMember = ({
  open,
  selectdata = [],
  onClose,
}: {
  open: boolean;
  selectdata: Role[];
  onClose: () => void;
}) => {
  const [loading, setLoading] = useState(false);
  const [onAddmember] = useMutation(ADD_A_MEMBER);
  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleAddMember = async () => {
    setLoading(true);
    try {
      const { data } = await onAddmember({
        variables: {
          input: values,
        },
      });
      if (data?.addMember) {
        successToast(data.addMember);
        handleClose();
      }
    } catch (err: any) {
      errorToast(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const { values, errors, handleChange, handleSubmit, resetForm } = useFormik({
    initialValues: { email: "", role: selectdata[0]?.id },
    validationSchema: forgetPasswordSchema,
    enableReinitialize: true,
    onSubmit: handleAddMember,
  });

  const updatedData = selectdata?.map((item) => {
    const role = memberType.find((desc) => desc.label === item.role);
    const roleDescription = role?.description || "";
    return {
      label: item.role,
      value: item.id,
      description: roleDescription,
    };
  });

  return (
    <div>
      <Modal
        open={open}
        width="1100"
        closeModal={handleClose}
        maxWidth={"xl"}
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <ModalHeader showClose onclose={handleClose} />
        <Container>
          <ContentContainer heading="Members">
            <Form onSubmit={handleSubmit}>
              <InputFlex>
                <InputContainer>
                  <Label labelText="Add New Member" />
                  <InputBox
                    fullborder
                    type={"text"}
                    placeholder={"Enter email address"}
                    name={"email"}
                    value={values?.email}
                    autocomplete={"off"}
                    error={errors?.email}
                    onChange={handleChange}
                  />
                </InputContainer>
                <InputContainer>
                  <Label labelText="Role" />
                  <SelectBox
                    name={"role"}
                    options={updatedData}
                    value={values?.role}
                    onChange={handleChange}
                  />
                </InputContainer>
              </InputFlex>
              <ButtonContainer>
                <SmallButton type="submit" disabled={loading}>
                  {loading ? "Loading..." : "Invite"}
                </SmallButton>
              </ButtonContainer>
            </Form>
          </ContentContainer>
        </Container>
      </Modal>
    </div>
  );
};

export default AddMember;
const Container = styled.div`
  width: 853px;
  padding: 35px;
  margin-bottom: 60px;
`;

const Form = styled.form`
  padding: ${guttersPx.small} 0;
`;
