import React from "react";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import Modal from "../Modal";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import Label from "../../input/Label";
import InputBox from "../../input/InputBox";
import Button from "../../button/Button";
import { guttersPx, whiteColor } from "@/styles/variables";
import { typographyParagraph } from "@/styles/typography";
import { billingAddressSchema } from "@/utils/formUtils/validations/ValidationUtils";
import {
  ButtonContainer,
  InputContainer,
} from "@/shared/UserMenu/SharedUserMenuComponents";

interface EditBillingAddressProps {
  open: boolean;
  onClose: () => void;
  data: Record<string, string>;
}

interface Field {
  name: string;
  label: string;
  placeholder: string;
}

const EditBillingAddress: React.FC<EditBillingAddressProps> = ({
  open,
  onClose,
  data,
}) => {
  const fields: Field[] = [
    {
      name: "companyname",
      label: "Enter Company name",
      placeholder: "Enter Company name",
    },
    { name: "vat", label: "VAT", placeholder: "Enter VAT" },
    { name: "address", label: "Address", placeholder: "Enter Address" },
    { name: "location", label: "Location", placeholder: "Enter Location" },
    {
      name: "postalcode",
      label: "Postal Code",
      placeholder: "Enter Postal Code",
    },
    { name: "province", label: "Province", placeholder: "Enter Province" },
    { name: "country", label: "Country", placeholder: "Enter Country" },
  ];

  const inputFieldsToRender = fields?.slice(3);
  const firstRender = fields?.slice(0, 3);

  const renderField = (field: Field) => {
    const commonProps = {
      fullborder: true,
      type: "text",
      placeholder: field.placeholder,
      name: field.name,
      value: values[field.name],
      error: errors[field.name],
      onChange: handleChange,
      autocomplete: "",
    };

    return (
      <InputContainer key={field.name}>
        <Label labelText={field.label} />
        <InputBox {...commonProps} />
      </InputContainer>
    );
  };

  const { values, errors, handleChange, handleSubmit, resetForm } = useFormik({
    initialValues: data,
    validationSchema: billingAddressSchema,
    enableReinitialize: true,
    onSubmit: () => {
      console.log(values);
    },
  });

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Modal open={open} width="1100" closeModal={handleClose} maxWidth={"xl"}>
      <ModalHeader showClose onclose={handleClose} />
      <Container>
        <Form onSubmit={handleSubmit}>
          <InputContainerWrapper>
            {firstRender?.map(renderField)}
          </InputContainerWrapper>
          <Grid>{inputFieldsToRender?.map(renderField)}</Grid>
          <ButtonContainer>
            <SaveButton type="submit">Save changes</SaveButton>
          </ButtonContainer>
        </Form>
      </Container>
    </Modal>
  );
};

export default EditBillingAddress;

const Container = styled.div`
  width: 853px;
  padding: ${guttersPx.medium};
  padding-top: 0;
`;

const Form = styled.form`
  padding: ${guttersPx.small} 0;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: auto auto;
  column-gap: 40px;
  margin-bottom: ${guttersPx.extraLarge};
`;

const SaveButton = styled(Button)`
  color: ${whiteColor};
  ${typographyParagraph}
`;

const InputContainerWrapper = styled.div``;
