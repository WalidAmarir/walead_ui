import ModalHeader from "@/components/schedulePost/ModalHeader";
import { useQueryContext } from "@/context/query/queryContext";
import { errorToast } from "@/styles/toaster";
import { typographyH3, typographyParagraph } from "@/styles/typography";
import { darkCharcoalColor, guttersPx, whiteColor } from "@/styles/variables";
import { loinAndSignUpVariable } from "@/utils/constant";
import styled from "@emotion/styled";
import axios from "axios";
import Image from "next/image";
import React, { useCallback } from "react";
import { useLinkedIn } from "react-linkedin-login-oauth2";
import Modal from "../Modal";

const { scope, windowObject, somethingWentWrong } = loinAndSignUpVariable;

const CLIENT_ID: string = process.env.CLIENT_ID || "";
const baseUrl: string = process.env.API_BASE_URL || "";

const AddAccounts = ({
  open,
  onClose,
  onOpenConnect,
}: {
  open: boolean;
  onClose: () => void;
  onOpenConnect: (arg: boolean) => void;
}) => {
  const { profiledata, profileRefecth } = useQueryContext();

  const handleLinkedInError = useCallback(() => {
    console.log(somethingWentWrong);
  }, []);

  const { linkedInLogin } = useLinkedIn({
    clientId: CLIENT_ID,
    redirectUri: `${
      typeof window === windowObject && window.location.origin
    }/linkedin`,
    onSuccess: async (code) => {
      try {
        const { data } = await axios.post(`${baseUrl}/linkLinkedinConnection`, {
          code: code,
          userId: profiledata?.getUserDetailsById?.id,
        });
        if (data.success) {
          profileRefecth();
          onOpenConnect(true);
          onClose();
        } else {
          errorToast(somethingWentWrong);
        }
      } catch (error: any) {
        errorToast(error?.message);
      }
    },
    onError: handleLinkedInError,
    scope: scope,
  });

  return (
    <>
      <Modal
        open={open}
        width="900"
        closeModal={onClose}
        maxWidth={"xl"}
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <Container>
          <ModalHeader
            component={<ModelHeader />}
            showClose
            onclose={onClose}
          />
          <ModalContainer>
            <Cards onClick={linkedInLogin}>
              <Image
                src={"/assets/images/profile.png"}
                alt="Profile"
                width={50}
                height={50}
              />
              <Title>Profile</Title>
            </Cards>
            <Cards onClick={linkedInLogin}>
              <Image
                src={"/assets/images/page.png"}
                alt="Page"
                width={50}
                height={50}
              />
              <Title>Page</Title>
            </Cards>
          </ModalContainer>
        </Container>
      </Modal>
    </>
  );
};

export default AddAccounts;

export const ModelHeader = ({
  imgHeight = 45,
  imgWidth = 45,
}: {
  imgHeight?: number;
  imgWidth?: number;
}) => {
  return (
    <LogoWraapper>
      <Image
        src="/assets/icons/LinkedInRd.png"
        alt="logo"
        height={imgHeight}
        width={imgWidth}
      />
      <Heading>LinkedIn</Heading>
    </LogoWraapper>
  );
};

const LogoWraapper = styled.div`
  display: flex;
  gap: ${guttersPx.small};
  align-items: center;
`;
const Heading = styled.h1`
  color: ${darkCharcoalColor};
  ${typographyH3}
`;
const Container = styled.div`
  padding: ${guttersPx.medium};
  min-width: 787px;
  min-height: 360px;
`;
const ModalContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 40px;
  padding: ${guttersPx.large};
`;

const Cards = styled.div`
  border-radius: 5px;
  background: ${whiteColor};
  box-shadow: 0px 1px 4px 0px rgb(0 0 0 / 25%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: ${guttersPx.medium};
  min-width: 167px;
  height: 142px;
  cursor: pointer;
  gap: ${guttersPx.medium};
`;
const Title = styled.h1`
  color: ${darkCharcoalColor};
  ${typographyParagraph}
`;
