import React from "react";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import {
  darkblueColor,
  darkCharcoalColor,
  GreenTeal,
  greyColor,
  guttersPx,
  silverGrayColor,
} from "@/styles/variables";
import Modal from "../Modal";
import styled from "@emotion/styled";
import { ModelHeader } from "./AddAccounts";
import AvatarUI from "../../avatar/Avatar";
import { useQueryContext } from "@/context/query/queryContext";
import { typographyBold, typographyParagraph } from "@/styles/typography";
import SmallButton from "../../button/SmallButton";
import { getBtnState, userData } from "@/utils/helperUtils";
import { css } from "@emotion/react";
const ConnectAccount = ({
  open,
  onClose,
  onConnect,
  connectloading,
}: {
  open: boolean;
  onClose: () => void;
  onConnect: (arg: boolean) => void;
  connectloading: boolean;
}) => {
  const { profiledata } = useQueryContext();
  const { linkedinUserName, profilePicture, isConnectedOnLinkedin } =
    profiledata?.getUserDetailsById || {};
  const avtardata = userData(linkedinUserName);
  const onLinkedinConnect = () => {
    if (isConnectedOnLinkedin) {
      return;
    }
    onConnect(true);
  };
  return (
    <div>
      <Modal
        open={open}
        width="900"
        closeModal={onClose}
        maxWidth={"xl"}
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <Container>
          <ModalHeader
            component={<ModelHeader />}
            showClose
            onclose={onClose}
          />
          <ModalContainer>
            <AccountComponent>
              <AccountWrapper>
                <AvatarUI
                  teammembers={avtardata}
                  image={profilePicture}
                  width="35px"
                  height="35px"
                />
                <UserName>{linkedinUserName}</UserName>
              </AccountWrapper>
              <Connectbtn
                onClick={onLinkedinConnect}
                isconnected={isConnectedOnLinkedin}
                disabled={connectloading}
              >
                {getBtnState(
                  isConnectedOnLinkedin ? "Connected" : "Connect",
                  connectloading,
                )}
              </Connectbtn>
            </AccountComponent>
            <Message>
              If you need to add another LinkedIn account, simply log out of or
              switch your current LinkedIn account first.
            </Message>
            <Savebtn onClick={onClose}>Save</Savebtn>
          </ModalContainer>
        </Container>
      </Modal>
    </div>
  );
};

export default ConnectAccount;

const commonStyle = `
display:flex;
align-items:center;
`;

const AccountComponent = styled.div`
  ${commonStyle};
  justify-content: space-between;
  border-radius: 2px;
  background: ${silverGrayColor};
  padding: ${guttersPx.medium};
`;
const AccountWrapper = styled.div`
  ${commonStyle};
  gap: ${guttersPx.small};
`;

const UserName = styled.h1`
  color: ${darkCharcoalColor};
  ${typographyParagraph}
`;

const Container = styled.div`
  padding: ${guttersPx.medium};
  min-width: 787px;
`;
const ModalContainer = styled.div``;

const Connectbtn = styled.button<{
  isconnected: boolean;
}>(
  ({ isconnected }) => css`
    border: none;
    background-color: transparent;
    color: ${isconnected ? GreenTeal : darkblueColor};
    ${typographyBold};
    cursor: pointer;
  `,
);
const Message = styled.div`
  color: ${greyColor};
  ${typographyParagraph};
  padding: ${guttersPx.extraLarge} ${guttersPx.smallHalf};
`;
const Savebtn = styled(SmallButton)`
  display: block;
  margin-left: auto;
`;
