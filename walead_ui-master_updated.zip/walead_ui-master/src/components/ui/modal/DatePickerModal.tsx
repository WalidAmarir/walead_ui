import React, { useEffect, useState } from "react";
import Modal from "./Modal";
import styled from "@emotion/styled";
import SmallButton from "../button/SmallButton";
import dayjs, { Dayjs } from "dayjs";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateCalendar } from "@mui/x-date-pickers/DateCalendar";

import {
  darkblueColor,
  whiteColor,
  darkCharcoalColor,
  fontSizeBody2,
  borderRadiusBig,
  lightGreyColor,
  blackColor,
  fontFamily,
  guttersPx,
} from "@/styles/variables";
import { Box } from "@mui/material";
import { typographyH3, typographySubtitle1 } from "@/styles/typography";
import {
  CalenderNextICon,
  CalenderPrevICon,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { datePickerStyles } from "@/styles/base";
import { ErrorMessage } from "@/shared/UserMenu/SharedUserMenuComponents";
import { css } from "@emotion/core";
import { getBorderColor } from "../input/InputBox";
import { useFormik } from "formik";
import { validationSchemaForTime } from "@/utils/formUtils/validations/ValidationUtils";
import { handleKeyPress } from "@/utils/helperUtils";
import updateLocale from "dayjs/plugin/updateLocale";

dayjs.extend(updateLocale);
dayjs.updateLocale("en", {
  weekStart: 1,
});

const ModalContainer = styled.div`
  width: 100%;
  padding: ${guttersPx.extraLarge};
`;

const ButtonFlex = styled.div`
  display: flex;
  align-items: center;
  gap: ${guttersPx.medium};
  justify-content: flex-end;
  margin-top: ${guttersPx.large};
`;

const Button = styled(SmallButton)`
  width: 105px;
  height: 36px;
  border-radius: ${guttersPx.smallHalf};
  font-size: ${fontSizeBody2};
`;

type ButtonStyles = {
  background: string;
  text: string;
  border: string;
};

const generateButtonStyles = ({
  background,
  text,
  border,
}: ButtonStyles) => styled(Button)`
  width: 105px;
  height: 36px;
  border-radius: 5px;
  background: ${background};
  color: ${text};
  border: 1px solid ${border};
  box-shadow: none;
  &:hover {
    border: 1px solid ${darkblueColor};
    background: ${whiteColor};
    color: ${darkblueColor};
  }
`;

const ScheduleButton = generateButtonStyles({
  background: darkblueColor,
  text: whiteColor,
  border: darkblueColor,
});

const DraftButton = generateButtonStyles({
  background: whiteColor,
  text: darkCharcoalColor,
  border: darkCharcoalColor,
});

const InputContainer = styled.div`
  border-radius: ${borderRadiusBig};
  background: ${lightGreyColor};
  padding: ${guttersPx.medium};
  text-align: center;
  border-radius: ${guttersPx.smallHalf};
  margin: ${guttersPx.medium} 0;
`;

const InputFlex = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: ${guttersPx.smallHalf};
`;

const StyledInput = styled.input<{
  error: boolean;
}>([
  typographySubtitle1,
  ({ error }) => css`
    width: 54px;
    height: 54px;
    outline: none;
    color: ${blackColor};
    text-align: center;
    font: 400 20px ${fontFamily};
    background: transparent;
    border-radius: ${guttersPx.smallHalf};
    border: 2px solid ${getBorderColor(error, darkblueColor, 1)};
  `,
]);
export interface CalendarTime {
  hours: string;
  minutes: string;
}
const DatePickerModal = ({
  open,
  closeModal,
  setCalenderValue,
  isTime,
  date,
  onSchedule,
  disablePast,
  handleTime,
}: {
  open: boolean;
  closeModal: () => void;
  isTime: boolean;
  setCalenderValue?: (arg1: string) => void;
  handleTime?: (arg: any) => void;
  date?: string;
  onSchedule: (value: string) => void;
  disablePast: boolean;
}) => {
  const [selectedDate, setSelectedDate] = useState(dayjs());
  const days = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

  const handlePrevMonth = () => {
    setSelectedDate((prevDate) => dayjs(prevDate).subtract(1, "month"));
  };
  const handleNextMonth = () => {
    setSelectedDate((prevDate) => dayjs(prevDate).add(1, "month"));
  };

  const handleDateChange = (value: Dayjs | null) => {
    if (dayjs.isDayjs(value)) {
      setSelectedDate(value);
      if (setCalenderValue) {
        const formattedDate = dayjs(value).format(
          "ddd MMM DD YYYY HH:mm:ss [GMT]ZZ",
        );
        setCalenderValue(formattedDate?.toString());
      }
    }
  };
  useEffect(() => {
    if (date) {
      setSelectedDate(dayjs(date));
    }
  }, [date]);

  const handleCancel = () => {
    handleReset();
    closeModal();
    setSelectedDate(dayjs());
  };
  const { values, errors, handleChange, handleSubmit, handleReset }: any =
    useFormik({
      initialValues: { hours: "00", minutes: "00" },
      validationSchema: validationSchemaForTime(selectedDate?.toDate()),
      onSubmit: () => {
        onSchedule("schedulePostDate");
      },
    });

  useEffect(() => {
    if (handleTime) {
      handleTime(values);
    }
  }, [values.hours, values.minutes]);

  const handleFormSubmit = () => {
    onSchedule(selectedDate.toString());
    handleCancel();
  };

  return (
    <>
      <Modal
        open={open}
        width="550px"
        closeModal={closeModal}
        sx={{ p: 0, width: "550px", ...modalStyle }}
        maxWidth={false}
        styles={modalStyle}
      >
        <ModalContainer>
          <DatePickerContainer>
            <CalenderPrevICon onClick={handlePrevMonth} />
            <StyledDate>{dayjs(selectedDate)?.format("MMMM YYYY")}</StyledDate>
            <CalenderNextICon onClick={handleNextMonth} />
          </DatePickerContainer>

          <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale={"de"}>
            <Box sx={datePickerStyles}>
              <DateCalendar
                value={selectedDate}
                views={["day"]}
                dayOfWeekFormatter={(_day, weekday) => {
                  return days[days.indexOf(weekday.format("dd")) % 7];
                }}
                onChange={handleDateChange}
                showDaysOutsideCurrentMonth
                disablePast={disablePast}
              />
            </Box>
          </LocalizationProvider>
          {isTime && (
            <InputContainer>
              <InputFlex>
                <StyledInput
                  name="hours"
                  type="text"
                  onKeyPress={handleKeyPress}
                  onChange={handleChange}
                  error={!!errors?.hours}
                  value={values.hours}
                  maxLength={2}
                  minLength={2}
                />
                :
                <StyledInput
                  name="minutes"
                  type="text"
                  onKeyPress={handleKeyPress}
                  onChange={handleChange}
                  error={!!errors?.minutes}
                  value={values.minutes}
                  maxLength={2}
                  minLength={2}
                />
              </InputFlex>
              {errors?.hours && <ErrorMessage>{errors.hours}</ErrorMessage>}
              {errors?.minutes && <ErrorMessage>{errors.minutes}</ErrorMessage>}
            </InputContainer>
          )}

          <ButtonFlex>
            <DraftButton onClick={handleCancel} type="button">
              Cancel
            </DraftButton>
            <ScheduleButton
              type="button"
              onClick={isTime ? handleSubmit : handleFormSubmit}
            >
              {isTime ? "Schedule" : "Apply"}
            </ScheduleButton>
          </ButtonFlex>
        </ModalContainer>
      </Modal>
    </>
  );
};

export default DatePickerModal;

const DatePickerContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${guttersPx.small};
  svg {
    cursor: pointer;
  }
`;

const StyledDate = styled.div`
  ${typographyH3};
  color: ${darkCharcoalColor};
`;

const modalStyle = {
  borderRadius: guttersPx.extraLarge,
  background: " #FFF",
  boxShadow: "0px 0px 4px 2px rgba(2, 119, 182, 0.50)",
};
