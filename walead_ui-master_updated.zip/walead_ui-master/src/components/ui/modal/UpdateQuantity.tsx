import React, { useState } from "react";
import styled from "@emotion/styled";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import { darkCharcoalColor, greyColor, guttersPx } from "@/styles/variables";

import {
  typographySubtitle2,
  typographySubtitle2Normal,
} from "@/styles/typography";
import Modal from "./Modal";
import QuantitySelector from "../selectBox/QuantitySelector";
import Button from "../button/Button";
import Image from "next/image";
import { getBtnState } from "@/utils/helperUtils";
const ModalContainer = styled.div`
  padding-top: ${guttersPx.medium};
  width: 452px;
`;

const UpdateQuantity = ({
  open,
  loading,
  dafaultqty = "1",
  onclose,
  onSubmit,
}: {
  open: boolean;
  loading: boolean;
  dafaultqty?: string;
  onclose: () => void;
  onSubmit: (arg: number | string) => void;
}) => {
  const [quantity, setQuantity] = useState(Number(dafaultqty));

  const handleQuantityChange = (newQuantity: React.SetStateAction<number>) => {
    setQuantity(newQuantity);
  };
  const isDisabled = quantity <= 0 || loading;

  return (
    <>
      <Modal
        open={open}
        width="711px"
        closeModal={onclose}
        maxWidth="lg"
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <ModalContainer>
          <ModalHeader
            component={<ModalHeaderComponent />}
            showClose={true}
            onclose={onclose}
          />
          <PaymentContainer>
            <QuantitySelector
              value={quantity}
              onChange={handleQuantityChange}
            />
            <UpdatePlan
              disabled={isDisabled}
              onClick={() => {
                onSubmit(quantity);
              }}
            >
              {getBtnState("Update", loading)}
            </UpdatePlan>
          </PaymentContainer>
        </ModalContainer>
      </Modal>
    </>
  );
};

export default UpdateQuantity;

const ModalHeaderComponent = () => {
  return (
    <Wrapper>
      <StyledLogo
        src="/assets/images/Logo.png"
        width="80"
        height="100"
        alt="logo"
      />
      <ContentWrapper>
        <Heading>Update quantity</Heading>
        <PlanType>Standard</PlanType>
      </ContentWrapper>
    </Wrapper>
  );
};

const PaymentContainer = styled.div`
  padding: ${guttersPx.extraLarge} 0;
`;

const UpdatePlan = styled(Button)`
  ${typographySubtitle2};
  width: 100%;
  margin-top: ${guttersPx.extraLarge};
`;
const Wrapper = styled.div`
  display: flex;
  align-items: center;
  gap: ${guttersPx.mediumHalf};
`;

const ContentWrapper = styled.div``;

const Heading = styled.h1`
  ${typographySubtitle2};
  color: ${darkCharcoalColor};
`;

const PlanType = styled.h3`
  ${typographySubtitle2Normal};
  color: ${greyColor};
`;

const StyledLogo = styled(Image)`
  width: auto;
  height: auto;
`;
