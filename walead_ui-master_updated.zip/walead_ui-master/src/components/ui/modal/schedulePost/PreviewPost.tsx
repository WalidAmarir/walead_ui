import React from "react";
import Modal from "../Modal";
import styled from "@emotion/styled";
import { Earth, CautionSVG } from "@/utils/formUtils/InputSvg/InputSvg";
import {
  darkCharcoalColor,
  borderRadiusLarger,
  greyColor,
  buttonCursor,
  fullWidth,
  fontSizeCaptionSmall,
  guttersPx,
} from "@/styles/variables";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import { typographyH3, typographyParagraph } from "@/styles/typography";
import CustomTooltip from "../../tooltip/CustomTooltip";
import ExpandableHTMLContent from "../../HtmlRenderer/ExpandableHTMLContent";
import { AvatarInitials } from "../../avatar/Avatar";
import { ImageList } from "../../image/ImageList";
const baseTextStyles = `
  color: ${darkCharcoalColor};
  ${typographyParagraph}
`;
const ModalContainer = styled.div`
  padding: 50px;
  div > svg:nth-child(1) {
    margin-left: 50px !important;
  }
`;
const Card = styled.div`
  min-width: 700px;
  width: ${fullWidth};
  border-radius: ${borderRadiusLarger};
  border: 1px solid ${greyColor};
  position: relative;
  padding: ${guttersPx.medium} ${guttersPx.medium} ${guttersPx.mediumHalf}
    ${guttersPx.medium};
`;
const User = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  gap: 10px;
  .MuiAvatar-root {
    background: transparent;
  }
`;

const UserInfo = styled.div`
  display: flex;
  flex-direction: column;
`;
const UserName = styled.h3`
  ${baseTextStyles}
`;

const Span = styled.span`
  ${baseTextStyles}
  color: ${greyColor};
  font-size: ${fontSizeCaptionSmall};
`;
const NowIconContainer = styled.div`
  display: flex;
  align-items: center;
`;
const SpanSVG = styled.span`
  margin-left: 6px;
`;
const SubFlexContainer = styled.div`
  display: flex;
  width: ${fullWidth};
  justify-content: space-between;
  align-items: baseline;
`;
const DotsContainer = styled.div`
  cursor: ${buttonCursor};
  margin-top: -${guttersPx.mediumHalf};
  ${typographyH3}
`;
const CautionContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: end;
  position: absolute;
  bottom: -80px;
  right: -51px;
`;

const PreviewPost = ({
  open,
  data,
  closeHandler,
}: {
  open: boolean;
  data: any;
  closeHandler: () => void;
}) => {
  const { img, profile, values } = data;
  const MAX_CHAR_LIMIT = 200;

  const filterProfile = profile?.find(
    (item: { id: string }) =>
      item.id ===
      (Array.isArray(values.teamMembers)
        ? values.teamMembers[0]
        : values.teamMembers),
  );

  return (
    <>
      <Modal
        open={open}
        styles={{ borderRadius: "10px" }}
        width="1000"
        closeModal={closeHandler}
        maxWidth="lg"
      >
        <ModalContainer>
          <ModalHeader
            component={<ModalHeading heading={"Preview post"} />}
            showClose
            onclose={closeHandler}
          />
          <Card>
            <User>
              <AvatarInitials
                w={"48px"}
                h={"47px"}
                name={filterProfile?.fullName}
                profilePicture={filterProfile?.profilePicture}
                textSize={"12px"}
              />
              <SubFlexContainer>
                <UserInfo>
                  <UserName>{filterProfile?.fullName}</UserName>
                  <NowIconContainer>
                    <Span>Now</Span>
                    <SpanSVG>
                      <Earth />
                    </SpanSVG>
                  </NowIconContainer>
                </UserInfo>
                <DotsContainer>...</DotsContainer>
              </SubFlexContainer>
            </User>
            <ExpandableHTMLContent
              content={values?.content}
              length={MAX_CHAR_LIMIT}
            />
            <ImageList images={img} />
            <CautionContainer>
              <CustomTooltip
                title="The published post may look slightly different"
                placement="bottom"
              >
                <CautionSVG />
              </CustomTooltip>
            </CautionContainer>
          </Card>
        </ModalContainer>
      </Modal>
    </>
  );
};
export default React.memo(PreviewPost);
