import React, { ReactNode } from "react";
import styled from "@emotion/styled";
import { darkCharcoalColor, guttersPx } from "@/styles/variables";
import { css } from "@emotion/core";
import { typographyParagraph } from "@/styles/typography";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ComboButtons from "@/components/schedulePost/ComboButtons";
import Modal from "../Modal";
import { borderStyle } from "@/styles/base";
import { ButtonConfigProp } from "@/types/global";

const ModalContainer = styled.div`
  width: 787px;
  padding: ${guttersPx.medium};
`;

const SubHeading = styled.p([
  typographyParagraph,
  css`
    color: ${darkCharcoalColor};
    margin: 30px 0px;
  `,
]);

const Name = styled.span`
  font-size: 18px;
  font-weight: 700;
`;

const AlertPoPup = ({
  heading = "Delete post",
  subheading = "Are you sure you want to delete this post?",
  name,
  open,
  onclose,
  ButtonConfig,
  component,
}: {
  heading: string;
  subheading?: string;
  name?: string;
  open: boolean;
  onclose: () => void;
  ButtonConfig: ButtonConfigProp[];
  component?: ReactNode;
}) => {
  return (
    <>
      <Modal
        open={open}
        width="900"
        closeModal={onclose}
        maxWidth="lg"
        styles={borderStyle}
      >
        <ModalContainer>
          <ModalHeader
            component={<ModalHeading heading={heading} />}
            showClose={false}
          />
          <SubHeading>
            {subheading} {name && <Name>{name}?</Name>}
          </SubHeading>
          {component ? component : null}
          <ModalFooter
            componentRight={<ComboButtons buttons={ButtonConfig} />}
          />
        </ModalContainer>
      </Modal>
    </>
  );
};

export default AlertPoPup;
