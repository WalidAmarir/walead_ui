"use client";
import React, { useState } from "react";
import { useQueryContext } from "@/context/query/queryContext";
import styled from "@emotion/styled";
import Modal from "../Modal";
import ScheduleInputContainer from "@/layouts/schedulePostLayouts/ScheduleInputContainer";
import { guttersPx } from "@/styles/variables";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import { GroupBadge } from "../../avatar/Avatar";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import {
  DraftButton,
  ScheduleButton,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { FooterComponent } from "@/components/schedulePost/CommonComponent";
import PreviewPost from "./PreviewPost";
import CommentPost from "./CommentPost";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { WaleadLogo } from "@/layouts/schedulePostLayouts/shared/SharedComponent";
import { useFormik } from "formik";
import { s3UploadMethod } from "@/utils/awsFileUploder";
import DatePickerModal from "../DatePickerModal";
import {
  editorSchema,
  InitialEmpty,
} from "@/utils/formUtils/validations/ValidationUtils";
import { CalenderValueProps } from "@/types/global";
import {
  filterImgWithoutUpdate,
  formatGMTDate,
  getBtnState,
  getFinalValue,
  getSchedulePostStatus,
  isCurrentDate,
  parseQuillContent,
} from "@/utils/helperUtils";
import { errorToast } from "@/styles/toaster";

export const ModalContainer = styled.div`
  width: 100%;
  min-width: 790px;
  padding: ${guttersPx.large};
`;

export const FlexContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const StyledBudge = styled.div`
  div {
    margin: 0 !important;
  }
  margin-bottom: 10px !important;
`;

const SchedulePost = ({
  data,
  deafultvalues,
  open,
  edit = false,
  onClose,
  onOpen,
  handleCalenderOpen,
  onCalenderClose,
  onSubmit,
  loading = false,
  calenderOpen = false,
}: {
  data?: string;
  deafultvalues?: any;
  open: boolean;
  edit: boolean;
  onOpen: () => void;
  onClose: () => void;
  calenderOpen?: boolean;
  loading?: boolean;
  onSubmit: (arg1: any, arg2: () => void) => void;
  handleCalenderOpen?: () => void;
  onCalenderClose?: () => void;
}) => {
  const calenderTimeinitialValues = { hours: "00", minutes: "00" };
  const { teammembers, profiledata } = useQueryContext();
  const { postactionType, handleScheduleActions, setIsLoader } =
    useScheduledContext();

  const getDateValue = deafultvalues?.displayDate;
  const formattedDate = formatGMTDate(getDateValue) || new Date();
  const draftDate = formatGMTDate(data || "");
  const [calenderValue, setCalenderValue] = useState<CalenderValueProps>({
    date: formattedDate?.toString(),
    time: calenderTimeinitialValues,
  });
  const handleTime = (value: React.SetStateAction<CalenderValueProps>) => {
    setCalenderValue({ ...calenderValue, ["time"]: value });
  };
  const handleDate = (dateVal: any) => {
    calenderValue.date = dateVal;
    setCalenderValue({ ...calenderValue });
  };

  const {
    values,
    handleChange,
    setFieldValue,
    resetForm,
    errors,
    setFieldError,
    isValid,
  }: any = useFormik({
    initialValues: {
      teamMembers: deafultvalues?.teamMembers || [
        profiledata?.getUserDetailsById?.id,
      ],
      img: deafultvalues?.img || [],
      content: deafultvalues?.dbContent || "",
    },
    validationSchema: editorSchema("content"),
    enableReinitialize: true,
    onSubmit: () => {
      console.log("test");
    },
  });
  const [commentValues, setCommentValues] = useState<any>({});
  const onSchedulePost = async (value: string) => {
    InitialEmpty("content", setFieldError, values.content);
    let commentImg: unknown = [];
    let location: unknown = [];
    const parseContent = parseQuillContent(values?.content)?.trim();
    if (parseContent === "" || !parseContent) {
      return errorToast("Content required");
    }
    if (isValid) {
      setIsLoader(true);
      if (!edit) {
        const folderName = `leadImage/${profiledata?.getUserDetailsById?.email}`;
        location = await s3UploadMethod(values.img, folderName);
        if (commentValues.commentImg) {
          commentImg = await s3UploadMethod(
            commentValues.commentImg,
            folderName,
          );
        }
      }
      let finalValues = {
        ...values,
        ...commentValues,
        teamMembers: Array.isArray(values?.teamMembers)
          ? values.teamMembers
          : [values?.teamMembers],
        content: parseQuillContent(values?.content),
        dbContent: values?.content,
        dbCommentContent: commentValues?.commentContent,
        img: location,
        commentContent: parseQuillContent(commentValues?.commentContent),
        commentImg: commentImg,
        [value]: value === "draftPosttDate" ? draftDate : calenderValue.date,
        schedulePostTime: `${calenderValue?.time.hours}:${calenderValue?.time.minutes}`,
        status: getSchedulePostStatus(value),
      };
      const filterData = getFinalValue(value, finalValues);
      onSubmit(filterData, resetForm);
    }
  };
  const actionBtn = [
    {
      button: (
        <DraftButton onClick={onClose} type="button" isHide={edit}>
          Cancel
        </DraftButton>
      ),
    },
    {
      button: (
        <DraftButton
          onClick={() => {
            onSchedulePost("draftPosttDate");
          }}
          type="button"
          isHide={!edit}
        >
          {getBtnState("Draft", loading)}
        </DraftButton>
      ),
    },
    {
      button: (
        <ScheduleButton
          isHide={!edit}
          onClick={handleCalenderOpen}
          type="button"
        >
          {getBtnState("Schedule", loading)}
        </ScheduleButton>
      ),
    },
    {
      button: (
        <ScheduleButton
          onClick={() => {
            onSchedulePost("Posted");
          }}
          type="button"
          isHide={isCurrentDate(data || deafultvalues.displayDate) && !edit}
        >
          {getBtnState("Publish", loading)}
        </ScheduleButton>
      ),
    },
    {
      button: (
        <ScheduleButton
          onClick={() => {
            onSchedulePost("Posted");
          }}
          type="button"
          isHide={edit}
        >
          {getBtnState("Save", loading)}
        </ScheduleButton>
      ),
    },
  ];

  const previewData = {
    img: filterImgWithoutUpdate(deafultvalues?.img, values.img),
    values: values,
    profile: teammembers?.getTeamMembersByCompanyId,
  };
  const handleOnclose = () => {
    resetForm();
    onClose();
  };

  return (
    <>
      <Modal
        styles={{ borderRadius: "10px" }}
        open={open}
        width="1000"
        closeModal={onOpen}
        maxWidth={false}
      >
        <ModalContainer>
          <ModalHeader
            component={
              <StyledBudge>
                <GroupBadge
                  handleCheked={handleChange}
                  name="teamMembers"
                  error={""}
                  selectable
                  defaultValues={values?.teamMembers}
                  data={teammembers?.getTeamMembersByCompanyId}
                  dimension="43"
                  imgDimension={43}
                  isSingleSelect
                />
              </StyledBudge>
            }
            showClose={true}
            onclose={handleOnclose}
          />
          <ScheduleInputContainer
            placeholderTextArea="Write something..."
            postaction
            setValues={setFieldValue}
            name="content"
            imgName={"img"}
            values={values}
            errors={errors}
            isEdit={edit}
          />
          <ModalFooter
            componentRight={<FooterComponent data={actionBtn} />}
            componentLeft={<WaleadLogo />}
          />
        </ModalContainer>
      </Modal>
      <PreviewPost
        data={previewData}
        open={postactionType?.isPreview}
        closeHandler={() => {
          handleScheduleActions("isPreview", false);
        }}
      />

      <CommentPost
        open={postactionType?.isComment}
        closeHandler={() => {
          handleScheduleActions("isComment", false);
        }}
        onsubmit={setCommentValues}
      />
      <DatePickerModal
        onSchedule={onSchedulePost}
        handleTime={handleTime}
        setCalenderValue={handleDate}
        isTime
        date={getDateValue}
        open={calenderOpen}
        closeModal={onCalenderClose!}
        disablePast
      />
    </>
  );
};

export default SchedulePost;
