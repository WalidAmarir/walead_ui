import React from "react";
import Modal from "../Modal";
import styled from "@emotion/styled";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import {
  DraftButton,
  ScheduleButton,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import { FooterComponent } from "@/components/schedulePost/CommonComponent";
import ScheduleInputContainer from "@/layouts/schedulePostLayouts/ScheduleInputContainer";
import { typographyParagraph } from "@/styles/typography";
import { greyColor, guttersPx } from "@/styles/variables";
import InputBox from "../../input/InputBox";
import SelectBox from "../../selectBox/SelectBox";
import { useFormik } from "formik";
import { ModalContainer } from "./SchedulePost";
import { editorSchema } from "@/utils/formUtils/validations/ValidationUtils";
import { handleKeyPress } from "@/utils/helperUtils";

const ContentContainer = styled.div`
  width: 100%;
`;

const HeaderActionContainer = styled.div`
  display: flex;
  gap: ${guttersPx.medium};
  align-items: center;
`;

const PostCommentHeader = styled.h1`
  ${typographyParagraph};
  color: ${greyColor};
`;
const InputWrapper = styled.div`
  max-width: 100px;
  margin-top: 10px;
  input {
    text-align: center;
    padding-left: 0 !important;
  }
`;

const CommentPost = ({
  open,
  closeHandler,
  onsubmit,
}: {
  open: boolean;
  closeHandler: () => void;
  onsubmit: (arg: any) => void;
}) => {
  const {
    values,
    handleChange,
    errors,
    setFieldValue,
    handleSubmit,
    resetForm,
  } = useFormik({
    initialValues: {
      numbers: "0",
      time: "Minutes",
      commentContent: "",
      commentImg: [],
    },
    validationSchema: editorSchema("commentContent"),
    onSubmit: () => {
      onsubmit({
        commentContent: values.commentContent,
        commentDateTime: values.numbers + "-" + values.time,
        commentImg: values.commentImg,
      });
      resetForm();
      closeHandler();
    },
  });
  const actionBtn = [
    {
      button: (
        <DraftButton type="button" onClick={closeHandler}>
          Cancel
        </DraftButton>
      ),
    },
    {
      button: <ScheduleButton type="submit">Save</ScheduleButton>,
    },
  ];

  return (
    <>
      <Modal
        open={open}
        styles={{ borderRadius: "10px" }}
        width="1000"
        closeModal={closeHandler}
        maxWidth={false}
      >
        <ModalContainer>
          <ModalHeader
            component={<ModalHeading heading={"Comments"} />}
            showClose
            onclose={closeHandler}
          />
          <form onSubmit={handleSubmit}>
            <ContentContainer>
              <HeaderActionContainer>
                <PostCommentHeader>Post comment after:</PostCommentHeader>
                <InputWrapper>
                  <InputBox
                    onChange={handleChange}
                    onKeyPress={handleKeyPress}
                    type={"text"}
                    placeholder="00"
                    name="numbers"
                    value={values.numbers}
                    autocomplete={"off"}
                    error={errors.numbers}
                    maxLength={2}
                    min={1}
                  />
                </InputWrapper>
                <SelectBox
                  width="auto"
                  name="time"
                  options={options}
                  value={values.time}
                  onChange={handleChange}
                />
              </HeaderActionContainer>
              <ScheduleInputContainer
                placeholderTextArea={"Write a comment..."}
                name="commentContent"
                imgName="commentImg"
                setValues={setFieldValue}
                values={values}
                errors={errors}
              />
            </ContentContainer>
            <ModalFooter
              componentRight={<FooterComponent data={actionBtn} />}
            />
          </form>
        </ModalContainer>
      </Modal>
    </>
  );
};

export default CommentPost;

const options = [
  { value: "Minutes", label: "Minutes" },
  { value: "Hours", label: "Hours" },
  { value: "Days", label: "Days" },
];
