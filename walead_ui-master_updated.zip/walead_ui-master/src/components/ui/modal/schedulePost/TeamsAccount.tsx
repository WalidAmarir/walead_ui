import React from "react";
import Modal from "../Modal";
import styled from "@emotion/styled";
import {
  darkCharcoalColor,
  darkblueColor,
  whiteColor,
  guttersPx,
} from "@/styles/variables";
import InputCrud from "../../input/InputCrud";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ComboButtons from "@/components/schedulePost/ComboButtons";
import { borderStyle } from "@/styles/base";
import SelectBox from "../../selectBox/SelectBox";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { selectBoxstyle } from "@/layouts/schedulePostLayouts/CalenderHeader";
import { useFormik } from "formik";
import { DELETE_TEAM_BY_ID } from "@/lib/graphql/queries/deleteTeamById";
import { useLazyQuery, useMutation } from "@apollo/client";
import { errorToast, successToast } from "@/styles/toaster";
import { UPDATE_TEAM } from "@/lib/graphql/mutation/updateTeam";
import { teamValidation } from "@/utils/formUtils/validations/ValidationUtils";

const ModalContainer = styled.div`
  width: 647px;
  padding: ${guttersPx.medium};
`;

const TeamsAccount = ({
  open,
  onclose,
}: {
  open: boolean;
  onclose: () => void;
}) => {
  const { teamMembers, teamsDataRefetch } = useScheduledContext();

  const { values, errors, handleChange, resetForm, setFieldValue } = useFormik({
    initialValues: { members: "All members", teamName: "" },
    validationSchema: teamValidation,
    onSubmit: () => {
      console.log("");
    },
  });

  const [onnDeleteTeam] = useLazyQuery(DELETE_TEAM_BY_ID, {
    onCompleted: () => {
      teamsDataRefetch();
      resetForm();
      successToast("Team deleted successfully");
    },
    onError: (err) => {
      errorToast(err.message);
    },
  });
  const [onTeamUpdate] = useMutation(UPDATE_TEAM, {
    onCompleted: () => {
      teamsDataRefetch();
      resetForm();
      successToast("Team name successfully updated");
    },
    onError: (err) => {
      errorToast(err.message);
    },
  });
  const handleSelect = (event: { target: { value: string } }) => {
    const { value } = event.target;
    handleChange(event);
    const selectname = teamMembers?.find((item) => item.value === value);
    setFieldValue("teamName", selectname?.name);
  };

  const buttonsConfig = [
    {
      backgroundColor: whiteColor,
      color: darkCharcoalColor,
      outline: true,
      buttonText: "Cancel",
      onclick: onclose,
    },
    {
      backgroundColor: darkblueColor,
      color: whiteColor,
      outline: false,
      buttonText: "Save",
      onclick: onclose,
    },
  ];

  const isDefault = values.members === "All members";
  const isEmpty = Object.keys(errors).length === 0;

  const onUpdate = (handleEditClose: any) => {
    if (!isEmpty) {
      return;
    }
    try {
      onTeamUpdate({
        variables: {
          input: {
            id: values.members,
            teamName: values.teamName,
          },
        },
      });
      handleEditClose();
    } catch (err) {
      console.log(err);
    }
  };

  const onDelete = () => {
    if (!isDefault) {
      onnDeleteTeam({
        variables: {
          deleteTeamByIdId: values.members,
        },
      });
    }
  };

  return (
    <>
      <Modal
        open={open}
        width="900"
        closeModal={onclose}
        maxWidth="xl"
        styles={borderStyle}
      >
        <ModalContainer>
          <ModalHeader
            onclose={onclose}
            component={<ModalHeading heading={"Team Accounts"} />}
            showClose={true}
          />
          <FormWrapper>
            <SelectBox
              name="members"
              options={teamMembers}
              value={values?.members}
              onChange={handleSelect as any}
              sx={{ ...selectBoxstyle, mb: 2 }}
            />
            {!isDefault && (
              <InputCrud
                inputname={"teamName"}
                value={values.teamName}
                error={errors.teamName}
                handleChange={handleChange}
                reset={resetForm}
                onUpdate={onUpdate}
                onDelete={onDelete}
              />
            )}{" "}
          </FormWrapper>
          <ModalFooter
            componentRight={<ComboButtons buttons={buttonsConfig} />}
          />
        </ModalContainer>
      </Modal>
    </>
  );
};

export default TeamsAccount;

const FormWrapper = styled.div`
  max-width: 456px;
`;
