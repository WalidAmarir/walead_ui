import React, { useEffect, useMemo, useState } from "react";
import Modal from "../Modal";
import styled from "@emotion/styled";
import {
  DraftSGV,
  Earth,
  SquareDot,
} from "@/utils/formUtils/InputSvg/InputSvg";
import {
  darkCharcoalColor,
  borderRadiusLarger,
  greyColor,
  darkblueColor,
  whiteColor,
  lightRedColor,
  fontSizeCaptionSmall,
  guttersPx,
  orangeColor,
} from "@/styles/variables";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ComboButtons from "@/components/schedulePost/ComboButtons";
import { borderStyle } from "@/styles/base";
import { typographyParagraph } from "@/styles/typography";
import AlertPoPup from "./AlertPoPup";
import { getPostStatus, isCurrentDate } from "@/utils/helperUtils";
import { useLazyQuery, useMutation } from "@apollo/client";
import { DELETE_POST_BY_ID } from "@/lib/graphql/queries/deletePostById";
import { errorToast, successToast } from "@/styles/toaster";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { UPDATE_POST_BY_ID } from "@/lib/graphql/mutation/upadatePostById";
import SchedulePost from "./SchedulePost";
import { AvatarInitials } from "../../avatar/Avatar";
import { ImageList } from "../../image/ImageList";
import { useQueryContext } from "@/context/query/queryContext";
import { setDefaultTeamMembersPostUpdate } from "@/utils/optionUtils";
const baseTextStyles = `
  color: ${darkCharcoalColor};
  ${typographyParagraph};
`;

const ModalContainer = styled.div`
  min-width: 760px;
`;

const Card = styled.div`
  height: fit-content;
  border-radius: ${borderRadiusLarger};
`;

const User = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
  margin-bottom: ${guttersPx.extraLarge};
  .MuiAvatar-root {
    background: transparent;
  }
`;

const UserInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

const UserName = styled.h3`
  ${baseTextStyles}
`;

const PostContent = styled.p`
  color: ${darkCharcoalColor};
  ${typographyParagraph};
  margin: ${guttersPx.medium} 0;
  word-wrap: break-word;
  a {
    color: ${darkblueColor} !important;
  }
`;

const Span = styled.span`
  ${baseTextStyles}
  color: ${greyColor};
  font-size: ${fontSizeCaptionSmall};
`;

const NowIconContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
`;

const SpanSVG = styled.span`
  margin-left: 6px;
`;

const PostActions = ({
  open,
  onClose,
  data,
}: {
  open: boolean;
  onClose: () => void;
  data: any;
}) => {
  const [openDelete, setOpenDelete] = useState(false);
  const [btnName, setBtnName] = useState("Draft");
  const { isDraft, isPublished } = getPostStatus(data);
  const { profiledata } = useQueryContext();
  const { refetch, setIsLoader } = useScheduledContext();

  const defaultData = setDefaultTeamMembersPostUpdate(data, profiledata);

  const handleOpen = (btnText: string) => {
    setBtnName(btnText);
    setOpenDelete(true);
  };

  const handleCloseDelete = () => {
    setOpenDelete(false);
  };

  const buttonsConfig = [
    {
      backgroundColor: whiteColor,
      color: greyColor,
      outline: true,
      buttonText: "Edit",
      onclick: () => handleOpen("Edit"),
    },
    {
      backgroundColor: lightRedColor,
      color: whiteColor,
      outline: false,
      buttonText: "Delete",
      onclick: () => handleOpen("Delete"),
    },
    {
      backgroundColor: darkblueColor,
      color: whiteColor,
      outline: false,
      buttonText: "Publish",
      isHide: isPublished || !isCurrentDate(data?.displayDate),
      onclick: () => handleOpen("Publish"),
    },
    {
      color: whiteColor,
      Icon: <DraftSGV />,
      outline: false,
      buttonText: "Draft",
      isHide: isDraft || isPublished,
      onclick: () => handleOpen("Draft"),
    },
  ];

  const handleCancel = () => {
    setOpenDelete(false);
  };

  const onPostUpdateSuccess = (message: string) => {
    successToast(message);
    onClose();
    handleCloseDelete();
    refetch();
  };
  const [handleDeletePost, { loading }] = useLazyQuery(DELETE_POST_BY_ID, {
    onCompleted: () => onPostUpdateSuccess("Successfully deleted"),
  });

  const [handleUpdatePost, { loading: updateLoading }] = useMutation(
    UPDATE_POST_BY_ID,
    {
      onCompleted: () => onPostUpdateSuccess("Post updated successfully"),
    },
  );
  const handleUpdate = async (actiontype: string) => {
    try {
      setIsLoader(true);
      await handleUpdatePost({
        variables: {
          input: {
            id: data.id,
            status: actiontype,
          },
        },
      });
    } catch (err: any) {
      errorToast(err.message);
    }
  };

  const handleEdit = async (values: any, resetForm: () => void) => {
    const {
      commentImg,
      commentContent,
      commentDateTime,
      img,
      status,
      ...rest
    } = values;
    try {
      setIsLoader(true);
      const { data: updateresponse } = await handleUpdatePost({
        variables: {
          input: {
            id: data.id,
            ...rest,
          },
        },
      });
      if (updateresponse?.updatePost) {
        resetForm();
      }
    } catch (err: any) {
      errorToast(err.message);
    }
  };
  const handleDelete = async () => {
    try {
      setIsLoader(true);
      await handleDeletePost({
        variables: {
          deletePostByIdId: data?.id,
        },
      });
    } catch (err: any) {
      errorToast(err.message);
    }
  };

  const cancelButtonConfig = {
    backgroundColor: whiteColor,
    color: darkCharcoalColor,
    outline: true,
    buttonText: "Cancel",
    onclick: handleCancel,
  };

  const deleteButtonConfig = {
    backgroundColor: lightRedColor,
    color: whiteColor,
    outline: false,
    buttonText: "Delete",
    onclick: handleDelete,
  };

  const publishButtonConfig = {
    backgroundColor: darkblueColor,
    color: whiteColor,
    outline: false,
    buttonText: "Publish",
    onclick: () => {
      handleUpdate("Posted");
    },
  };
  const confirmButtonConfig = {
    backgroundColor: orangeColor,
    color: whiteColor,
    outline: false,
    buttonText: "Confirm",
    onclick: () => {
      handleUpdate("Drafts");
    },
  };
  const getModal = useMemo(() => {
    switch (btnName) {
      case "Delete":
        return (
          <AlertPoPup
            open={openDelete}
            onclose={handleCloseDelete}
            ButtonConfig={[cancelButtonConfig, deleteButtonConfig]}
            heading={"Delete post"}
          />
        );
      case "Publish":
        return (
          <AlertPoPup
            subheading="Once the post is published, it will change the expected time to the current time. Do you want to continue?"
            open={openDelete}
            onclose={handleCloseDelete}
            ButtonConfig={[cancelButtonConfig, publishButtonConfig]}
            heading="Publish post now"
          />
        );
      case "Draft":
        return (
          <AlertPoPup
            subheading="The post will be changed to a draft, and it won't be published automatically."
            open={openDelete}
            onclose={handleCloseDelete}
            ButtonConfig={[cancelButtonConfig, confirmButtonConfig]}
            heading="Switch to draft"
          />
        );
      case "Edit":
        return (
          <SchedulePost
            edit
            deafultvalues={defaultData}
            open={openDelete}
            onOpen={() => {
              setOpenDelete(true);
            }}
            onClose={handleCloseDelete}
            onSubmit={handleEdit}
          />
        );
      default:
        break;
    }
  }, [btnName, openDelete]);

  useEffect(() => {
    const isLoading = updateLoading || loading;
    setIsLoader(isLoading);
  }, [updateLoading, loading]);
  return (
    <>
      <Modal
        open={open}
        width="1000"
        closeModal={onClose}
        maxWidth={false}
        styles={borderStyle}
      >
        <ModalContainer>
          <ModalHeader component={<></>} showClose={true} onclose={onClose} />
          <Card>
            <User>
              <AvatarInitials
                w={"48px"}
                h={"47px"}
                name={data?.createdFor?.fullName}
                profilePicture={data?.createdFor?.profilePicture}
                textSize={"12px"}
              />
              <UserInfo>
                <UserName>{data?.createdFor?.fullName}</UserName>
                <NowIconContainer>
                  <Span>Now</Span>
                  <Span>
                    <SquareDot />
                  </Span>
                  <SpanSVG>
                    <Earth />
                  </SpanSVG>
                </NowIconContainer>
              </UserInfo>
            </User>
            <PostContent
              dangerouslySetInnerHTML={{ __html: data?.dbContent }}
            ></PostContent>
            {data?.img && <ImageList images={data?.img} />}
          </Card>

          <ModalFooter
            componentRight={<ComboButtons buttons={buttonsConfig} />}
          />
        </ModalContainer>
        {getModal}
      </Modal>
    </>
  );
};

export default PostActions;
