import React, { useState } from "react";
import Modal from "../Modal";
import styled from "@emotion/styled";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import { guttersPx, lightRedColor, whiteColor } from "@/styles/variables";

import ModalHeading from "@/components/schedulePost/ModalHeading";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ComboButtons from "@/components/schedulePost/ComboButtons";
import SchedulePostCard from "../../CardContainer/SchedulePostCard";
import MultiProfileCheck from "../../input/MultiProfileCheck";
import { DELETE_DEAL_POST } from "@/lib/graphql/queries/deletedealpost";
import { useLazyQuery } from "@apollo/client";
import { errorToast, successToast } from "@/styles/toaster";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
const ModalContainer = styled.div`
  padding: 40px;
  width: 732px;
`;

const Wrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: ${guttersPx.extraLarge} 0;
`;
const CardContainer = styled.div`
  width: 100%;
  max-width: 200px;
`;
const SearchContainer = styled.div``;

const DeleteDeal = ({
  data,
  isOpen,
  onclose,
}: {
  data: any;
  isOpen: boolean;
  onclose: (arg: boolean) => void;
}) => {
  const { refetch } = useScheduledContext();
  const [selectedCheckboxes, setSelectedCheckboxes] = useState<string[]>([]);
  const closeHandler = () => {
    onclose(false);
  };
  const handleDeleteSuccess = (deleteDealPostdata: {
    deleteDealPost: string;
  }) => {
    successToast(deleteDealPostdata?.deleteDealPost);
    closeHandler();
    refetch();
  };

  const handleDeleteError = (err: { message: string }) => {
    errorToast(err?.message);
  };

  const [handleDelete] = useLazyQuery(DELETE_DEAL_POST, {
    fetchPolicy: "no-cache",
    onCompleted: handleDeleteSuccess,
    onError: handleDeleteError,
  });

  const handleCheckboxChange = (id: string) => {
    setSelectedCheckboxes((prevSelected) => {
      if (prevSelected?.includes(id)) {
        return prevSelected?.filter((selectedId) => selectedId !== id);
      } else {
        return [...prevSelected, id];
      }
    });
  };

  const onDeleteDealPost = async () => {
    if (selectedCheckboxes.length === 0) {
      return errorToast("Please select any one value");
    }
    await handleDelete({
      variables: {
        ids: selectedCheckboxes,
        postId: data?.id,
      },
    });
  };

  const buttonsConfig = [
    {
      backgroundColor: lightRedColor,
      color: whiteColor,
      outline: false,
      buttonText: "Delete",
      onclick: onDeleteDealPost,
    },
  ];
  return (
    <>
      <Modal
        open={isOpen}
        width="732px"
        closeModal={closeHandler}
        maxWidth="xl"
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <ModalContainer>
          <ModalHeader
            component={
              <ModalHeading heading="Select the deal you want to delete" />
            }
            showClose
            onclose={closeHandler}
          />
          <Wrapper>
            <CardContainer>
              <SchedulePostCard data={data} />
            </CardContainer>
            <SearchContainer>
              <MultiProfileCheck
                profiledata={data?.dealMember}
                value={selectedCheckboxes}
                handleChange={handleCheckboxChange}
              />
            </SearchContainer>
          </Wrapper>
          <ModalFooter
            componentRight={<ComboButtons buttons={buttonsConfig} />}
          />
        </ModalContainer>
      </Modal>
    </>
  );
};

export default DeleteDeal;
