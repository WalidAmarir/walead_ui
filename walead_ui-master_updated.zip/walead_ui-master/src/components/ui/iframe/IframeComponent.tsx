import { greyColor } from "@/styles/variables";
import { extractVideoId } from "@/utils/helperUtils";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React, { useEffect, useMemo, useState } from "react";
import PDFViewer from "../pdfrenderer/PdfRenderer";

const isValidUrl = (url: string | URL) => {
  try {
    new URL(url);
    return true;
  } catch (error) {
    return false;
  }
};

const IFrameSkeleton = styled.div<{
  width: string;
  height: string;
}>(
  ({ width, height }) => css`
    width: ${width};
    height: ${height}px;
    background-color: ${greyColor};
    display: grid;
    place-items: center;
    text-align: center;
  `,
);

const IframeComponent = ({
  url,
  width,
  height,
  type,
  isSingle = false,
}: {
  url: string;
  height: string;
  width: string;
  type: string;
  isSingle?: boolean;
}) => {
  const [hasError, setHasError] = useState(!isValidUrl(url));

  const handleIframeError = () => {
    setHasError(true);
  };
  useEffect(() => {
    setHasError(!isValidUrl(url));
  }, [url]);

  return (
    <div>
      {hasError ? (
        <IFrameSkeleton width={width} height={height}>
          Something went wrong. Invalid URL or iframe error.
        </IFrameSkeleton>
      ) : (
        <IFrame
          type={type}
          url={url}
          width={width}
          height={height}
          handleIframeError={handleIframeError}
          isSingle={isSingle}
        />
      )}
    </div>
  );
};

export default IframeComponent;

interface Props {
  type: string;
  url: string;
  width: string;
  height: string;
  isSingle: boolean;
  handleIframeError: () => void;
}

const IFrame: React.FC<Props> = ({
  type,
  url,
  width,
  height,
  isSingle,
  handleIframeError,
}) => {
  const commonIframeProps = {
    frameBorder: 0,
    allowFullScreen: true,
    allow:
      "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
  };

  const YoutubeID = extractVideoId(url);
  const embedUrl = `https://www.youtube.com/embed/${YoutubeID}`;
  const renderUrl = useMemo(() => {
    const renderers: { [key: string]: JSX.Element | null } = {
      Video: (
        <iframe
          title="MyIframe"
          src={embedUrl}
          width={width}
          height={height}
          onError={handleIframeError}
          {...commonIframeProps}
        ></iframe>
      ),
      Document: (
        <PDFViewer
          pdfUrl={url}
          isSingle={isSingle}
          width={width}
          height={height}
        />
      ),
      PDF: (
        <PDFViewer
          pdfUrl={url}
          isSingle={isSingle}
          width={width}
          height={height}
        />
      ),
    };

    return renderers[type] || null;
  }, [type, url, width, height, handleIframeError]);
  return <>{renderUrl}</>;
};
