import { mqMax, styledWebkitScrollbar } from "@/styles/base";
import {
  darkblueColor,
  darkCharcoalColor,
  lightGreyColor,
} from "@/styles/variables";
import { getLastIndex } from "@/utils/helperUtils";
import { css } from "@emotion/core";
import styled from "@emotion/styled";
import Checkbox from "@mui/material/Checkbox";
import React, { useEffect, useState } from "react";
import { ErrorMessage } from "../input/InputBox";
import { typographyParagraph } from "@/styles/typography";

interface CheckedProps {
  handleChecked?(): void;
  isLabel?: boolean;
  name: string;
  error?: string;
  setFieldValue?: any;
  data?: string;
  width?: string | number;
  wrapperWidth?: string;
  dealStage: any[];
  setStageName?: (arg: string) => void;
}
interface StateProps {
  [x: string]: any;
  [index: number]: string;
  length: number;
}

const Wrapper = styled.div<{
  wrapperWidth?: string;
}>(
  ({ wrapperWidth }) => css`
    display: flex;
    max-width: ${wrapperWidth ? wrapperWidth : "auto"};
    overflow: auto;
    justify-content: start;
    gap: 10px;
    & span {
      padding: 0;
    }
    ${styledWebkitScrollbar}
  `,
);
const Label = styled.div<{
  index: number;
  last: number;
  color: string;
  width?: string | number;
}>(
  ({ index, last, color, width = "65" }) => css`
    display: flex;
    width: 100%;
    width: ${width}px;
    height: 33px;
    position: relative;
    align-items: center;
    cursor: pointer;
    background-color: ${color || lightGreyColor};
    color: ${darkCharcoalColor};
    ${chekIndex(index, last, color)}
  `,
);

const DealCheckBox = ({
  name,
  error,
  setFieldValue,
  isLabel = false,
  width,
  data,
  wrapperWidth,
  dealStage,
  setStageName,
}: CheckedProps) => {
  const lastIndex = getLastIndex(Object.entries(dealStage));
  const [state, setState] = useState<StateProps>([]);
  const [label, setLabel] = useState<any>({});
  const getDefaultFun = () => {
    const stageFieldsValues = Object.values(dealStage);
    const index = stageFieldsValues.findIndex(
      (field: any) => field.label === data,
    );
    const defaultState = stageFieldsValues
      .slice(0, index + 1)
      .map((field: any) => field?.value);
    setState(defaultState);
  };

  useEffect(() => {
    if (data) {
      getDefaultFun();
    }
  }, [data]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    number: number,
  ) => {
    let arr = [];
    for (let index = 0; index <= number; index++) {
      const element = dealStage[index];
      arr.push(element.value);
    }
    setFieldValue(name, arr);
    setState([...arr]);
    const getname = dealStage?.find(
      (item: { value: string }) => item.value === e.target.value,
    );
    setLabel(getname);
    if (setStageName) {
      setStageName(getname?.label);
    }
  };
  return (
    <div>
      <Wrapper wrapperWidth={wrapperWidth}>
        {dealStage?.map((item: { value: unknown }, index: number) => {
          return (
            <Checkbox
              key={index}
              name={name}
              checked={state.includes(item.value)}
              onChange={(e) => {
                handleChange(e, index);
              }}
              value={item.value}
              icon={
                <Label
                  color={lightGreyColor}
                  index={index}
                  last={lastIndex}
                  width={width}
                ></Label>
              }
              checkedIcon={
                <Label
                  color={darkblueColor}
                  index={index}
                  last={lastIndex}
                ></Label>
              }
            />
          );
        })}
      </Wrapper>
      {isLabel && !error && <LabelText>{label?.label}</LabelText>}
      {error && <ErrorMessage>{error}</ErrorMessage>}
    </div>
  );
};

export default DealCheckBox;

const chekIndex = (fIndex: number, lIndex: number, color: string) => {
  let style: string = "";
  if (fIndex !== lIndex) {
    style += `&::before {
        content: "";
        position: absolute;
        right: -9px;
        ${mqMax.desktop}{
        right: -8px;
        };
        bottom: 0;
        width: 0;
        top:0;
        height: 0;
        border-left: 11px solid ${color ?? lightGreyColor};
        border-top: 16px solid transparent;
        border-bottom: 16px solid transparent;;
      }`;
  }
  if (fIndex !== 0) {
    style += `&::after {
      content: "";
      position: absolute;
      top:0;
      left: 0;
      bottom: 0;
      width: 0;
      height: 0;
      border-left: 6px solid white;
      border-top: 16px solid transparent;
      border-bottom: 16px solid transparent;
  `;
  }
  return style;
};
export const LabelText = styled.h3(
  [typographyParagraph],
  `
  color:${darkCharcoalColor};
  padding:5px 0
`,
);
