import { typographySubtitle2Normal } from "@/styles/typography";
import {
  darkblueColor,
  greyColor,
  guttersPx,
  whiteColor,
} from "@/styles/variables";
import { MinusIcon, PlusIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import styled from "@emotion/styled";
import React from "react";

const QuantityContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${guttersPx.medium};
`;

const QuantityInput = styled.input`
  width: 100%;
  max-width: 100px;
  text-align: center;
  padding: ${guttersPx.small};
  border: 1px solid ${greyColor};
  border-radius: 5px;
  ${typographySubtitle2Normal}
`;

const QuantityButton = styled.button`
  background-color: ${darkblueColor};
  color: ${whiteColor};
  border: none;
  border-radius: 3px;
  padding: ${guttersPx.mediumHalf};
  cursor: pointer;
  display: grid;
  place-content: center;
`;

interface QuantitySelectorProps {
  value: number;
  onChange: (newValue: number) => void;
}

const QuantitySelector: React.FC<QuantitySelectorProps> = ({
  value,
  onChange,
}) => {
  const handleDecrease = () => {
    if (value > 1) {
      onChange(value - 1);
    }
  };

  const handleIncrease = () => {
    if (value < 100) {
      onChange(value + 1);
    }
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = event.target.value;
    if (/^\d*$/.test(newValue)) {
      const intValue = newValue === "" ? 0 : parseInt(newValue, 10);
      if (intValue >= 0 && intValue <= 100) {
        onChange(intValue);
      }
    }
  };

  return (
    <QuantityContainer>
      <QuantityButton onClick={handleDecrease}>
        <MinusIcon width={16} height={16} color="white" />
      </QuantityButton>
      <QuantityInput
        type="text"
        value={value}
        onChange={handleInputChange}
        min="1"
        max="100"
      />
      <QuantityButton onClick={handleIncrease}>
        <PlusIcon width={16} height={16} color="white" />
      </QuantityButton>
    </QuantityContainer>
  );
};

export default QuantitySelector;
