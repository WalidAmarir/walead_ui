import React, { ReactNode, useState } from "react";
import styled from "@emotion/styled";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import { SelectChangeEvent } from "@mui/material/Select";
import {
  greyColor,
  whiteColor,
  fontFamily,
  guttersPx,
  blackColor,
} from "@/styles/variables";
import { WorkOption } from "@/types/global";
import { SvgIconProps } from "@mui/material/SvgIcon";
import { DownArrowIcon, UpArrowIcon } from "@/layouts/form/SelectBox";
import { StyledSelect } from "@/styles/base";
import { MenuItem, IconButton } from "@mui/material";
import { selectInputProp } from "@/shared/UserMenu/SharedUserMenuComponents";
import { css } from "@emotion/core";
export interface ExtendedWorkOption extends WorkOption {
  icon?: any;
  description?: string;
}
interface SelectBoxProps {
  id?: string;
  label?: string;
  name: string;
  options: ExtendedWorkOption[];
  value: string | string[];
  width?: string;
  onChange: (event: SelectChangeEvent<unknown>) => void;
  sx?: any;
  isMultiple?: boolean;
  defaultVal?: string;
  actionIcon?: any;
  onAction?: (data: any) => void;
  bottomComponent?: ReactNode;
}

const IconWrapper = styled.div`
  div {
    top: 20%;
    right: 5%;
    translate: (-5%, -20%);
  }
`;

const renderIconComponent = (iconProps: SvgIconProps, isOpen: boolean) => {
  const color = greyColor;
  return (
    <IconWrapper>
      {isOpen ? (
        <UpArrowIcon color={color} {...iconProps} />
      ) : (
        <DownArrowIcon color={color} {...iconProps} />
      )}
    </IconWrapper>
  );
};

const CustomSelectBox: React.FC<SelectBoxProps> = ({
  id,
  label,
  name,
  options,
  value,
  onChange,
  width,
  sx,
  isMultiple = false,
  defaultVal = "",
  actionIcon,
  onAction,
  bottomComponent,
}: SelectBoxProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const renderValue = (arr: any) => {
    if (Array.isArray(arr)) {
      return defaultVal;
    }
    return arr;
  };

  const onActionChange = (option: ExtendedWorkOption) => {
    if (onAction) {
      onAction(option);
    }
  };

  return (
    <FormControl sx={{ width: width ? width : "100%" }}>
      <InputLabel id={`${id}-label`}>{label}</InputLabel>
      <StyledSelect
        labelId={`${id}-label`}
        id={id}
        IconComponent={(iconProps) => renderIconComponent(iconProps, isOpen)}
        onOpen={() => setIsOpen(true)}
        onClose={() => setIsOpen(false)}
        multiple={isMultiple}
        value={value || ""}
        name={name}
        onChange={onChange}
        sx={sx ? sx : { mb: 1, fontFamily: fontFamily }}
        renderValue={isMultiple ? renderValue : undefined}
        inputProps={selectInputProp}
      >
        {options.map((option: ExtendedWorkOption) => (
          <MenuItem
            sx={sx ? sx : menuItemStyle}
            key={option.value}
            style={menuItemStyle}
            value={option.value}
          >
            <>
              <StyledWrapper direction={option?.description}>
                <LabelWrapper>
                  {option.icon && <>{option.icon}</>}
                  {option.label}
                </LabelWrapper>
                {actionIcon && option.value === value && (
                  <ActionIconButton
                    className="actionicon"
                    disableRipple
                    onClick={() => onActionChange(option)}
                  >
                    {actionIcon}
                  </ActionIconButton>
                )}
                {option.description && (
                  <p className="description">{option.description}</p>
                )}
              </StyledWrapper>
            </>
          </MenuItem>
        ))}
        {bottomComponent ? bottomComponent : null}
      </StyledSelect>
    </FormControl>
  );
};

export default CustomSelectBox;

const LabelWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: ${guttersPx.mediumHalf};
`;

const StyledWrapper = styled.div<{
  direction?: string;
}>(
  ({ direction }) => css`
    overflow: hidden;
    text-overflow: ellipsis;
    flex-direction: ${direction ? "column" : "row"};
    display: flex;
    align-items: ${direction ? "start" : "center"};
    gap: ${guttersPx.smallHalf};
    justify-content: space-between;
    width: 100%;
  `,
);

const menuItemStyle = {
  fontSize: "14px",
  mb: 1,
  fontFamily: "Montserrat !important",
  fontWeight: 500,
  color: blackColor,
  ".Mui-selected ": {
    color: whiteColor,
  },
};

const ActionIconButton = styled(IconButton)`
  margin-left: auto;
  border-radius: 5px;
  background-color: ${whiteColor};
`;
