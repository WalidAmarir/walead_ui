import {
  boxShadow,
  darkblueColor,
  fontSizeH5,
  fontWeightBold,
  whiteColor,
  mediumButtonWidth,
  mediumButtonHeight,
  buttonRadius,
  buttonBorder,
  buttonCursor,
  mediumButtonPadding,
  fontFamily,
} from "@/styles/variables";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import Link from "next/link";
import React, { ReactElement, SyntheticEvent } from "react";

const ButtonContainer = styled.button<{
  bgColor?: string;
  color?: string;
  borderColor?: string;
  width?: string;
  height?: string;
}>(
  ({
    bgColor = darkblueColor,
    color = whiteColor,
    borderColor,
    width = mediumButtonWidth,
    height = mediumButtonHeight,
  }) => css`
    padding: ${mediumButtonPadding};
    border-radius: ${buttonRadius};
    cursor: ${buttonCursor};
    width: ${width};
    height: ${height};
    color: ${color};
    background: ${bgColor};
    box-shadow: ${boxShadow};
    font-size: ${fontSizeH5};
    font-weight: ${fontWeightBold};
    font-family: ${fontFamily};
    border: ${borderColor ? borderColor : buttonBorder};
    display: grid;
    place-content: center;
  `,
);
const Button = ({
  className = "",
  id,
  type = "button",
  disabled = false,
  onClick,
  href,
  children,
  color,
  bgColor,
  width,
  height,
  borderColor,
}: {
  className?: string;
  id?: string;
  type?: "submit" | "reset" | "button";
  disabled?: boolean;
  onClick?: (e: SyntheticEvent) => void;
  href?: string;
  children?: string | ReactElement | ReadonlyArray<ReactElement | string>;
  color?: string;
  bgColor?: string;
  width?: string;
  height?: string;
  borderColor?: string;
}) => {
  return href ? (
    <Link href={href} className={className} onClick={onClick}>
      {children}
    </Link>
  ) : (
    <ButtonContainer
      width={width}
      height={height}
      id={id}
      className={className}
      disabled={disabled}
      onClick={onClick}
      type={type}
      bgColor={bgColor}
      color={color}
      borderColor={borderColor}
    >
      {children}
    </ButtonContainer>
  );
};

export default Button;
