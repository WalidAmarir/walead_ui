import { typographyBold } from "@/styles/typography";
import { GreenTeal, buttonRadius, whiteColor } from "@/styles/variables";
import { Button, styled } from "@mui/material";

interface ExportButtonProps {
  buttonText: string;
  disabled?: boolean;
  onExportCsv: () => void;
}
const BtnDownload = styled(Button)`
  ${typographyBold};
  text-align: center;
  text-transform: none;
  border-radius: ${buttonRadius}px;
  background-color: ${GreenTeal};
  &.Mui-disabled {
    border-radius: ${buttonRadius}px;
    color: ${whiteColor};
    background-color: rgba(103, 214, 75, 0.3);
  }
  &:hover {
    background-color: #87e270;
  }
`;
function ExportButton({
  buttonText = "Export",
  disabled,
  onExportCsv,
}: ExportButtonProps) {
  return (
    <BtnDownload variant="contained" onClick={onExportCsv} disabled={disabled}>
      {buttonText}
    </BtnDownload>
  );
}

export default ExportButton;
