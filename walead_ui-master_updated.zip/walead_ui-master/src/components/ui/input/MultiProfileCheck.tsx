import React from "react";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import styled from "@emotion/styled";
import {
  borderRadiusTiny,
  darkCharcoalColor,
  fontSizeBody2,
  guttersPx,
  lightGreyColor,
} from "@/styles/variables";
import { AvatarInitials } from "../avatar/Avatar";
import { typographySubtitle2Normal } from "@/styles/typography";
const ProfileCheck = styled.div`
  padding: 20px;
  width: 292px;
  min-height: 180px;
  max-height: 230px;
  border-radius: 5px;
  box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);
`;
const ScrollableContainer = styled(FormGroup)`
  max-height: 176px;
  flex-wrap: unset;
  overflow-x: hidden;
  overflow-y: auto;
  &::-webkit-scrollbar {
    width: 3px;
  }

  &::-webkit-scrollbar-thumb {
    height: 174px;
    border-radius: ${borderRadiusTiny};
    background: ${lightGreyColor};
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }
`;

interface DealArray {
  leadImage: string | undefined;
  name: string;
  id: string;
}

const MultiProfileCheck = ({
  profiledata = [],
  value,
  handleChange,
}: {
  profiledata: DealArray[];
  value: string[];
  handleChange: (id: string) => void;
}) => {
  return (
    <ProfileCheck>
      <ScrollableContainer>
        {profiledata?.map((item) => (
          <FormControlLabel
            key={item.id}
            control={
              <Checkbox
                checked={value.includes(item.id)}
                onChange={() => handleChange(item.id)}
              />
            }
            label={
              <Label>
                <AvatarInitials
                  w={"23px"}
                  h={"23px"}
                  name={item.name}
                  profilePicture={item.leadImage}
                  textSize={fontSizeBody2}
                />
                <NameSpan>{item.name}</NameSpan>
              </Label>
            }
          />
        ))}
      </ScrollableContainer>
    </ProfileCheck>
  );
};

export default MultiProfileCheck;

const Label = styled.div`
  color: ${darkCharcoalColor};
  ${typographySubtitle2Normal};
  display: flex;
  align-items: center;
`;
const NameSpan = styled.span`
  margin-left: ${guttersPx.mediumHalf};
`;
