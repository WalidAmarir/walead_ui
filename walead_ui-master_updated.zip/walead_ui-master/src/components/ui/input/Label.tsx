import React from "react";
import styled from "@emotion/styled";
import { greyColor } from "../../../styles/variables";
import { typographyParagraph } from "@/styles/typography";
const Label = ({ labelText }: { labelText: string }) => {
  const TextAreaLabel = styled.div`
    color: ${greyColor};
    ${typographyParagraph};
    padding-bottom: 10px;
  `;
  return <TextAreaLabel>{labelText}</TextAreaLabel>;
};

export default Label;
