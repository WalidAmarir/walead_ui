import React, { useState, useRef, useCallback, useEffect } from "react";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css";
import EditorToolBar, { formats } from "../editor/EditorToolbar";
import styled from "@emotion/styled";
import { darkblueColor, fontFamily, greyColor } from "@/styles/variables";
import { typographyParagraph } from "@/styles/typography";
import { ErrorMessage } from "@/shared/UserMenu/SharedUserMenuComponents";
import { formatText, isBrowser } from "@/utils/helperUtils";
import Quill from "quill";
import MagicUrl from "quill-magic-url";
if (Quill && typeof Quill.register === "function" && isBrowser) {
  Quill.register("modules/magicUrl", MagicUrl);
}

/* eslint-disable */
const QuillWrapper = dynamic(
  async () => {
    const { default: RQ } = await import("react-quill");
    return ({ forwardedRef, ...props }: any) => (
      <RQ ref={forwardedRef} {...props} />
    );
  },
  { ssr: false, loading: () => <p>Loading...</p> },
);

QuillWrapper.displayName = "QuillWrapper";

function insertEmoji(
  quillEditor: {
    getSelection: () => { (): any; new (): any; index: number };
    insertText: (arg0: any, arg1: any) => void;
    setSelection: (arg0: any, arg1: number) => void;
    getLength: () => any;
  },
  hashtag: React.SetStateAction<string>,
) {
  const cursorPosition = quillEditor?.getSelection()?.index || 0;
  quillEditor.insertText(cursorPosition, hashtag);
  quillEditor.setSelection(quillEditor.getLength(), 0);
}

export default function TextEditor(props: any) {
  const [selectedText, setSelectedText] = useState(null);
  const { name, placeholder, setValues, editorValue, editorError } = props;
  const quillRef = useRef<any>();

  const handleChange = (html: any) => {
    setSelectedText(null);
    setValues(name, html);
  };

  const handleEmoji = (value: React.SetStateAction<string>) => {
    const editor = quillRef.current?.getEditor();
    quillRef.current?.getEditor().focus();
    if (editor) {
      insertEmoji(editor, value);
    }
  };

  const modules = {
    toolbar: "#toolbar",
    magicUrl: true,
    clipboard: {
      matchVisual: false,
    },
  };
  const handleBoldClick = useCallback(() => {
    quillRef.current?.getEditor().focus();
    const editor = quillRef.current?.getEditor();
    if (editor) {
      const selection = editor.getSelection();
      if (selection) {
        const [startIndex] = [
          selection.index,
          selection.index + selection.length,
        ];
        const cursorPosition = selection.index;
        const selectedBoldText = editor.getText(
          cursorPosition,
          selection.length,
        );
        if (selectedBoldText !== undefined) {
          const boldText = formatText(selectedBoldText, "sansBold", {});
          editor.deleteText(startIndex, selection.length);
          editor.insertText(startIndex, boldText, "bold", false);
          editor.setSelection(startIndex + boldText.length);
        }
      }
    }
  }, [quillRef.current]);

  const handleItalicClick = useCallback(() => {
    quillRef.current?.getEditor().focus();
    const editor = quillRef.current?.getEditor();
    if (editor) {
      const selection = editor.getSelection();
      if (selection) {
        const [startIndex] = [
          selection.index,
          selection.index + selection.length,
        ];
        const cursorPosition = selection.index;
        const selectedItalicText = editor.getText(
          cursorPosition,
          selection.length,
        );
        if (selectedItalicText !== undefined) {
          const italicText = formatText(selectedItalicText, "sansItalic", {});
          editor.deleteText(startIndex, selection.length);
          editor.insertText(startIndex, italicText, "italic", false);
          editor.setSelection(startIndex + italicText.length);
        }
      }
    }
  }, [quillRef.current]);

  useEffect(() => {
    const editor = quillRef.current?.getEditor();
    if (editor) {
      editor.on("selection-change", (range: any) => {
        if (range) {
          const text = editor.getText(range);
          setSelectedText(text);
        }
      });
    }
  }, [quillRef.current]);

  const handleAddLink = (link: string) => {
    quillRef.current?.getEditor().focus();
    const range = quillRef.current.getEditor()?.getSelection();
    if (range) {
      quillRef.current
        ?.getEditor()
        .formatText(range.index, range.length, "link", link);
    }
  };

  const insertHashtag = () => {
    quillRef.current?.getEditor().focus();
    const quillEditor = quillRef.current?.getEditor();
    if (quillEditor) {
      const selection = quillEditor.getSelection();
      if (selection && selection.length > 0) {
        const cursorPosition = selection.index;
        const selectedHashText = quillEditor.getText(
          cursorPosition,
          selection.length,
        );
        if (selectedHashText.includes("#")) {
          return;
        }
        const hashtag = `#${selectedHashText} `;
        quillEditor.deleteText(cursorPosition, selection.length);
        quillEditor.insertText(cursorPosition, hashtag);
        quillEditor.setSelection(cursorPosition + hashtag.length);
        quillEditor.formatText(
          cursorPosition,
          hashtag.length - 1,
          "color",
          darkblueColor,
        );
      }
    }
  };

  const isEmpty = selectedText === null || selectedText === "";
  return (
    <TextEditorWrapper className="text-editor">
      <QuillWrapper
        theme="snow"
        forwardedRef={quillRef as any}
        value={editorValue}
        onChange={handleChange}
        modules={modules}
        formats={formats}
        {...props}
        placeholder={placeholder}
      />
      <EditorToolBar
        hideLink={true}
        isEmpty={isEmpty}
        handleAddLink={handleAddLink}
        handleBoldClick={handleBoldClick}
        handleItalicClick={handleItalicClick}
        setValue={handleEmoji}
        handleHash={insertHashtag}
      />
      {editorError && <ErrorMessage>{editorError}</ErrorMessage>}
    </TextEditorWrapper>
  );
}

const TextEditorWrapper = styled.div`
  min-height: 151px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  .ql-editor {
    min-height: 100px;
    max-height: 300px;
    overflow-y: auto;
  }
  .ql-container.ql-snow {
    border: none !important;
  }
  .ql-toolbar.ql-snow {
    border: none !important;
  }
  .ql-snow .ql-stroke {
    stroke: ${greyColor};
  }
  .ql-editor.ql-blank::before {
    ${typographyParagraph};
    font-style: normal;
    font-family: ${fontFamily};
    color: ${greyColor};
  }
`;
