import * as React from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import styled from "@emotion/styled";
import { darkCharcoalColor, whiteColor, fullWidth } from "@/styles/variables";
import { typographySubtitle1 } from "@/styles/typography";

const MyAutocomplete = styled(Autocomplete)`
  .MuiOutlinedInput-root {
    width: ${fullWidth};
    color: ${darkCharcoalColor};
    background-color: ${whiteColor};
    ${typographySubtitle1};
    height: 39px;
    border: 1px solid rgba(135, 135, 135, 0.5);
    padding-right: 0;
  }
  .MuiAutocomplete-input {
    padding: 0 4px 0 4px !important;
  }

  &.MuiAutocomplete-hasPopupIcon {
    margin: 0;
  }
`;

export const SearchSuggestWithLabel = ({
  setTimezone,
  timezone,
}: {
  setTimezone: any;
  timezone: string;
}) => {
  const handleOptionChange = (newValue: any) => {
    setTimezone(newValue);
  };

  return (
    <MyAutocomplete
      disablePortal
      value={timezone}
      id="combo-box-demo"
      options={timezoneOptions}
      getOptionLabel={(option: any) => option}
      renderInput={(params) => <TextField {...params} variant="outlined" />}
      onChange={(event, value) => handleOptionChange(value)}
    />
  );
};
const timezoneOptions = [
  "America/Bogota",
  "America/New_York",
  "America/Santiago",
  "Asia/Calcutta",
  "Europe/Madrid",
];
