import { goldColor, guttersPx } from "@/styles/variables";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React, { useEffect, useState } from "react";
import { Rating } from "react-simple-star-rating";

const StarRating = ({
  initalValue = 0,
  readonly,
  size,
  isLabel = false,
  color = goldColor,
  onchange,
}: {
  initalValue?: number;
  readonly: boolean;
  size: number;
  isLabel?: boolean;
  color?: string;
  onchange?: (id: string | number) => void;
}) => {
  const [rating, setRating] = useState(initalValue);
  const handleRating = (rate: number) => {
    if (onchange) {
      onchange(rate);
    }
    setRating(rate);
  };
  useEffect(() => {
    setRating(initalValue);
  }, [initalValue]);
  return (
    <RatingWrapper>
      {isLabel && (
        <RatingLabel color={color}>{`${rating?.toFixed(1)}/${5}`}</RatingLabel>
      )}
      <Rating
        onClick={handleRating}
        initialValue={rating}
        readonly={readonly}
        allowFraction
        fillColor={color}
        emptyColor="transparent"
        SVGstrokeColor={color}
        SVGstorkeWidth={1}
        size={size}
        titleSeparator="/"
      />
    </RatingWrapper>
  );
};

export default StarRating;

const RatingWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
`;

const RatingLabel = styled.span<{
  color: string;
}>(
  ({ color }) => css`
    font-size: ${guttersPx.mediumHalf};
    color: ${color};
    font-weight: 500;
  `,
);
