import { darkblueColor, greyColor, guttersPx } from "@/styles/variables";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React from "react";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";

const dynamicBorder = (isChecked: boolean) => {
  let style: string = "";
  if (isChecked) {
    style += `border: 4px solid ${darkblueColor}`;
  } else {
    style += `border: 1px solid ${greyColor}`;
  }
  return style;
};

const Container = styled.div`
  display: flex;
  flex-direction: ${({ row }: { row: boolean }) => (row ? "row" : "column")};
  align-items: start;
  justify-content: ${({ row }: { row: boolean }) =>
    row ? "space-between" : "start"};
  gap: ${guttersPx.smallHalf};
`;

const OptionLabel = styled.label`
  margin-bottom: ${({ row }: { row: boolean }) =>
    row ? "0" : guttersPx.mediumHalf};
  margin-right: ${({ row }: { row: boolean }) =>
    row ? guttersPx.medium : "0"};
  position: relative;
`;

const RadioWrapper = styled.div`
  ${flexStyle};
  gap: ${guttersPx.small};
`;

const Radio = styled.input`
  position: absolute;
  opacity: 0;
  cursor: pointer;
  &:checked + span::before {
    background-color: white;
  }
`;

const CustomRadio = styled.span<{
  checked: boolean;
}>(
  ({ checked }) => css`
    position: relative;
    display: inline-block;
    width: 14px;
    height: 14px;
    ${dynamicBorder(checked)};
    border-radius: 50%;
    margin-right: 5px;
  `,
);

const OptionComponent = styled.div`
  margin-top: ${guttersPx.medium};
`;

interface RadioOption {
  label: string;
  value: string;
  component?: React.ReactElement;
}

interface RadioProps {
  options: RadioOption[];
  selectedOption: string;
  onChange: (value: any) => void;
  row?: boolean;
  name: string;
}

const RadioButton: React.FC<RadioProps> = ({
  options,
  selectedOption,
  onChange,
  row = false,
  name,
}) => {
  const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event);
  };

  return (
    <Container row={row}>
      {options.map((option) => (
        <>
          <OptionLabel key={option.value} row={row}>
            <RadioWrapper>
              <Radio
                type="radio"
                name={name}
                value={option.value}
                checked={selectedOption === option.value}
                onChange={handleRadioChange}
              />
              <CustomRadio checked={selectedOption === option.value} />
              {option.label}
            </RadioWrapper>
            {option.component && selectedOption === option.value && (
              <OptionComponent>{option.component}</OptionComponent>
            )}
          </OptionLabel>
        </>
      ))}
    </Container>
  );
};

export default RadioButton;
