import styled from "@emotion/styled";
import { typographyCaptionSmall } from "@/styles/typography";
import { blackColor, darkblueColor, guttersPx } from "@/styles/variables";
import React from "react";
import Skeletor from "../skeletor/Skeletor";
import { css } from "@emotion/react";

const ProgressBar = ({
  value = "100",
  maxValue = "100",
  loading,
  isLabel = false,
  color = darkblueColor,
}: {
  value: string | number;
  maxValue?: string;
  loading: boolean;
  isLabel?: boolean;
  color?: string;
}) => {
  return (
    <ProgressContainer>
      {loading ? (
        <Skeletor variant="text" width={200} height={10} />
      ) : (
        <>
          <Progress color={color} value={value} max={maxValue} />
          {isLabel && (
            <ProgressLabel htmlFor="file">{`${value}%`}</ProgressLabel>
          )}
        </>
      )}
    </ProgressContainer>
  );
};

export default ProgressBar;

const ProgressContainer = styled.div`
  display: flex;
  align-items: center;
  padding: ${guttersPx.mediumHalf} 0;
  width: 100%;
`;

const Progress = styled.progress<{
  color: string;
}>(
  ({ color }) => css`
    accent-color: ${color};
  `,
);

const ProgressLabel = styled.label`
  ${typographyCaptionSmall};
  color: ${blackColor};
  margin-left: 10px;
`;
