import React, { useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import styled from "@emotion/styled";
import { css } from "@emotion/react";

pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const PdfIframeStyle = styled.div<{
  width: string;
  height: string;
}>(
  ({ width, height }) => css`
    .react-pdf__Page__canvas {
      width: ${width} !important;
      height: ${height} !important; /* Set a fixed height for the container */
      overflow: auto; /* Enable scrolling for the container */
    }
  `,
);

const PdfRenderer = ({
  pdfUrl,
  isSingle,
  width,
  height,
}: {
  pdfUrl: string;
  isSingle: boolean;
  width: string;
  height: string;
}) => {
  const [numPages, setNumPages] = useState(1);

  const onDocumentLoadSuccess = (num: any) => {
    if (!isSingle) {
      setNumPages(num);
    }
  };

  return (
    <PdfIframeStyle width={width} height={height}>
      <Document file={pdfUrl} onLoadSuccess={onDocumentLoadSuccess}>
        {Array.from(new Array(numPages), (el, index) => (
          <>
            <Page
              key={el}
              pageNumber={index + 1}
              renderAnnotationLayer={false}
              renderTextLayer={false}
            />
          </>
        ))}
      </Document>
    </PdfIframeStyle>
  );
};

export default PdfRenderer;
