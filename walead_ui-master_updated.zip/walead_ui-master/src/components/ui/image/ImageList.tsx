import { css } from "@emotion/react";
import styled from "@emotion/styled";
import Image from "next/image";

export const ImageList = ({
  images,
  maxHeight = "300px",
}: {
  images: any[];
  maxHeight?: string;
}) => {
  return (
    <ImageListContainer maxheight={maxHeight}>
      {images?.map((image: string, index: number) => (
        <ImageWrapper key={index}>
          <PostImage
            width={100}
            height={100}
            src={image}
            alt={`image-${index}`}
            unoptimized
          />
        </ImageWrapper>
      ))}
    </ImageListContainer>
  );
};

const ImageListContainer = styled.div<{ maxheight: string }>(
  ({ maxheight }) => css`
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    max-height: ${maxheight};
    overflow: auto;
  `,
);

const ImageWrapper = styled.div`
  width: calc(33.33% - 10px);
  flex-grow: 1;
  position: relative;
  overflow: hidden;
`;

const PostImage = styled(Image)`
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
`;
