import styled from "@emotion/styled";
import Image, { ImageProps } from "next/image";
import React from "react";

type ImageComponentProps = {
  className?: string;
  src: string;
  alt: string;
  width?: number | string;
  height?: number | string;
  unoptimized?: boolean;
} & ImageProps;

const ImageComponent: React.FC<ImageComponentProps> = ({
  className = "",
  src = "",
  alt = "",
  height,
  width,
  unoptimized = true,
  ...rest
}) => {
  return (
    <StyledImage
      className={className}
      src={src}
      alt={alt}
      height={height}
      width={width}
      unoptimized={unoptimized}
      quality={100}
      {...rest}
    />
  );
};

export default ImageComponent;

const StyledImage = styled(Image)<{
  width?: number | string;
  height?: number | string;
}>`
  width: ${(props) => getValue(props.width)};
  height: ${(props) => getValue(props.height)};
  object-fit: cover;
`;

const getValue = (prop: string | number | undefined) => {
  if (typeof prop === "number") {
    return `${prop}px`;
  }
  return prop || "auto";
};
