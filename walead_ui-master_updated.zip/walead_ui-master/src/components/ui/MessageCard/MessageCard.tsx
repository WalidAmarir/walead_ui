import React from "react";

import Link from "next/link";
import styled from "@emotion/styled";
import { typographyH4Regular, typographyH5 } from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightGreenColor,
  lightRedColor,
  lightSilverColor,
  whiteColor,
} from "@/styles/variables";
import ButtonLarge from "../button/ButtonLarge";
import { CheckIcon, CrossIcon } from "@/utils/formUtils/InputSvg/InputSvg";

interface Props {
  title: string;
  message: string;
}

const MessageCard = ({ title, message }: Props) => {
  const isErr = title === "Error";
  return (
    <StyledCard>
      <CardBody>
        {isErr ? (
          <CrossIcon width="45" height="45" color={lightRedColor} />
        ) : (
          <CheckIcon width="45" height="45" color={lightGreenColor} />
        )}
        <Message>{title}</Message>
        <Para>{message}</Para>
        <Link href="/">
          <StyledButton className={isErr ? "errorBtn" : ""}>
            Back to Home
          </StyledButton>
        </Link>
      </CardBody>
    </StyledCard>
  );
};

export default MessageCard;

// Styled Components
const StyledCard = styled.div`
  background: ${whiteColor};
  padding: 60px;
  border-radius: 4px;
  border: 1px solid ${lightSilverColor};
  display: block;
  width: 50%;
  margin: auto;
  margin-top: 200px;
`;

const CardBody = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const StyledButton = styled(ButtonLarge)<{ className: string }>`
  color: white;
  background: ${(props) =>
    props.className === "errorBtn" ? lightRedColor : darkblueColor};
  max-width: 220px;

  &:hover {
    border-color: ${(props) =>
      props.className === "errorBtn" ? lightRedColor : darkblueColor};
    color: ${(props) =>
      props.className === "errorBtn" ? lightRedColor : darkblueColor};
  }
`;

const Para = styled.p`
  color: ${greyColor};
  ${typographyH4Regular}
  text-align: center;
  margin-bottom: ${guttersPx.medium};
`;

const Message = styled.h1`
  ${typographyH5};
  color: ${darkCharcoalColor};
  margin: ${guttersPx.medium} 0;
`;
