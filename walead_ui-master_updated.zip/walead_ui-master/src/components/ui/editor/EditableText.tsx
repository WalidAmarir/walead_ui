import { typographySubtitle1 } from "@/styles/typography";
import { blackColor } from "@/styles/variables";
import styled from "@emotion/styled";
import React, { useState } from "react";

type EditableTextProps = {
  value: string;
  name: string;
  handleNameChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  readOnly?: boolean;
};

const EditableTextWrapper = styled.div`
  display: inline-block;
  cursor: text;
`;

const EditableText: React.FC<EditableTextProps> = ({
  name,
  value,
  handleNameChange,
  readOnly = true,
}) => {
  const [text, setText] = useState(value);
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setText(event.target.value);
    handleNameChange(event);
  };

  return (
    <EditableTextWrapper>
      <EditableInput
        type="text"
        name={name}
        value={text}
        onChange={handleChange}
        contentEditable
        suppressContentEditableWarning
        readOnly={readOnly}
      />
    </EditableTextWrapper>
  );
};

export default EditableText;

const EditableInput = styled.input`
  width: 100%;
  border: none;
  outline: none;
  background: transparent;
  ${typographySubtitle1};
  color: ${blackColor};
`;
