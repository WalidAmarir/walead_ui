import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import styled from "@emotion/styled";

interface ReusableDrawerProps {
  children: React.ReactNode;
  anchor?: "left" | "right" | "top" | "bottom";
  width?: string; // width prop
  height?: string; // height prop
  open: boolean;
}

export default function SliderOverModal({
  children,
  anchor = "right",
  width,
  height,
  open,
}: ReusableDrawerProps) {
  const StyledDrawer = styled(Drawer)`
    .MuiDrawer-paper {
      width: ${width};
      height: ${height};
      margin-top: 4%;
    }
  `;
  return (
    <StyledDrawer anchor={anchor} open={open}>
      <Box role="presentation">{children}</Box>
    </StyledDrawer>
  );
}
