import React, { useState } from "react";
import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  Menu,
  MenuItem,
  IconButton,
  TableBody,
  Chip,
} from "@mui/material";
import styled from "@emotion/styled";
import {
  typographyCaptionNormal,
  typographyParagraph,
} from "@/styles/typography";
import { guttersPx } from "@/styles/variables";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import LeadModal from "@/components/leads/leadmodal/LeadModal";
import AlertPoPup from "../modal/schedulePost/AlertPoPup";
import { getButtonsConfigAlert } from "@/utils/helperUtils";
import useDialogState from "@/hooks/useDialogState";
import { useLazyQuery } from "@apollo/client";
import { DELETE_SAVE_SEARCH } from "@/lib/graphql/queries/deleteSaveSearch";
import { errorToast, successToast } from "@/styles/toaster";
import { colors } from "../avatar/Avatar";
import { VerticleDots } from "@/utils/formUtils/InputSvg/InputSvg";

// Define types for header and data
type HeaderType = Record<string, any>[];
type DataType = Record<string, any>[]; // Assuming data is an array of objects with string keys

// Styled component for the table container
const TableContainer = styled.div`
  width: 100%;
  margin-top: 20px;
  overflow-x: auto;
`;

const StyledMenu = styled(Menu)`
  .MuiPaper-root {
    background-color: #fff;
  }
`;

const StyledIconButton = styled(IconButton)`
  padding: 6px;
`;

const StyledTableCell = styled(TableCell)`
  ${typographyParagraph};
  padding: 8px 30px !important;
  &:last-child {
    padding-right: 30px; /* Adjust padding for the last cell to accommodate the menu icon */
  }
`;

const StyledTableCellBody = styled(TableCell)`
  ${typographyCaptionNormal};
  padding: 8px 30px !important;
  &:last-child {
    padding-right: 30px; /* Adjust padding for the last cell to accommodate the menu icon */
  }
`;

const NameCellContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const TagsWrapper = styled.div`
  ${flexStyle};
  flex-wrap: wrap;
  max-width: 200px;
  gap: ${guttersPx.smallHalf};
`;

interface CommonTableProps {
  header: HeaderType;
  data: DataType;
  refetch: () => void;
}

const SavedListTable: React.FC<CommonTableProps> = ({
  header,
  data,
  refetch,
}) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [defaultData, setDefaultData] = useState<Record<string, any> | null>(
    null,
  );
  const [dialogState, { handleCloseDialog, handleOpenDialog }] = useDialogState(
    {
      isEditOpen: false,
      isDeleteOpen: false,
    },
  );
  const [handleDelete] = useLazyQuery(DELETE_SAVE_SEARCH, {
    onCompleted: (res) => {
      handleClose();
      handleCloseDialog("isDeleteOpen");
      refetch();
      successToast(res?.deleteSaveSearch);
    },
    onError: (err) => errorToast(err?.message),
  });

  const handleClick = (
    event: React.MouseEvent<HTMLElement>,
    datavalue: Record<string, any>,
  ) => {
    setAnchorEl(event.currentTarget);
    setDefaultData(datavalue);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const onDelete = async () => {
    await handleDelete({
      variables: {
        deleteSaveSearchId: defaultData?.id,
      },
    });
  };
  const buttonsConfigAlert = getButtonsConfigAlert(
    () => handleCloseDialog("isDeleteOpen"),
    onDelete,
  );

  let colorIndex = 0;

  const gettabledataWithColor = (index: number) => {
    colorIndex = (index + 1) % colors.length;
    return colors[colorIndex] ? colors[colorIndex] : colors[1];
  };

  return (
    <>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              {header?.map((column, index) => (
                <StyledTableCell
                  sx={{ textTransform: "uppercase" }}
                  key={index}
                >
                  {column?.title}
                </StyledTableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {data?.map((row, rowIndex) => {
              return (
                <TableRow key={rowIndex}>
                  {header.map((column, columnIndex) => {
                    if (columnIndex === 0) {
                      return (
                        <StyledTableCellBody key={columnIndex}>
                          <NameCellContainer>
                            {row[column?.key]}
                            <StyledIconButton
                              aria-controls="context-menu"
                              aria-haspopup="true"
                              onClick={(e) => handleClick(e, row)}
                            >
                              <VerticleDots />
                            </StyledIconButton>
                          </NameCellContainer>
                        </StyledTableCellBody>
                      );
                    } else if (Array.isArray(row[column?.key])) {
                      return (
                        <StyledTableCellBody key={columnIndex}>
                          <TagsWrapper>
                            {row[column?.key].map(
                              (item: string, index: number) => (
                                <Chip
                                  key={item + index}
                                  label={item}
                                  sx={{
                                    background: gettabledataWithColor(index),
                                  }}
                                />
                              ),
                            )}
                          </TagsWrapper>
                        </StyledTableCellBody>
                      );
                    } else {
                      return (
                        <StyledTableCellBody key={columnIndex}>
                          {row[column?.key]}
                        </StyledTableCellBody>
                      );
                    }
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <StyledMenu
          id="context-menu"
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleClose}
          disableScrollLock
        >
          <MenuItem onClick={() => handleOpenDialog("isEditOpen")}>
            Edit
          </MenuItem>
          <MenuItem onClick={() => handleOpenDialog("isDeleteOpen")}>
            Delete
          </MenuItem>
        </StyledMenu>
      </TableContainer>
      <LeadModal
        defaultData={defaultData}
        isEdit
        open={dialogState?.isEditOpen}
        closeModal={() => handleCloseDialog("isEditOpen")}
        title="Edit search"
        saveSearchData={undefined}
        totalCount={""}
      />
      <AlertPoPup
        heading="Delete list search"
        subheading="Are you sure you want to delete this list search?"
        open={dialogState?.isDeleteOpen}
        onclose={() => handleCloseDialog("isDeleteOpen")}
        ButtonConfig={buttonsConfigAlert}
      />
    </>
  );
};

export default SavedListTable;
