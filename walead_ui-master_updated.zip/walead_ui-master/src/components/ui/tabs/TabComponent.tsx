import React, { useState } from "react";
import styled from "@emotion/styled";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import {
  darkblueColor,
  darkCharcoalColor,
  guttersPx,
  lightBlueColor,
} from "@/styles/variables";

interface TabItem {
  label: string;
  icon?: any;
  content?: React.ReactNode;
  child?: TabItem[];
}

interface CommonTabProps {
  tabs: TabItem[];
  defaultTab?: number;
  onChange?: (activeTab: number) => void;
}

interface StyledTabProps {
  orientation?: "horizontal" | "vertical";
}

const HorizontalTabs = styled(Tabs)<StyledTabProps>`
  border-bottom: 2px solid #d8d8d8;
  margin-bottom: 50px;
`;

const VerticalTabs = styled(Tabs)<StyledTabProps>`
  display: ${({ orientation }) =>
    orientation === "vertical" ? "flex" : "none"};
  flex-direction: column;
  width: 100%;
  max-width: 300px;
  button {
    justify-content: start;
  }
  .MuiTabs-indicator {
    display: none !important;
  }
  .MuiTabs-flexContainer {
    gap: ${guttersPx.small};
  }
`;

const StyledTab = styled(Tab)`
  cursor: pointer;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: ${guttersPx.smallHalf};
  &:hover {
    color: #3498db;
  }
`;

const TabContent = styled.div`
  padding: 0 ${guttersPx.small};
  width: 100%;
`;

const TabContentWrapper = styled.div`
  display: flex;
  gap: ${guttersPx.large};
`;

const TabComponent: React.FC<CommonTabProps> = ({
  tabs,
  defaultTab = 0,
  onChange,
}) => {
  const [activeHorizontalTab, setActiveHorizontalTab] = useState(defaultTab);
  const [activeVerticalTab, setActiveVerticalTab] = useState(0);

  const handleHorizontalTabChange = (
    _event: React.SyntheticEvent,
    newValue: number,
  ) => {
    setActiveHorizontalTab(newValue);
    setActiveVerticalTab(0);
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleVerticalTabChange = (
    _event: React.SyntheticEvent,
    newValue: number,
  ) => {
    setActiveVerticalTab(newValue);
  };

  return (
    <div>
      <HorizontalTabs
        value={activeHorizontalTab}
        onChange={handleHorizontalTabChange}
        indicatorColor="primary"
        textColor="primary"
      >
        {tabs?.map((tab, index) => (
          <StyledTab
            sx={horizontaltabStyle}
            key={index}
            label={tab.label}
            disableRipple
            icon={tab.icon}
            iconPosition="start"
          />
        ))}
      </HorizontalTabs>
      <TabContentWrapper>
        {tabs[activeHorizontalTab]?.child && (
          <VerticalTabs
            value={activeVerticalTab}
            onChange={handleVerticalTabChange}
            orientation="vertical"
          >
            {tabs[activeHorizontalTab]?.child?.map((verticalTab, index) => (
              <StyledTab
                sx={verticaltabStyle}
                key={index}
                disableRipple
                label={verticalTab.label}
                icon={verticalTab.icon}
                iconPosition="start"
              />
            ))}
          </VerticalTabs>
        )}
        <TabContent>
          {tabs[activeHorizontalTab]?.child?.[activeVerticalTab]?.content ||
            tabs[activeHorizontalTab]?.content}
        </TabContent>
      </TabContentWrapper>
    </div>
  );
};

export default TabComponent;

const commonTabStyle = {
  color: `${darkCharcoalColor} !important`,
  fontFamily: "Montserrat",
  fontSize: "16px",
  fontWeight: `${600} !important`,
};

const verticaltabStyle = {
  "&.Mui-selected": {
    backgroundColor: lightBlueColor,
    color: `${darkCharcoalColor} !important`,
  },
  borderRadius: "5px",
  minHeight: "45px",
  height: "45px",
  ...commonTabStyle,
};

const horizontaltabStyle = {
  "&.Mui-selected": {
    color: `${darkblueColor} !important`,
  },
  ...commonTabStyle,
};
