import styled from "@emotion/styled";
import React from "react";
import {
  borderRadiusBig,
  buttonCursor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightGreyColor,
  lightVoilet,
  whiteColor,
} from "@/styles/variables";
import AcceleratorCardSkeleton from "../loader/AcceleratorSkeletors/AcceleratorCardSkeleton";
import StarRating from "../input/StarRating";
import Image from "next/image";
import ProgressBar from "../input/ProgressBar";
import { DetailsProps } from "@/app/(dashboard)/accelerator/page";
import { css } from "@emotion/react";
import {
  formatNumberToDecimalPlaces,
  truncateWords,
} from "@/utils/helperUtils";
import {
  typographySubtitle1,
  typographySubtitle2Normal,
} from "@/styles/typography";
import { imageLoader } from "@/shared/UserMenu/SharedUserMenuComponents";
import ImageComponent from "../image/Image";

interface TextProps {
  primary?: boolean;
}

const CardContainer = styled.div<{
  isHighlight: boolean;
}>(
  ({ isHighlight }) => css`
    flex: 0 0 calc(25% - ${guttersPx.medium});
    border-radius: ${borderRadiusBig};
    border: 1px solid ${isHighlight ? lightVoilet : lightGreyColor};
    background: ${isHighlight ? "rgba(177, 108, 234, 0.50)" : whiteColor};
    box-shadow: 0px 1px 1px 0px rgba(0, 0, 0, 0.25);
    display: grid;
    place-items: center;
    cursor: ${buttonCursor};
    margin: ${guttersPx.medium} 0;
    padding: ${guttersPx.medium} ${guttersPx.mediumHalf};
    position: relative;
  `,
);

const Text = styled.div<TextProps>`
  color: ${darkCharcoalColor};
  text-align: center;
  font-weight: 500;
  font-size: 18px;
  margin: ${guttersPx.smallHalf} 0;
  word-wrap: break-word;
`;

const Description = styled.div<{
  isHighlighted: boolean;
}>(
  ({ isHighlighted }) => css`
    ${typographySubtitle2Normal};
    color: ${isHighlighted ? darkCharcoalColor : greyColor};
    text-align: center;
    word-wrap: break-word;
    margin-bottom: ${guttersPx.smallHalf};
  `,
);

export const FlexCards = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: streched;
  justify-content: start;
  gap: ${guttersPx.medium};
  padding-left: ${guttersPx.medium};
`;
const ImageWrapper = styled.div`
  width: 100%;
`;

const ProgressContainer = styled.div`
  padding: 0px ${guttersPx.mediumHalf} 0 ${guttersPx.mediumHalf};
  width: 100%;
  progress {
    width: 100%;
  }
`;

const HighLightIconWrapper = styled.div`
  position: absolute;
  right: ${guttersPx.mediumHalf};
  bottom: ${guttersPx.mediumHalf};
`;
const AccleraterTitle = styled.h1`
  text-align: center;
  ${typographySubtitle1};
  padding: 0 ${guttersPx.smallHalf};
  margin-top: ${guttersPx.mediumHalf};
`;
const AcceleratorCard: React.FC<{
  setOpen: () => void;
  setDetails: (arg: DetailsProps) => void;
  loading: boolean;
  data: any[];
}> = ({ setOpen, data = [], setDetails, loading }) => {
  const handleDetail = (item: { id: string; name: string }) => {
    setOpen();
    setDetails(item);
  };
  const getHighlightedColor = (isHighlight: boolean) => {
    if (isHighlight) {
      return lightVoilet;
    }
  };

  return (
    <>
      <FlexCards>
        {loading
          ? Array?.from({ length: 4 })?.map((_, index) => (
              <AcceleratorCardSkeleton key={index} />
            ))
          : data?.map((item) => {
              const color = getHighlightedColor(item.highlight);
              const totoalAvgProgress = formatNumberToDecimalPlaces(
                item?.avgProgress,
                2,
              );

              return (
                <CardContainer
                  isHighlight={item.highlight}
                  key={item?.id}
                  onClick={() => {
                    handleDetail(item);
                  }}
                >
                  {item?.img && (
                    <ImageWrapper>
                      <ImageComponent
                        src={item.img}
                        loader={imageLoader}
                        width={93}
                        style={{ width: "100%" }}
                        height={150}
                        alt={item?.name}
                      />
                    </ImageWrapper>
                  )}
                  <AccleraterTitle>
                    {truncateWords(item.name, 25)}
                  </AccleraterTitle>
                  <ProgressContainer>
                    <ProgressBar
                      value={totoalAvgProgress}
                      loading={false}
                      color={color}
                    />
                  </ProgressContainer>
                  <Description isHighlighted={item.highlight}>
                    {truncateWords(item?.description, 80)}
                  </Description>
                  <StarRating
                    initalValue={Number(item?.avgRating)}
                    isLabel
                    readonly
                    size={24}
                    color={color}
                  />
                  <Text primary as="div">
                    by {item?.createdBy?.email}
                  </Text>
                  {item.highlight && (
                    <HighLightIconWrapper>
                      <Image
                        src="/assets/images/fire.png"
                        alt="highlighted"
                        width={36}
                        height={36}
                      />
                    </HighLightIconWrapper>
                  )}
                </CardContainer>
              );
            })}
      </FlexCards>
    </>
  );
};

export default AcceleratorCard;
