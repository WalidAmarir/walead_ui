import {
  LeftArrow,
  RoundedChechMark,
} from "@/utils/formUtils/InputSvg/InputSvg";
import styled from "@emotion/styled";
import React, { useEffect, useMemo, useState } from "react";
import {
  borderRadiusLarger,
  darkCharcoalColor,
  darkblueColor,
  fontFamily,
  placeholderColor,
  guttersPx,
} from "@/styles/variables";
import { typographyH3, typographyParagraph } from "@/styles/typography";
import PopupCardSkeleton from "../loader/AcceleratorSkeletors/PopupCardSkeleton";
import StartModal from "../modal/acceleratorModals/StartModal";
import { useLazyQuery, useMutation } from "@apollo/client";
import { GET_COURSES } from "@/lib/graphql/queries/getCourses";
import { StaticImport } from "next/dist/shared/lib/get-img-props";
import { FlexCards } from "./AcceleratorCard";
import IframeComponent from "../iframe/IframeComponent";
import { DetailsProps } from "@/app/(dashboard)/accelerator/page";
import Checkbox from "@mui/material/Checkbox";
import { ACCELERETOT_PROGRESS } from "@/lib/graphql/mutation/acceleratorProgress";
const Container = styled.div``;

const commonTextStyles = `
  color: ${darkCharcoalColor};
  font-family: ${fontFamily};
`;

const commonCardStyles = `
  border: 1px solid ${placeholderColor};
  border-radius: ${borderRadiusLarger};
  position: relative;
  z-index: 0;
`;

const StartArrow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: baseline;
  cursor: pointer;
  width: fit-content;
  margin-bottom: ${guttersPx.extraLarge};
`;

const StartText = styled.div`
  ${commonTextStyles}
  ${typographyH3}
`;

const CardContainer = styled.div`
  padding: 20px;
  cursor: pointer;
`;
const CardWrapper = styled.div`
  position: relative;
  width: 251px;
  ${commonCardStyles};
`;

const CardHeader = styled.div`
  ${typographyParagraph}
  color:  ${darkblueColor};
  margin-bottom: 25px;
`;

const ImageContainer = styled.div`
  width: 100%;
`;

const GreenTickAvatar = styled.div`
  position: absolute;
  top: -15px;
  right: -35px;
`;

const PopupCard: React.FC<{
  setOpen: () => void;
  updateRating: (arg: string, arg1: string) => void;
  details: DetailsProps;
}> = ({ setOpen, updateRating, details }) => {
  const [popOpen, setPopOpen] = useState(false);
  const [currentId, setCurrentID] = useState<string>("");
  const [handleLazy, { data, loading, refetch: courseRefetch }] = useLazyQuery(
    GET_COURSES,
    {
      fetchPolicy: "network-only",
    },
  );
  const [handleUpdateProgress] = useMutation(ACCELERETOT_PROGRESS, {
    onCompleted: courseRefetch,
  });

  const openDetails = (id: string) => {
    setCurrentID(id);
    setPopOpen(true);
  };
  const oncloseDetails = () => {
    setPopOpen(false);
  };
  useEffect(() => {
    handleLazy({ variables: { coursesId: details?.id } });
  }, [details?.id]);

  const filteredData = useMemo(() => {
    const { courses } = data ?? {};
    const filterValue = courses?.edges?.map(({ node }: { node: any }) => ({
      ...node,
    }));
    return filterValue ?? [];
  }, [data]);

  const handleUpdateCourse = async (id: string, value: boolean) => {
    try {
      const { data: updateres } = await handleUpdateProgress({
        variables: {
          input: {
            course: id,
            progress: value,
            accelerator: details?.id,
          },
        },
      });
      if (updateres?.updateCourse) {
        setPopOpen(false);
        return updateres.updateCourse;
      }
      return null;
    } catch (err) {
      return err;
    }
  };

  return (
    <Container>
      <StartModal
        data={filteredData}
        closeHandler={oncloseDetails}
        open={popOpen}
        onUpdate={handleUpdateCourse}
        currentId={currentId}
        acceleratorValues={details}
        updateRating={updateRating}
        setOpen={setOpen}
      />
      <StartArrow onClick={setOpen}>
        <LeftArrow />
        <StartText>{details?.name}</StartText>
      </StartArrow>

      {loading ? (
        <PopupCardSkeleton />
      ) : (
        <FlexCards>
          {filteredData?.map(
            (
              item: {
                progress: boolean;
                type: string;
                link: string;
                id: string;
                title: string;
                img: string | StaticImport;
                accelerator: { img: string };
              },
              index: number,
            ) => {
              return (
                <CardWrapper key={item?.id}>
                  <CardContainer
                    onClick={() => {
                      openDetails(item.id);
                    }}
                  >
                    <CardHeader>
                      {index + 1}. {item?.title}
                    </CardHeader>
                    <ImageContainer>
                      <IframeComponent
                        url={item?.link}
                        type={item.type}
                        width="100%"
                        height="200px"
                        isSingle
                      />
                    </ImageContainer>
                  </CardContainer>
                  <GreenTickAvatar>
                    <CircularCheckboxComponent
                      courseid={item?.id}
                      status={item.progress}
                      onChange={handleUpdateCourse}
                    />
                  </GreenTickAvatar>
                </CardWrapper>
              );
            },
          )}
        </FlexCards>
      )}
    </Container>
  );
};

export default PopupCard;

// Main Checkbox component
const CircularCheckboxComponent = ({
  courseid,
  status,
  onChange,
}: {
  courseid: string;
  status: boolean;
  onChange: (id: string, value: boolean) => void;
}) => {
  const [isChecked, setChecked] = useState(false);

  const handleCheckboxChange = (e: { target: { checked: boolean } }) => {
    const { checked } = e.target;
    setChecked(!isChecked);
    if (onChange) {
      onChange(courseid, checked);
    }
  };

  return (
    <>
      <Checkbox
        onChange={handleCheckboxChange}
        disableRipple
        checked={status}
        icon={<RoundedChechMark opacity={0.3} />}
        checkedIcon={<RoundedChechMark />}
      />
    </>
  );
};
