import React from "react";
import Image from "next/image";
import styled from "@emotion/styled";
import {
  whiteColor,
  darkCharcoalColor,
  greyColor,
  buttonCursor,
  guttersPx,
  fontFamily,
  fullWidth,
  aquamarineColor,
} from "@/styles/variables";
import {
  typographyCaptionNormal,
  typographyCaptionSmall,
  typographySubtitle3,
} from "@/styles/typography";
import {
  RocketSGV,
  DraftSGV,
  HasPDFSGV,
  PersonSGV,
  LinkedinRounded,
  Clock,
  CommentIcon,
} from "@/utils/formUtils/InputSvg/InputSvg";
import CustomTooltip from "../tooltip/CustomTooltip";
import { getPostStatus, truncateWords } from "@/utils/helperUtils";
import { RenderHTML } from "../HtmlRenderer/RenderHTML";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { css } from "@emotion/react";
import dayjs from "dayjs";
import { SchedulePostProp } from "@/types/global";

const CardContainer = styled.div<{
  isMargin: boolean;
}>(
  ({ isMargin }) => css`
    border-radius: 5px;
    background: ${whiteColor};
    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);
    margin: 1rem ${!isMargin ? "auto" : 0};
    display: block;
    padding: ${guttersPx.small};
    max-width: 200px;
    cursor: ${buttonCursor};
    &:hover {
      box-shadow: -2px 1px 4px 0px rgba(0, 0, 0, 0.25);
    }
  `,
);

const FlexContainer = styled.div`
  display: flex;
  align-items: center;
  padding: 6px 0;
  gap: ${guttersPx.smallHalf};
`;

const Time = styled.div`
  color: ${greyColor};
  ${typographyCaptionSmall};
  font-family: ${fontFamily};
`;

const Name = styled.h1`
  color: ${darkCharcoalColor};
  ${typographyCaptionNormal};
`;

const LinkedInSvg = styled.span`
  width: 19px;
  height: 20px;
`;

const StyledImage = styled(Image)`
  width: ${fullWidth};
  height: auto;
  max-height: 60px;
  object-fit: cover;
`;

const CardIconWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  padding-top: ${guttersPx.smallHalf};
`;
const Lefticons = styled.div`
  display: flex;
  align-items: center;
  gap: 2px;
`;
const Righticons = styled.div`
  color: ${aquamarineColor};
  ${typographySubtitle3};
  display: flex;
  align-items: center;
  gap: 2px;
`;
const SchedulePostCard = ({
  data,
  onClick,
  onDeleteDeal,
}: {
  data?: any;
  onClick?: () => void;
  onDeleteDeal?: (event: any, data: SchedulePostProp) => void;
}) => {
  const { isDraft, isPublished, isScheduled } = getPostStatus(data);
  const { calenderType } = useScheduledContext();
  const dateString = data?.displayDate;
  const parsedDate = dayjs(dateString);
  const timeString = parsedDate.format("HH:mm");
  const onDealDelete = (event: any) => {
    if (onDeleteDeal) {
      onDeleteDeal(event, data);
    }
  };
  return (
    <CardContainer onClick={onClick} isMargin={calenderType === "daily"}>
      <FlexContainer>
        <LinkedInSvg>
          <LinkedinRounded />
        </LinkedInSvg>
        <Name>{data?.createdFor?.fullName}</Name>
      </FlexContainer>
      <FlexContainer>
        <Clock />
        <Time>{timeString}</Time>
      </FlexContainer>
      {data?.img?.length !== 0 && (
        <StyledImage
          src={data?.img[0] || ""}
          width={125}
          height={60}
          alt="Schedule Card"
          unoptimized
        />
      )}
      {data?.content && <RenderHTML html={truncateWords(data?.content, 60)} />}
      <CardIconWrapper>
        <Lefticons>
          {isPublished && <RocketSGV />}
          {isDraft && (
            <CustomTooltip title="Draft" placement="bottom">
              <DraftSGV />
            </CustomTooltip>
          )}
          {isScheduled && (
            <FlexContainer>
              <CustomTooltip title="Schedule" placement="bottom">
                <HasPDFSGV />
              </CustomTooltip>
              {data?.commentId && (
                <CustomTooltip title="Comment" placement="bottom">
                  <CommentIcon color="#64C7B0" width="20" height="20" />
                </CustomTooltip>
              )}
            </FlexContainer>
          )}
        </Lefticons>
        {data?.dealMember?.length > 0 && (
          <Righticons onClick={onDealDelete}>
            {data?.dealMember?.length}
            <CustomTooltip title="Leads Post" placement="bottom">
              <PersonSGV />
            </CustomTooltip>
          </Righticons>
        )}
      </CardIconWrapper>
    </CardContainer>
  );
};

export default SchedulePostCard;
