import React from "react";
import styled from "@emotion/styled";
import CommonAvatar from "./CommonAvatar";

const AvatarContainer = styled.label`
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
`;

const HiddenRadio = styled.input`
  position: absolute;
  opacity: 0;
  pointer-events: none;
`;

interface SelectableAvatarProps {
  name: string;
  background: string;
  value?: string;
  profilePicture?: string;
  selected?: boolean;
  onChange: any;
  avatarText?: string;
  dimension: string;
  imgDimension: number;
}

const SingleSelectableAvatar: React.FC<SelectableAvatarProps> = ({
  name,
  background,
  value,
  profilePicture,
  selected = false,
  avatarText,
  onChange,
  dimension,
  imgDimension,
}) => {
  return (
    <AvatarContainer>
      <HiddenRadio
        name={name}
        type="radio"
        value={value}
        checked={selected}
        onChange={onChange}
      />
      <CommonAvatar
        selected={selected}
        avatarText={avatarText}
        alt={name}
        bgColor={background}
        imgDimension={imgDimension.toString()}
        src={profilePicture}
        dimension={dimension}
      />
    </AvatarContainer>
  );
};

export default SingleSelectableAvatar;
