import React from "react";
import styled from "@emotion/styled";
import { SmallAvatar } from "./Avatar";
import { darkblueColor } from "@/styles/variables";

const AvatarContainer = styled.div``;

interface CommonAvatarProps {
  alt: string;
  src?: string | null;
  dimension: string;
  bgColor?: string;
  selected?: boolean;
  avatarText?: string;
  imgDimension: string;
  size?: string;
}

const CommonAvatar: React.FC<CommonAvatarProps> = ({
  alt,
  src,
  dimension = "32",
  bgColor = darkblueColor,
  selected = false,
  avatarText,
  imgDimension,
  size = "7",
}) => {
  const background = src ? "transparent" : bgColor;
  return (
    <AvatarContainer>
      {src ? (
        <SmallAvatar
          alt={alt}
          src={src}
          dimension={imgDimension}
          bgColor={background}
          checked={selected}
          isCollapse={false}
        />
      ) : (
        <SmallAvatar
          alt={alt}
          dimension={dimension}
          bgColor={background}
          checked={selected}
          isCollapse={false}
          size={size}
        >
          {avatarText}
        </SmallAvatar>
      )}
    </AvatarContainer>
  );
};

export default CommonAvatar;
