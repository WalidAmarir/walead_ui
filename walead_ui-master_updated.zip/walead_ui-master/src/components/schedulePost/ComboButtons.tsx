import React from "react";
import styled from "@emotion/styled";
import {
  buttonCursor,
  fontFamily,
  errorPixel,
  guttersPx,
  darkCharcoalColor,
} from "@/styles/variables";
interface ButtonConfig {
  backgroundColor?: string;
  color: string;
  outline: boolean;
  buttonText: string;
  Icon?: React.ReactElement;
  onclick?: () => void;
  isHide?: boolean;
  outlineColor?: string;
  buttonIcon?: React.ReactElement;
}

interface ButtonsProps {
  buttons: ButtonConfig[];
}

const ButtonsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: ${guttersPx.smallHalf};
`;

const getOutlineColor = (isOutline: boolean, color: string = "black") => {
  if (isOutline) {
    return `1px solid ${color}`;
  }
  return "none";
};

const Button = styled.button<ButtonConfig>`
  background-color: ${(props) => props.backgroundColor};
  color: ${(props) => props.color};
  outline: ${(props) => getOutlineColor(props.outline, props.outlineColor)};
  border: none;
  padding: ${guttersPx.smallHalf};
  display: ${(props) => (props.isHide ? "none" : "flex")};
  align-items: center;
  justify-content: center;
  ${guttersPx.small};
  margin: 5px;
  cursor: ${buttonCursor};
  height: 36px;
  border-radius: 5px;
  text-align: center;
  font-family: ${fontFamily};
  font-size: ${errorPixel};
  font-weight: 800;
  width: 94px;
`;
const IconDiv = styled.div<ButtonConfig>`
  display: ${(props) => (props.isHide ? "none" : "block")};
  cursor: pointer;
`;
const ComboButtons: React.FC<ButtonsProps> = ({ buttons }) => {
  const renderButtons = () => {
    return buttons.map((button, index) =>
      !button.Icon ? (
        <Button
          key={index}
          {...button}
          isHide={button.isHide}
          onClick={button.onclick}
          outlineColor={button?.outlineColor || darkCharcoalColor}
        >
          {button.buttonText}
          <ButtonIcon icon={button?.buttonIcon} />
        </Button>
      ) : (
        <IconDiv
          key={index}
          {...button}
          isHide={button.isHide}
          onClick={button.onclick}
        >
          {button.Icon}
        </IconDiv>
      ),
    );
  };

  return <ButtonsContainer>{renderButtons()}</ButtonsContainer>;
};

export default ComboButtons;

const ButtonIcon = ({ icon }: { icon?: React.ReactElement }) => {
  if (icon) {
    return icon;
  }
  return null;
};
