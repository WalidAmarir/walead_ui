import { typographyH3 } from "@/styles/typography";
import { darkCharcoalColor } from "@/styles/variables";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import Skeletor from "../ui/skeletor/Skeletor";

const Heading = styled.h3<{
  color: string;
}>(
  ({ color }) => css`
    ${typographyH3};
    color: ${color};
  `,
);

const ModalHeading = ({
  heading,
  headingColor = darkCharcoalColor,
}: {
  heading?: string;
  headingColor?: string;
}) => {
  return !heading ? (
    <Skeletor variant="text" sx={{ fontSize: "25px" }} width={400} />
  ) : (
    <Heading color={headingColor}>{heading}</Heading>
  );
};

export default ModalHeading;
