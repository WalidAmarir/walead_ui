import { useQueryContext } from "@/context/query/queryContext";
import CalenderContextProvider from "@/context/schedule/CalenderContextProvider";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import DailyCalender from "@/layouts/schedulePostLayouts/calenders/DailyCalender";
import MonthlyCalender from "@/layouts/schedulePostLayouts/calenders/MonthlyCalender";
import WeeklyCalender from "@/layouts/schedulePostLayouts/calenders/WeeklyCalender";
import { UPDATE_POST_BY_ID } from "@/lib/graphql/mutation/upadatePostById";
import { gutters } from "@/styles/variables";
import { SchedulePostProp } from "@/types/global";
import { calenderName } from "@/utils/constant";
import { formatGMTDate } from "@/utils/helperUtils";
import { useMutation } from "@apollo/client";
import styled from "@emotion/styled";
import { Backdrop, CircularProgress } from "@mui/material";
import dynamic from "next/dynamic";
import React, { useEffect, useMemo } from "react";
const CalenderHeader = dynamic(
  () => import("@/layouts/schedulePostLayouts/CalenderHeader"),
  {
    loading: () => <p>Loading...</p>,
  },
);

const ScheduleCalender = () => {
  const { calenderType, refetch, isLoader } = useScheduledContext();
  const { membersRefecth } = useQueryContext();
  const [handleUpdatePost] = useMutation(UPDATE_POST_BY_ID, {
    onCompleted: refetch,
  });

  useEffect(() => {
    membersRefecth();
  }, []);

  const handleUpdate = async (
    date: string,
    id: string,
    filteredData: SchedulePostProp,
  ) => {
    const formattedDate = formatGMTDate(date);
    const filterItem = filteredData?.find((item: { id: string }) => {
      return item.id === id;
    });
    const key =
      filterItem?.status === "Drafts" ? "draftPosttDate" : "schedulePostDate";
    try {
      await handleUpdatePost({
        variables: {
          input: {
            id: id,
            [key]: formattedDate?.toString(),
            status: filterItem.status,
          },
        },
      });
    } catch (err: any) {
      return err.message;
    }
  };

  const getCalender = useMemo(() => {
    let CalenderComponent: any;
    switch (calenderType) {
      case calenderName.Daily:
        CalenderComponent = DailyCalender;
        break;
      case calenderName.Weekly:
        CalenderComponent = WeeklyCalender;
        break;
      case calenderName.Monthly:
        CalenderComponent = MonthlyCalender;
        break;
      default:
        CalenderComponent = null;
    }

    return CalenderComponent ? (
      <CalenderComponent handleUpdate={handleUpdate} />
    ) : null;
  }, [calenderType]);

  return (
    <CalenderContextProvider>
      <CalenderHeader />
      <CalenderWrapper>{getCalender}</CalenderWrapper>
      <Backdrop sx={{ color: "#fff", zIndex: 1400 }} open={isLoader}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </CalenderContextProvider>
  );
};

export default ScheduleCalender;

const CalenderWrapper = styled.div`
  margin: ${gutters.medium * 2}px 0;
`;
