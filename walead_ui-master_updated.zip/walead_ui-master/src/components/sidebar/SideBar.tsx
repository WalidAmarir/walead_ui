import React from "react";

const SideBar = () => {
  return <div>SideBar</div>;
};

export default SideBar;
