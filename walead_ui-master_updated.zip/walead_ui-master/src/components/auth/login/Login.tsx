import React, { useEffect, useState } from "react";
import styled from "@emotion/styled";
import Card from "../../ui/CardContainer/Card";
import InputBox from "../../ui/input/InputBox";
import Checkbox from "../../ui/Checkbox/CheckBox";
import { Button, cardStyle } from "@/styles/base";
import LinkedinLogin from "./LinkedinLogin/LinkedinLogin";
import { useLazyQuery } from "@apollo/client";
import { LOGIN } from "@/lib/graphql/queries/loginForm";
import { useRouter } from "next/navigation";
import {
  loginCardMaxWidth,
  darkCharcoalColor,
  gutters,
  whiteColor,
  greyColor,
  fontSizeCaption,
  maxWidthOfMaxWidth,
  gapOfLinkWrapper,
} from "@/styles/variables";
import { loinAndSignUpVariable } from "@/utils/constant";
import { typographyCaptionSmall, typographyH2 } from "@/styles/typography";
import { LoginKeys } from "@/types/user";
import { errorToast, successToast } from "@/styles/toaster";
import { loginSchema } from "@/utils/formUtils/validations/ValidationUtils";
import { useFormik } from "formik";
import { useAuth } from "@/context/auth/authContext";
import { getCookie, setCookie } from "@/utils/cookiesUtils";
import { getBtnState, isBrowser } from "@/utils/helperUtils";

const { loginSuccessful, email, password, Email, Password } =
  loinAndSignUpVariable;
export interface ItemValue {
  name: keyof LoginKeys; // Use keyof LoginInput to ensure type safety
  label: string;
  placeholder: string;
  type: string;
}

const Login: React.FC = () => {
  const router = useRouter();
  const { authenticateUser, handleDealdata } = useAuth();

  const [login, { loading }] = useLazyQuery(LOGIN);

  const [initialValues, setInitialValues] = useState({
    email: "",
    password: "",
    remember: false,
  });

  useEffect(() => {
    if (isBrowser) {
      const cookies = getCookie("remember");
      const cookieValue = cookies ? JSON.parse(cookies) : {};
      if (cookieValue.email && cookieValue.password) {
        initialValues.email = cookieValue.email;
        initialValues.password = cookieValue.password;
        setInitialValues({ ...initialValues });
      }
    }
  }, []);

  const { errors, values, handleChange, handleSubmit } = useFormik({
    initialValues: initialValues,
    validationSchema: loginSchema,
    enableReinitialize: true,
    onSubmit: async () => {
      const { data, error: loginErr } = await login({
        variables: { email: values.email, password: values.password },
      });
      if (loginErr) {
        errorToast(loginErr?.message);
      }
      if (data?.login) {
        authenticateUser(data?.login?.token?.token);
        successToast(loginSuccessful);
        if (values.remember) {
          setCookie("remember", JSON.stringify(values), 7);
        }
        const { data: dealdata } = await handleDealdata();
        if (dealdata?.getUserDetailsById) {
          const isEmpty = dealdata?.getUserDetailsById?.dealCount === "0";
          return router.push(isEmpty ? "/deals" : "/dashboard");
        }
      }
    },
  });
  return (
    <>
      <Card maxWidth={loginCardMaxWidth}>
        <LoginWrapper>
          <LoginTitle>Log in</LoginTitle>
          <Form onSubmit={handleSubmit}>
            {LoginFields.map((item, key) => (
              <React.Fragment key={key}>
                <InputBox
                  key={item.name}
                  type={item.type}
                  placeholder={item.placeholder}
                  name={item.name}
                  value={values[item.name]}
                  onChange={handleChange}
                  autocomplete="off"
                  error={errors[item.name]}
                />
              </React.Fragment>
            ))}
            <ButtonWrapper>
              <Button disabled={loading} type="submit">
                {getBtnState("Log in", loading)}
              </Button>
            </ButtonWrapper>
            <Checkbox
              name="remember"
              checked={values.remember}
              handleChange={handleChange}
            >
              <CheckboxText>Remember me</CheckboxText>
            </Checkbox>
          </Form>
        </LoginWrapper>
        <LinkedinLogin />
      </Card>
      <LinkWrapper>
        <LinkTo href="/signup">Don&apos;t have an account? </LinkTo>
        <LinkTo href="/forgotpassword">Forgot your password?</LinkTo>
      </LinkWrapper>
    </>
  );
};

const LoginTitle = styled.h2`
  ${typographyH2};
  color: ${darkCharcoalColor};
  text-align: center;
`;

const LoginWrapper = styled.div`
  ${cardStyle};
  background: ${whiteColor};
`;

const Form = styled.form`
  padding: ${gutters.large}px 0;
`;

const ButtonWrapper = styled.div`
  padding: ${gutters.small}px 0;
`;

const CheckboxText = styled.h1`
  ${typographyCaptionSmall};
  line-height: normal;
  color: ${greyColor};
`;

const LinkWrapper = styled.div`
  max-width: ${maxWidthOfMaxWidth};
  margin: ${gutters.large}px auto;
  color: ${darkCharcoalColor};
  font-size: ${fontSizeCaption};
  display: flex;
  justify-content: center;
  align-items: center;
  gap: ${gapOfLinkWrapper};
`;

const LinkTo = styled(Button)`
  text-align: center;
`;

const LoginFields: ItemValue[] = [
  {
    name: email,
    label: Email,
    placeholder: Email,
    type: email,
  },
  {
    name: password,
    label: Password,
    placeholder: Password,
    type: password,
  },
];
export default Login;
