import {
  typographyParagraph,
  typographySubtitle1,
  typographySubtitle2Normal,
} from "@/styles/typography";
import {
  darkCharcoalColor,
  fontSizeBody1,
  greyColor,
  guttersPx,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import styled from "@emotion/styled";
import React, { useState } from "react";
import Button from "../ui/button/Button";
import SelectBox from "../ui/selectBox/SelectBox";
import { User, Role } from "@/types/global";
import { useMutation } from "@apollo/client";
import { UPDATE_TEAM_MEMBER_ROLE } from "@/lib/graphql/mutation/updateTeamMemberRoleId";
import { errorToast, successToast } from "@/styles/toaster";

const TeamMembersCard = ({
  item,
  data = [],
  onclick,
}: {
  item: User;
  data: Role[];
  onclick: (arg: User) => void;
}) => {
  const [selectValue, setSelectValue] = useState(item?.role.id);
  const [handleUpdate] = useMutation(UPDATE_TEAM_MEMBER_ROLE, {
    onCompleted: (response) => {
      successToast(response?.updateTeamMemberRole);
    },
    onError: (err) => {
      errorToast(err?.message);
    },
  });
  const handleSelect = (event: any) => {
    const { value } = event.target;
    setSelectValue(value);
    handleUpdate({
      variables: {
        role: value,
        updateTeamMemberRoleId: item.id,
      },
    });
  };
  return (
    <CardWrapper key={item.id}>
      <Details>
        <Title>{item?.fullName}</Title>
        <Email>{item?.email}</Email>
      </Details>
      {item?.role.role === "Owner" ? (
        <TypeText>{item?.role.role}</TypeText>
      ) : (
        <TypeActionWrapper>
          <SelectBox
            name={"role"}
            options={data?.map((role: { id: string; role: string }) => ({
              value: role.id,
              label: role.role,
            }))}
            value={selectValue}
            onChange={handleSelect}
          />
          <DeleteBtn
            onClick={() => onclick(item)}
            height="37px"
            width="auto"
            bgColor="transparent"
            color={lightRedColor}
          >
            Delete
          </DeleteBtn>
        </TypeActionWrapper>
      )}
    </CardWrapper>
  );
};

export default TeamMembersCard;

const CardWrapper = styled.div`
  border-radius: 2px;
  border: 1px solid ${greyColor};
  background: ${whiteColor};
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${guttersPx.large};
  padding: ${guttersPx.large} ${guttersPx.small};
  height: 85px;
`;
const Details = styled.div``;

const Title = styled.h1`
  color: ${darkCharcoalColor};
  ${typographySubtitle1};
  margin-bottom: ${guttersPx.mediumHalf};
`;

const Email = styled.div`
  color: ${greyColor};
  ${typographySubtitle2Normal}
`;

const TypeText = styled.h1`
  color: ${greyColor};
  ${typographyParagraph}
`;

const TypeActionWrapper = styled.div`
  display: flex;
  gap: ${guttersPx.small};
  align-items: center;
  .MuiFormControl-root {
    height: 39px !important;
    min-width: 133px;
  }
`;

const DeleteBtn = styled(Button)`
  box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.25);
  border: 1px solid ${lightRedColor};
  font-size: ${fontSizeBody1};
`;
