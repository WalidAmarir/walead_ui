import {
  typographyCaptionbold,
  typographyParagraph,
} from "@/styles/typography";
import {
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import { truncateWords, userData } from "@/utils/helperUtils";
import styled from "@emotion/styled";
import React from "react";
import AvatarUI from "../ui/avatar/Avatar";

interface CardProp {
  isConnectedOnLinkedin: boolean;
  linkedinUserName: string;
  fullName: string;
  profilePicture: string;
}

const ConnectedAccountCard = ({
  data,
  onClick,
}: {
  data: CardProp;
  onClick?: () => void;
}) => {
  const avtardata = userData(data?.linkedinUserName);
  const isConnected = data?.isConnectedOnLinkedin;
  return (
    <CardWrapper onClick={onClick}>
      <AvatarUI
        teammembers={avtardata}
        image={data?.profilePicture}
        width="52px"
        height="52px"
      />
      <Content>
        <Name>{truncateWords(data?.linkedinUserName, 10)}</Name>
        <Status isConnected={isConnected}>
          {isConnected ? "Connected" : "Disconnected"}
        </Status>
      </Content>
    </CardWrapper>
  );
};

export default ConnectedAccountCard;

const CardWrapper = styled.div`
  border-radius: 2px;
  border: 1px solid ${greyColor};
  background: ${whiteColor};
  display: flex;
  align-items: center;
  gap: ${guttersPx.small};
  padding: ${guttersPx.mediumHalf} ${guttersPx.small};
  max-width: 219px;
  padding-bottom: ${guttersPx.medium};
  cursor: pointer;
`;

const Content = styled.div``;
const Name = styled.div`
  ${typographyParagraph};
  color: ${darkCharcoalColor};
`;

const Status = styled.div<{ isConnected: boolean }>`
  color: ${(props) => (props.isConnected ? "green" : lightRedColor)};
  ${typographyCaptionbold};
`;
