import React from "react";
import {
  whiteColor,
  greyColor,
  darkCharcoalColor,
  darkblueColor,
  lightBlueColor,
  borderRadiusCircle,
  buttonRadius,
  boxShadow,
  buttonCursor,
} from "@/styles/variables";
import {
  typographyCaptionNormal,
  typographySubtitle2Normal,
} from "@/styles/typography";
import ButtonNewDeal from "@/components/ui/button/ButtonNewDeal";
import styled from "@emotion/styled";
import ContentContainer from "@/layouts/userprofile/profileactions/ContentContainer";
import { CardSVG, PeopleSVG } from "@/utils/formUtils/InputSvg/InputSvg";

const commonGrid = `
display: grid;
`;
const GridContainer = styled.div`
  ${commonGrid};
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  align-items: self-start;
`;

const Container = styled.div`
  display: flex;
  gap: 10px;
`;

const SvgIcon = styled.div`
  width: 48px;
  height: 48px;
  background-color: ${lightBlueColor};
  border-radius: ${borderRadiusCircle};
  ${commonGrid};
  place-items: center;
  padding: 10px;
`;

const Content = styled.div``;

const Text = styled.div`
  color: ${darkCharcoalColor};
  ${typographySubtitle2Normal};
  margin-top: 6px;
`;

const Heading = styled.div`
  color: ${greyColor};
  ${typographyCaptionNormal}
`;

const EditButton = styled.div`
  color: ${darkblueColor};
  ${typographyCaptionNormal};
  cursor: ${buttonCursor};
`;

const ContentHeadflex = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const Button = styled(ButtonNewDeal)`
  margin-top: 40px;
  border-radius: ${buttonRadius};
  border: 1px solid ${darkblueColor};
  background: ${whiteColor};
  box-shadow: ${boxShadow};
  color: ${darkblueColor};
  ${typographySubtitle2Normal};
`;

const SpaceBottom = styled.div`
  margin-bottom: 40px;
`;
interface PaymentMethodProps {
  buttonHandler: (val: string) => void;
  EditHandler: () => void;
}
const PaymentMethod: React.FC<PaymentMethodProps> = ({
  buttonHandler,
  EditHandler,
}) => {
  return (
    <SpaceBottom>
      <ContentContainer heading="Payment method">
        <GridContainer>
          <div>
            <Container>
              <SvgIcon>
                <CardSVG />
              </SvgIcon>
              <Content>
                <Heading>Card information</Heading>
                <Text>Mastercard ending in XXXX</Text>
              </Content>
            </Container>
            <Button onClick={() => buttonHandler("abc")}>
              Update credit card
            </Button>
          </div>
          <Container>
            <SvgIcon>
              <PeopleSVG />
            </SvgIcon>
            <Content>
              <ContentHeadflex>
                <Heading>Billing address</Heading>
                <EditButton onClick={EditHandler}>Edit</EditButton>
              </ContentHeadflex>
              <Text>
                Insurgente Solutions S.L B44904290 CALLE DEL CAMI DEL RACO, 6 -
                BL C 3 G, SALOU, 43840, Tarragona España, ES
              </Text>
            </Content>
          </Container>
        </GridContainer>
      </ContentContainer>
    </SpaceBottom>
  );
};

export default PaymentMethod;
