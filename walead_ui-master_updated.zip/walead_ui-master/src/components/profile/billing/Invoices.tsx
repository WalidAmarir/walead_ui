import ContentContainer from "@/layouts/userprofile/profileactions/ContentContainer";
import { DownloadSVG } from "@/utils/formUtils/InputSvg/InputSvg";
import styled from "@emotion/styled";
import React from "react";
import {
  fullWidth,
  greyColor,
  darkCharcoalColor,
  darkblueColor,
} from "@/styles/variables";
import {
  typographyCaptionNormal,
  typographySubtitle2Normal,
} from "@/styles/typography";
const TableContainer = styled.div`
  margin-top: 20px;
`;

const Table = styled.table`
  width: ${fullWidth};
  border-collapse: collapse;
`;

const Th = styled.th`
  color: ${darkblueColor};
  ${typographyCaptionNormal};
  text-decoration-line: underline;
  text-align: start;
  padding: 20px;
`;

const Td = styled.td`
  color: ${darkCharcoalColor};
  ${typographySubtitle2Normal};
  padding: 20px;
`;

const TbodyRow = styled.tr`
  border: 1px solid ${greyColor};
  border-radius: 8px;
`;
const SpaceBottom = styled.div`
  margin-bottom: 40px;
`;
const RowSpaceDivider = styled.div`
  height: 20px;
`;
const Invoices = () => {
  return (
    <SpaceBottom>
      <ContentContainer heading="Invoices">
        <TableContainer>
          <Table>
            <thead>
              <tr>
                <Th>Plan</Th>
                <Th>Cost</Th>
                <Th>Date</Th>
                <Th>Invoice number</Th>
                <Th>Download</Th>
              </tr>
            </thead>
            <tbody>
              <TbodyRow>
                <Td>Started Plan (at 29.50€ / month)</Td>
                <Td>88.50€</Td>
                <Td>Dec 05 2023</Td>
                <Td>0000AAA00-0005</Td>
                <Td>
                  <DownloadSVG />
                </Td>
              </TbodyRow>
              <RowSpaceDivider />
              <TbodyRow>
                <Td>Started Plan (at 29.50€ / month)</Td>
                <Td>88.50€</Td>
                <Td>Dec 05 2023</Td>
                <Td>0000AAA00-0005</Td>
                <Td>
                  <DownloadSVG />
                </Td>
              </TbodyRow>
            </tbody>
          </Table>
        </TableContainer>
      </ContentContainer>
    </SpaceBottom>
  );
};

export default Invoices;
