import { useQueryContext } from "@/context/query/queryContext";
import ContentContainer from "@/layouts/userprofile/profileactions/ContentContainer";
import {
  typographyCaptionNormal,
  typographySubtitle2Normal,
} from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightSilverColor,
} from "@/styles/variables";
import { getTimeFromUnixTimeStamp } from "@/utils/helperUtils";
import styled from "@emotion/styled";
import Link from "next/link";

const Subheading = styled.div`
  color: ${greyColor};
  padding: ${guttersPx.mediumHalf} 0;
  ${typographyCaptionNormal}
`;
const Flex = styled.div`
  display: flex;
  justify-content: space-between;
  padding-bottom: ${guttersPx.mediumHalf};
`;
const Text = styled.div`
  color: ${darkCharcoalColor};
  ${typographySubtitle2Normal};
`;
const Hr = styled.div`
  background: ${lightSilverColor};
  height: 1px;
`;

const StyledLink = styled(Link)`
  color: ${darkblueColor};
  ${typographySubtitle2Normal};
`;
const SpaceBottom = styled.div`
  margin-bottom: 40px;
`;
export default function PaymentInfo() {
  const { subscriptionDetails } = useQueryContext();
  const finaldata = plandata(subscriptionDetails) || [];
  return (
    <SpaceBottom>
      <ContentContainer heading="Payment information">
        {finaldata.map((item) => (
          <>
            <Subheading key={item.id}>{item.subheading}</Subheading>
            <Flex>
              <Text>{item.heading}</Text>
              {item?.isView ? (
                <StyledLink href="#">{item.text}</StyledLink>
              ) : (
                <Text>{item.text}</Text>
              )}
            </Flex>
            <Hr />
          </>
        ))}
      </ContentContainer>
    </SpaceBottom>
  );
}

const plandata = (res: {
  amount: string;
  quantity: string;
  currentPeriodEnd: string | number;
}) => {
  const totalammount = Number(res?.amount) * Number(res?.quantity);
  const formattedDate = getTimeFromUnixTimeStamp(Number(res?.currentPeriodEnd));
  return [
    {
      id: 0,
      subheading: "Plan",
      heading: "Standard Plan",
      text: `${res?.amount}€ /month /user`,
      isView: false,
    },
    {
      id: 1,
      subheading: "Users",
      heading: `${res?.quantity} Users`,
      text: "View MemberShip",
      isView: true,
    },
    {
      id: 2,
      subheading: "Next invoice",
      heading: `${totalammount} (${res?.quantity} x ${res?.amount}€) / month`,
      text: formattedDate,
      isView: false,
    },
  ];
};
