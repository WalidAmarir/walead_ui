import { useLeadsContext } from "@/context/leads/leadContext";
import { greyColor, whiteColor } from "@/styles/variables";
import styled from "@emotion/styled";
import dayjs from "dayjs";
import React from "react";
import SavedListTable from "../ui/tabels/SavedListTable";
const header = [
  { title: "NAME", key: "name" },
  { title: "Last Modified", key: "time" },
  { title: "Owner", key: "owner" },
  { title: "# LEADS", key: "lead" },
  { title: "TAGS", key: "tags" },
];

const SavedList = () => {
  const { filterSaveListData, savelistrefetch } = useLeadsContext();

  const tableData = filterSaveListData?.map(
    (item: {
      tags: string[];
      userId: { fullName: any };
      updated_at: string | number | Date;
    }) => ({
      ...item,
      owner: item.userId?.fullName || "Unknown",
      time: dayjs(item?.updated_at).format("YYYY-MM-DD h:mm A"),
    }),
  );
  const filterList = tableData?.filter(
    (item: { isSaveSearch: boolean }) => item.isSaveSearch,
  );

  return (
    <Wrapper>
      <SavedListTable
        header={header}
        data={filterList}
        refetch={savelistrefetch}
      />
    </Wrapper>
  );
};

export default SavedList;

const Wrapper = styled.div`
  background: ${whiteColor};
  height: 100%;
  min-height: 100vh;
  border: 1px solid ${greyColor};
  border-radius: 5px;
`;
