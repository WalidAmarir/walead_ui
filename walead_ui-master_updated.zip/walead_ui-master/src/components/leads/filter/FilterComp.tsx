import React, { useState } from "react";
import styled from "@emotion/styled";
import Button from "@/components/ui/button/Button";
import LeadMultiSelect from "../multiselect/LeadMultiSelect";
import LeadModal from "../leadmodal/LeadModal";
import LeadSearch from "../search/LeadSearch";
import { CrossIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import BuyLeadCredit from "../buyleadcredit/BuyLeadCredit";

import {
  whiteColor,
  greyColor,
  guttersPx,
  borderRadiusBig,
  darkblueColor,
  darkCharcoalColor,
  fullWidth,
} from "@/styles/variables";
import {
  typographyH4,
  typographyParagraph,
  typographySubtitle2Regular,
} from "@/styles/typography";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";

export interface FilterCompProps {
  selectedItems: number[];
  handleClick: (id: number) => void;
  deleteAllFilters: () => void;
  deleteSubOptionFilters: (itemName: string, id: number) => void;
  data: any;
  suggestionData: any;
  handleMultiSelectChange: (itemName: string, selectedValues: string[]) => void;
  loading: boolean;
  hanldeFilterChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  filterInput: string;
  handleReset: () => void;
  totalCount: string;
}

const FiltersContainer = styled.div`
  width: 30%;
  background: ${whiteColor};
  border: 1px solid ${greyColor};
  border-radius: 5px;
`;

const FiltersHeading = styled.div`
  padding: ${guttersPx.medium};
  ${typographyH4}
`;

const HR = styled.div`
  border-bottom: 1px solid ${greyColor};
`;

const Filters = styled.div`
  ${flexStyle};
  gap: ${guttersPx.mediumHalf};
  padding: ${guttersPx.medium};
`;

const FilterText = styled.div`
  ${typographyParagraph}
  cursor: pointer;
`;

const BtnContainer = styled.div`
  padding: ${guttersPx.mediumHalf};
`;

const StyledBtn = styled(Button)`
  width: ${fullWidth};
  height: 40px;
  margin: ${guttersPx.mediumHalf} 0;
  border-radius: 3px;
`;

const Span = styled.span`
  border-radius: 20px;
  background: ${darkblueColor};
  color: ${whiteColor};
  ${typographyParagraph};
  padding: 2px 14px;
  cursor: pointer;
  margin-left: 8px;
`;

const DotContainer = styled.div`
  width: 30px;
  ${flexStyle};
`;

const Dot = styled.div`
  width: 10px;
  height: 10px;
  border-radius: 20px;
  background: ${darkblueColor};
`;

const FloatingFilterHead = styled.div`
  color: ${darkblueColor};
`;

const Flex = styled.div`
  ${flexStyle};
  justify-content: space-between;
  margin-bottom: 4px;
`;

const SelectedRemove = styled.div`
  border-radius: ${borderRadiusBig};
  border: 0.5px solid ${darkCharcoalColor};
  color: ${darkCharcoalColor};
  ${typographySubtitle2Regular};
  padding: 2px 6px;
  cursor: pointer;
`;

const InputContainer = styled.div`
  width: 80%;
`;

const FilterComp: React.FC<FilterCompProps> = ({
  selectedItems,
  handleClick,
  deleteAllFilters,
  deleteSubOptionFilters,
  data,
  suggestionData,
  handleMultiSelectChange,
  loading,
  hanldeFilterChange,
  filterInput,
  handleReset,
  totalCount,
}) => {
  const [open, setOpen] = useState<boolean>(false);
  const { domain, employees, industry, jobTitle, location, keyword } =
    suggestionData || {};

  const renderInputOrMultiSelect = (item: any, itemNameLowerCase: string) => {
    return (
      <LeadMultiSelect
        data={getDataByItemName(itemNameLowerCase)}
        onChange={(selectedValues: string[]) =>
          handleMultiSelectChange(item.name, selectedValues)
        }
        selectedValues={item.values}
        loading={loading}
        isCheckbox={itemNameLowerCase === "employees"}
      />
    );
  };

  const getDataByItemName = (itemName: string): any[] => {
    const dataMap: { [key: string]: any[] } = {
      domains: domain,
      employees,
      industry,
      jobTitle,
      location,
      keywords: keyword,
    };
    return dataMap[itemName] || [];
  };

  const handleModalOpen = () => setOpen(true);
  const handleModalClose = () => setOpen(false);

  const totalValuesLength =
    data?.reduce(
      (totalLength: number, item: any) => totalLength + item.values.length,
      0,
    ) || 0;

  const isLessThanOne = totalValuesLength > 0;

  return (
    <>
      <FiltersContainer>
        <LeadSearch
          search={filterInput}
          handleSearch={hanldeFilterChange}
          placeholder="Search People..."
          handleReset={handleReset}
        />
        <FiltersHeading>
          Filters
          {isLessThanOne && (
            <Span onClick={deleteAllFilters}>
              {totalValuesLength}&nbsp;&nbsp;
              <CrossIcon color={whiteColor} width="10" height="10" />
            </Span>
          )}
        </FiltersHeading>
        <HR />
        {data?.map((item: any) => {
          const isSelected = selectedItems?.includes(item.id);
          const itemNameLowerCase = item.key;
          return (
            <React.Fragment key={item.id}>
              <Filters>
                {isSelected && (
                  <DotContainer>
                    <Dot />
                  </DotContainer>
                )}
                <div>{item.icon}</div>
                {isSelected ? (
                  <InputContainer>
                    <Flex>
                      <FloatingFilterHead>{item.name}</FloatingFilterHead>
                      <SelectedRemove
                        onClick={() =>
                          deleteSubOptionFilters(item.name, item.id)
                        }
                      >
                        <CrossIcon color={greyColor} width="8" height="8" />
                        {item.values.length !== 0 && <>{item.values.length}</>}
                      </SelectedRemove>
                    </Flex>
                    {renderInputOrMultiSelect(item, itemNameLowerCase)}
                  </InputContainer>
                ) : (
                  <FilterText onClick={() => handleClick(item.id)}>
                    {item.name}
                  </FilterText>
                )}
              </Filters>
              <HR />
            </React.Fragment>
          );
        })}
        <BtnContainer>
          <StyledBtn
            disabled={!isLessThanOne}
            bgColor={totalValuesLength ? darkblueColor : greyColor}
            onClick={handleModalOpen}
          >
            Save search
          </StyledBtn>
        </BtnContainer>
      </FiltersContainer>

      <LeadModal
        closeModal={handleModalClose}
        open={open}
        saveSearchData={data}
        totalCount={totalCount}
      />
      <BuyLeadCredit closeModal={handleModalClose} open={false} />
    </>
  );
};

export default FilterComp;
