import { typographyCaptionNormal } from "@/styles/typography";
import { darkCharcoalColor, guttersPx } from "@/styles/variables";
import styled from "@emotion/styled";
import { LinkIconDiv } from "../rightslider/RightSliderModal";
import { LinkedinIconBlueText } from "@/utils/formUtils/InputSvg/InputSvg";
interface CompanyColumnDataProps {
  fullName?: string;
}

export const LogoWithTextFlex = styled.div`
  display: flex;
  gap: ${guttersPx.smallHalf};
  align-items: start;
`;
const CompanyName = styled.div`
  color: ${darkCharcoalColor};
  ${typographyCaptionNormal}
`;

const NameColumnData: React.FC<CompanyColumnDataProps> = ({ fullName }) => {
  return (
    <>
      <LogoWithTextFlex>
        <div>
          <CompanyName>{fullName}</CompanyName>
          <LinkIconDiv>
            <LinkedinIconBlueText width="16px" height="16px" />
          </LinkIconDiv>
        </div>
      </LogoWithTextFlex>
    </>
  );
};

export default NameColumnData;
