import { darkCharcoalColor } from "@/styles/variables";
import { LogoWithTextFlex } from "./NameColumnData";
import Image from "next/image";
import styled from "@emotion/styled";
import { typographyCaptionNormal } from "@/styles/typography";
import {
  CopyLink,
  LinkedinIconBlueText,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { LinkIconDiv } from "../rightslider/RightSliderModal";
import { openToNewTab } from "@/utils/helperUtils";
import { LeadFinder } from "@/types/global";

const CompanyName = styled.div`
  color: ${darkCharcoalColor};
  ${typographyCaptionNormal}
`;

const CompanyColumnData: React.FC<{ data: LeadFinder }> = ({ data }) => {
  const { organizationName, organizationLogo, linkedIn, organizationWebsite } =
    data;

  const naviGateTo = (event: { stopPropagation: () => void }, url: string) => {
    event.stopPropagation();
    openToNewTab(url, "");
  };

  return (
    <>
      <LogoWithTextFlex>
        {organizationLogo && (
          <Image
            src={organizationLogo}
            alt={organizationName}
            width={20}
            height={20}
          />
        )}
        <div>
          <CompanyName>{organizationName}</CompanyName>
          <LinkIconDiv>
            <CopyLink
              width="15"
              height="15"
              color={darkCharcoalColor}
              onclick={(event: any) => naviGateTo(event, organizationWebsite)}
            />
            {linkedIn && (
              <LinkedinIconBlueText
                width="16px"
                height="16px"
                onclick={(event: any) => naviGateTo(event, linkedIn)}
              />
            )}
          </LinkIconDiv>
        </div>
      </LogoWithTextFlex>
    </>
  );
};

export default CompanyColumnData;
