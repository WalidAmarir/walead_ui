// Import necessary dependencies from React, MUI, and Emotion Styled

import * as React from "react";
import { Button } from "@mui/material";
import Pagination from "@mui/material/Pagination";

import styled from "@emotion/styled";
import {
  GridColDef,
  GridRowId,
  GridFooter,
  GridFooterContainer,
} from "@mui/x-data-grid";
import {
  typographyBody1,
  typographyBold,
  typographyH4,
} from "@/styles/typography";
import {
  buttonRadius,
  darkCharcoalColor,
  darkblueColor,
  fullWidth,
  greyColor,
  guttersPx,
  whiteColor,
} from "@/styles/variables";
import { SendSVG } from "@/utils/formUtils/InputSvg/InputSvg";
import RightSliderModal from "../rightslider/RightSliderModal";
import NameColumnData from "./NameColumnData";
import CompanyColumnData from "./CompanyColumnData";
import { SEND_LEAD_TO_PIPELINE } from "@/lib/graphql/mutation/sendLeadToPipeline";
import { useLazyQuery, useMutation } from "@apollo/client";
import { errorToast, successToast } from "@/styles/toaster";
import ExportButton from "@/components/ui/button/ExportButton";
import { LeadFinder } from "@/types/global";
import { StyledDataGrid } from "@/shared/UserMenu/SharedUserMenuComponents";
import { getBtnState } from "@/utils/helperUtils";
import { exportToExcel, formatNumber } from "@/utils/optionUtils";
import { EXPORT_LEAD_FINDER } from "@/lib/graphql/queries/exportLeadFinder";
import BuyLeadCredit from "../buyleadcredit/BuyLeadCredit";

const columns: GridColDef[] = [
  {
    field: "name",
    headerName: "NAME",
    headerClassName: "columnHeaderTitle",
    cellClassName: "cellContent",
    flex: 1,
    renderCell: (params) => <NameColumnData fullName={params.row.name} />,
  },
  {
    field: "title",
    headerName: "TITLE",
    flex: 1,
    headerClassName: "columnHeaderTitle",
    cellClassName: "cellContent",
  },
  {
    field: "organizationName",
    headerName: "COMPANY",
    flex: 1,
    headerClassName: "columnHeaderTitle",
    cellClassName: "cellContent",
    renderCell: ({ row }) => <CompanyColumnData data={row} />,
  },
  {
    field: "email",
    headerName: "EMAIL",
    flex: 1,
    headerClassName: "columnHeaderTitle",
    cellClassName: "cellContent",
  },
  {
    field: "phoneNumber",
    headerName: "PHONE NUMBER",
    flex: 1,
    headerClassName: "columnHeaderTitle",
    cellClassName: "cellContent",
  },
];

interface LeadsTableProps {
  totalCount?: string;
  tableData?: any;
  handlePageSize: (newPage: { pageSize: number; page: number }) => void;
  loading: boolean;
  paginationText: string;
}
// Define columns for the data grid

const commonFlex = {
  display: "flex",
  alignItems: "center",
};
// Define styled components for header elements

const Header = styled.div`
  padding: ${guttersPx.medium};
  border-bottom: 1px solid ${greyColor};
  justify-content: space-between;
  ${commonFlex}
`;

const CountWrapper = styled.div`
  ${commonFlex}
  gap:${guttersPx.mediumHalf};
`;
const Count = styled.div`
  ${typographyH4};
  color: ${darkCharcoalColor};
`;

const CountText = styled.div`
  ${typographyBody1};
  color: ${darkCharcoalColor};
`;
const SelectedText = styled.div`
  ${typographyBody1};
  color: ${greyColor};
`;
// Define styled components for button, data grid container, and data grid

const BtnPipeline = styled(Button)`
  background: ${darkblueColor};
  ${typographyBold};
  text-align: center;
  text-transform: none;
  border-radius: ${buttonRadius};
  &.Mui-disabled {
    /* Updated styling for the disabled button */
    border-radius: ${buttonRadius};
    background: rgba(2, 119, 182, 0.3);
    color: ${whiteColor};
  }
`;
const DataGridConatiner = styled.div`
  height: 90vh;
  width: ${fullWidth};
  .MuiTablePagination-displayedRows {
    display: none !important;
  }
`;
const StyledGridFooterContainer = styled(GridFooterContainer)`
  justify-content: start !important;
  margin-left: ${guttersPx.small};
`;

// Component for the leads table

const LeadsTable: React.FC<LeadsTableProps> = ({
  totalCount,
  tableData,
  handlePageSize,
  loading,
  paginationText,
}) => {
  const [selectedRows, setSelectedRows] = React.useState<LeadFinder[]>([]);
  const [isOpenDeal, setIsOpenDeal] = React.useState<boolean>(false);
  const [isDrawerOpen, setIsDrawerOpen] = React.useState(false);
  const [selectedRowData, setSelectedRowData] = React.useState<any | null>(
    null,
  );
  const [exportCsv] = useLazyQuery(EXPORT_LEAD_FINDER);
  const onCloseDealModal = () => setIsOpenDeal(false);
  const count = selectedRows?.length;
  const onExportCsv = async () => {
    const numberOfRows = selectedRowData ? 1 : count;
    const { data } = await exportCsv({
      variables: { leadCount: selectedRowData ? "1" : count?.toString() },
    });
    const checkLength =
      Number(data?.exportLeadFinder?.availableCreditScore) > numberOfRows;
    if (checkLength) {
      exportToExcel(
        selectedRowData ? [selectedRowData] : selectedRows,
        "leaddata.xlsx",
      );
    } else {
      setIsOpenDeal(true);
    }
  };

  const [sendLeadToPipeline, { loading: loadingPipeLine }] = useMutation(
    SEND_LEAD_TO_PIPELINE,
    {
      onCompleted: (data) => {
        successToast(data.sendLeadToPipeline);
        setSelectedRows([]);
      },
      onError: (error) => errorToast(error?.message),
    },
  );

  const handleSendToPipeline = async () => {
    const ids = selectedRows.map((item) => item.id);
    await sendLeadToPipeline({
      variables: {
        input: {
          leadIds: ids,
        },
      },
    });
  };

  // Function to handle row selection
  const onRowsSelectionHandler = (ids: GridRowId[]) => {
    const selectedRowsData = ids
      ?.map((id) => tableData?.find((row: LeadFinder) => row.id === id))
      ?.filter((row): row is LeadFinder => !!row);
    setSelectedRows(selectedRowsData);
  };

  const handleRowClick = (params: { row: string }) => {
    if (count > 0) {
      return;
    }
    setSelectedRowData(params.row);
    setIsDrawerOpen(true);
  };

  const handleCloseModal = () => {
    setIsDrawerOpen(false);
    setSelectedRowData(null);
  };

  const isDisabled = selectedRows.length === 0 || loadingPipeLine;
  const CustomFooter = () => {
    return (
      <StyledGridFooterContainer>
        <p>{paginationText}</p>
        <GridFooter>
          <Pagination count={10} color="primary" size="small" />
        </GridFooter>
      </StyledGridFooterContainer>
    );
  };

  return (
    <>
      <Header>
        <CountWrapper>
          <Count>{formatNumber(totalCount || "")}</Count>
          <CountText>results found</CountText>
        </CountWrapper>
        <CountWrapper>
          {selectedRows?.length > 0 && (
            <SelectedText>{selectedRows.length} selected</SelectedText>
          )}
          <ExportButton
            buttonText="Download CSV"
            disabled={isDisabled}
            onExportCsv={onExportCsv}
          />
          <BtnPipeline
            disabled={isDisabled}
            variant="contained"
            startIcon={<SendSVG />}
            onClick={handleSendToPipeline}
          >
            {getBtnState("Send to Pipeline", loadingPipeLine)}
          </BtnPipeline>
        </CountWrapper>
      </Header>
      <DataGridConatiner>
        <StyledDataGrid
          rows={tableData || []}
          columns={columns}
          sx={{
            "&, [class^=MuiDataGrid]": { border: "none" },
          }}
          checkboxSelection
          onRowSelectionModelChange={(ids) => onRowsSelectionHandler(ids)}
          onRowClick={handleRowClick}
          rowCount={Number(totalCount) || 0}
          initialState={{
            pagination: {
              paginationModel: { pageSize: 25, page: 0 },
            },
          }}
          pageSizeOptions={[25, 50, 100]}
          onPaginationModelChange={async (val) => handlePageSize(val)}
          loading={loading}
          disableRowSelectionOnClick
          components={{
            Footer: CustomFooter,
          }}
        />
      </DataGridConatiner>
      <RightSliderModal
        isOpen={isDrawerOpen}
        closeModal={handleCloseModal}
        selectedRowData={selectedRowData}
        onExportCsv={onExportCsv}
      />
      <BuyLeadCredit open={isOpenDeal} closeModal={onCloseDealModal} />
    </>
  );
};

export default LeadsTable;
