import ModalHeader from "@/components/schedulePost/ModalHeader";
import Modal from "@/components/ui/modal/Modal";
import {
  darkCharcoalColor,
  fontWeightNormal,
  greyColor,
  guttersPx,
} from "@/styles/variables";
import styled from "@emotion/styled";
import { typographyH3 } from "@/styles/typography";
interface LeadModalProps {
  open: boolean;
  closeModal: () => void;
}

const commonEqualMargin = {
  margin: "10px 0",
};
const ModalContainer = styled.div`
  width: 600px;
`;
const ModalHead = styled.div`
  color: ${darkCharcoalColor};
  text-align: center;
  ${typographyH3}
`;
const ModalPara = styled.p`
  color: ${greyColor};
  text-align: center;
  font-size: 18px;
  font-weight: ${fontWeightNormal};
  width: 262px;
  height: 66px;
  ${commonEqualMargin}
`;

const Div = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const BuyLeadCredit: React.FC<LeadModalProps> = ({ open, closeModal }) => {
  return (
    <>
      <Modal
        open={open}
        width="600px"
        maxWidth="md"
        closeModal={closeModal}
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <ModalContainer>
          <ModalHeader showClose={true} onclose={closeModal} />
          <Div>
            <ModalHead>You don&apos;t have lead credits 😢</ModalHead>
            <ModalPara>
              To download the leads, you need to have lead credits
            </ModalPara>
          </Div>
        </ModalContainer>
      </Modal>
    </>
  );
};

export default BuyLeadCredit;
