import {
  darkCharcoalColor,
  darkblueColor,
  whiteColor,
} from "@/styles/variables";
import styled from "@emotion/styled";
import { Autocomplete, TextField } from "@mui/material";
import { typographySubtitle1 } from "@/styles/typography";
import LeadTags from "../leadtags/LeadTags";

const StyledAutoComplete = styled(Autocomplete)`
  & input::placeholder {
    padding-left: 10px;
    color: ${darkCharcoalColor};
    background-color: ${whiteColor};
    ${typographySubtitle1}
  }

  .MuiInputBase-root {
    outline: none;
    border: 1px solid transparent;
    padding: 0;
    border-radius: 0;
  }

  .MuiInputBase-root:focus-within {
    border: 2px solid ${darkblueColor} !important; /* Border on focus */
  }

  .MuiInputBase-root:hover {
    border: 1px solid rgba(135, 135, 135, 0.5); /* Border on hover */
  }

  .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline {
    border-color: transparent !important;
  }

  .MuiOutlinedInput-root:hover .MuiOutlinedInput-notchedOutline {
    border-color: transparent !important;
  }

  .MuiAutocomplete-input {
    padding: 0px !important;
  }
`;

interface LeadModalProps {
  color: string;
  formik: any;
  options: string[];
}

const MultiInputEnter: React.FC<LeadModalProps> = ({
  color,
  formik,
  options,
}) => {
  const handleTagsChange = (_: any, newTags: any) => {
    formik.setValues({ ...formik.values, tags: newTags }); // Update the 'tags' field in formik values
  };

  return (
    <StyledAutoComplete
      multiple
      freeSolo
      id="tags-outlined"
      options={options}
      value={formik.values.tags}
      onChange={handleTagsChange}
      renderTags={(value) =>
        value.map((option, index) => (
          <LeadTags key={index} tag={option} color={color} />
        ))
      }
      renderInput={(params) => (
        <TextField
          {...params}
          variant="outlined"
          label=""
          placeholder="Add tags"
          size="small"
        />
      )}
    />
  );
};

export default MultiInputEnter;
