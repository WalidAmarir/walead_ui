import { darkCharcoalColor } from "@/styles/variables";
import styled from "@emotion/styled";
import { typographyCaptionNormal } from "@/styles/typography";

const TagsLead = styled.div`
  border-radius: 12.5px;
  background: ${(props) => props.color};
  color: ${darkCharcoalColor};
  ${typographyCaptionNormal}
  padding: 4px 8px;
  width: fit-content;
  margin: 4px;
`;
// Props type for the component
interface LeadTagsProps {
  tag: any;
  color: string;
}

const LeadTags: React.FC<LeadTagsProps> = ({
  tag = "1-500 employees",
  color,
}) => {
  return <TagsLead color={color}>{tag}</TagsLead>;
};

export default LeadTags;
