import React from "react";
import { Button } from "@mui/material";
import styled from "@emotion/styled";
import Image from "next/image";
import {
  CopyLink,
  CrossIcon,
  LinkedinIconBlueText,
  SendSVG,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { getInitials } from "@/components/ui/avatar/Avatar";
import CommonAvatar from "@/components/ui/avatar/CommonAvatar";
import SliderOverModal from "@/components/ui/slideover/SliderOverModal";
import {
  typographyBold,
  typographyH3Normal,
  typographyH4,
  typographyParagraph,
  typographySubtitle1,
} from "@/styles/typography";
import {
  blackColor,
  buttonCursor,
  darkCharcoalColor,
  darkblueColor,
  greyColor,
  guttersPx,
} from "@/styles/variables";
import { errorToast, successToast } from "@/styles/toaster";
import { useMutation } from "@apollo/client";
import { SEND_LEAD_TO_PIPELINE } from "@/lib/graphql/mutation/sendLeadToPipeline";
import ExportButton from "@/components/ui/button/ExportButton";
import { getBtnState, openToNewTab } from "@/utils/helperUtils";
import { keysToShow } from "@/utils/constant";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
const Container = styled.div`
  padding: 40px;
`;

const CommonMargin = `
  margin: 20px 0;
`;

const Hr = styled.div`
  border: 1px solid ${greyColor};
`;

const Cross = styled.div`
  cursor: ${buttonCursor};
  width: fit-content;
  float: right;
`;

const Heading = styled.div`
  color: ${darkCharcoalColor};
  ${typographyH4};
  ${CommonMargin}
`;

const TableFlex = styled.div`
  ${flexStyle};
  flex-wrap: wrap;
  ${CommonMargin}
`;

const TableHead = styled.div`
  color: ${greyColor};
  ${typographyParagraph};
  width: 40%;
`;

const TableData = styled.div`
  color: ${blackColor};
  ${typographySubtitle1};
  width: 60%;
`;

const CompanyName = styled.div`
  color: ${darkCharcoalColor};
  ${typographyParagraph};
`;

const LogoWithTextFlex = styled.div`
  display: flex;
  gap: ${guttersPx.smallHalf};
`;

export const LinkIconDiv = styled.div``;

export const Span = styled.span`
  margin-left: 4px;
`;

const CustomButtonPipeline = styled(Button)`
  background: ${darkblueColor};
  ${typographyBold};
  text-align: center;
  text-transform: none;
`;

const BtnContainer = styled.div`
  ${CommonMargin}
  ${flexStyle};
  gap: ${guttersPx.medium};
`;

const AvatarWithNameContainer = styled.div`
  ${flexStyle};
  gap: ${guttersPx.medium};
  ${CommonMargin}
`;

const Name = styled.div`
  color: ${darkCharcoalColor};
  ${typographyH3Normal}
`;
const NameWithLogoContainer = styled.div``;
const LinkedinLogo = styled.div``;

interface RightSliderModalProps {
  closeModal: () => void;
  selectedRowData: any;
  isOpen: boolean;
  onExportCsv: () => void;
}
const RightSliderModal = ({
  closeModal,
  onExportCsv,
  selectedRowData,
  isOpen,
}: RightSliderModalProps) => {
  const [sendLeadToPipeline, { loading }] = useMutation(SEND_LEAD_TO_PIPELINE, {
    onCompleted: (data) => successToast(data.sendLeadToPipeline),
    onError: (error) => errorToast(error?.message),
  });
  const {
    id,
    name,
    profileImage,
    organizationLogo,
    organizationWebsite,
    linkedIn,
  } = selectedRowData || {};
  const handleSendToPipeline = async () => {
    if (id) {
      await sendLeadToPipeline({
        variables: {
          input: {
            leadIds: [selectedRowData.id],
          },
        },
      });
    }
  };

  return (
    <SliderOverModal open={isOpen} anchor="right" width={"610px"}>
      <Container>
        <Cross onClick={closeModal}>
          <CrossIcon width="27px" height="27px" color={darkCharcoalColor} />
        </Cross>
        <AvatarWithNameContainer>
          <CommonAvatar
            avatarText={getInitials(name)}
            alt={name}
            imgDimension="60"
            src={profileImage}
            dimension="60"
            size="20"
          />
          <NameWithLogoContainer>
            <Name>{name}</Name>
            <LinkedinLogo>
              <LinkedinIconBlueText width="26px" height="26px" />
            </LinkedinLogo>
          </NameWithLogoContainer>
        </AvatarWithNameContainer>
        <BtnContainer>
          <ExportButton
            buttonText="Download CSV"
            disabled={loading}
            onExportCsv={onExportCsv}
          />
          <CustomButtonPipeline
            variant="contained"
            startIcon={<SendSVG />}
            onClick={handleSendToPipeline}
            disabled={loading}
          >
            {getBtnState("Send to Pipeline", loading)}
          </CustomButtonPipeline>
        </BtnContainer>
        <Hr />
        <Heading>Lead details</Heading>
        {/* Map over the keys to display */}
        {keysToShow?.map(({ key, displayName }) => (
          <TableFlex key={key}>
            <TableHead>{displayName}</TableHead>
            <TableData>
              {/* Render company logo if column is "Company" */}
              {key === "organizationName" ? (
                <>
                  <LogoWithTextFlex>
                    {/* Check if organizationLogo exists */}
                    {organizationLogo && (
                      <Image
                        src={organizationLogo}
                        alt={"company logo"}
                        width={20}
                        height={20}
                      />
                    )}
                    <LinkIconDiv>
                      <CompanyName>{selectedRowData?.[key]}</CompanyName>
                      {organizationWebsite && (
                        <CopyLink
                          width="15px"
                          height="15px"
                          onclick={() => openToNewTab(organizationWebsite, "")}
                        />
                      )}
                      {linkedIn && (
                        <LinkedinIconBlueText
                          width="16px"
                          height="16px"
                          onclick={() => openToNewTab(linkedIn, "")}
                        />
                      )}
                    </LinkIconDiv>
                  </LogoWithTextFlex>
                </>
              ) : (
                <CompanyName>{selectedRowData?.[key]}</CompanyName>
              )}
            </TableData>
          </TableFlex>
        ))}
      </Container>
    </SliderOverModal>
  );
};

export default RightSliderModal;
