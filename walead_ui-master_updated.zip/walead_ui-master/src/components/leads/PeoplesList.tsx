import { greyColor, whiteColor } from "@/styles/variables";
import styled from "@emotion/styled";
import React from "react";
import LeadsTable from "./leadstable/LeadsTable";
import { Data } from "./People";
import StartSearch from "./startsearch/StartSearch";

interface Props {
  loading: boolean;
  recentSearchValHandler: (data: any) => void; // Adjust the type accordingly
  totalCount: string;
  isFilterOpen: boolean;
  customData: any[]; // Adjust the type accordingly
  handlePegination: (variables: any) => void; // Adjust the type accordingly
  data: Data[];
  paginationText: string;
}

const PeoplesList = ({
  loading,
  recentSearchValHandler,
  totalCount,
  customData,
  isFilterOpen,
  handlePegination,
  data,
  paginationText,
}: Props) => {
  const handlePageSize = (newPage: { pageSize: number; page: number }) => {
    const currentPageSize = newPage.pageSize;
    const currentPage = newPage.page;
    let newFirst = currentPageSize * (currentPage + 1);
    let newAfter = currentPageSize * currentPage;
    handlePegination((prev: any) => ({
      ...prev,
      startIndex: newFirst,
      endIndex: newAfter,
    }));
  };

  return (
    <PeoplesListWrapper>
      {isFilterOpen ? (
        <LeadsTable
          totalCount={totalCount}
          tableData={customData}
          handlePageSize={handlePageSize}
          loading={loading}
          paginationText={paginationText}
        />
      ) : (
        <StartSearch
          filtervalues={data}
          totalCount={totalCount}
          saveHandler={recentSearchValHandler}
        />
      )}
    </PeoplesListWrapper>
  );
};

export default PeoplesList;

const PeoplesListWrapper = styled.div`
  width: 70%;
  background: ${whiteColor};
  border: 1px solid ${greyColor};
  border-radius: 5px;
  height: 100%;
`;
