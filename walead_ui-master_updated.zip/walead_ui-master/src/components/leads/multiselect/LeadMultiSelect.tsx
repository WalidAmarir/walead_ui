import * as React from "react";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import styled from "@emotion/styled";
import {
  buttonCursor,
  whiteColor,
  borderRadiusTiny,
  shelduckBlueColor,
  fullWidth,
  darkCharcoalColor,
  guttersPx,
} from "@/styles/variables";
import { typographySubtitle2Normal } from "@/styles/typography";
import FormControlLabel from "@mui/material/FormControlLabel";
import { Checkbox } from "@mui/material";

const StyledAutoComplete = styled(Autocomplete)`
  width: ${fullWidth};

  .MuiAutocomplete-tag {
    align-items: center;
    color: ${whiteColor};
    ${typographySubtitle2Normal}
    border-radius: ${borderRadiusTiny};
    background: ${shelduckBlueColor};
    width: fit-content;
    word-break: break-all;
    cursor: ${buttonCursor};
  }

  &.muiautocomplete-listbox {
    max-height: ${guttersPx.medium};
    overflow-y: auto;
  }

  .MuiFilledInput-root {
    padding-top: 10px !important;
    background: ${whiteColor} !important;
  }
`;

interface LeadMultiSelectProps {
  data: string[];
  selectedValues: string[];
  onChange: (selectedValues: string[]) => void;
  loading: boolean;
  isCheckbox?: boolean;
}

function sleep(duration: number): Promise<void> {
  return new Promise<void>((resolve) => {
    setTimeout(() => {
      resolve();
    }, duration);
  });
}

const LeadMultiSelect: React.FC<LeadMultiSelectProps> = ({
  data = [],
  selectedValues,
  onChange,
  loading,
  isCheckbox,
}) => {
  const [open, setOpen] = React.useState(false);
  const [options, setOptions] = React.useState<string[]>([]);
  const [internalLoading, setInternalLoading] = React.useState(false); // Internal loading state

  React.useEffect(() => {
    let active = true;

    const fetchData = async () => {
      setInternalLoading(true); // Set internal loading to true when fetching data
      await sleep(500); // Simulating asynchronous data fetching
      if (active) {
        setOptions(data);
        setInternalLoading(false); // Set internal loading to false when data fetching is done
      }
    };

    if (open) {
      fetchData();
    } else {
      setOptions([]);
    }

    return () => {
      active = false;
    };
  }, [open, data]);

  const handleChange = (_event: React.ChangeEvent<{}>, value: any) => {
    onChange(value); // Pass value to onChange
  };

  return (
    <StyledAutoComplete
      multiple
      id="multiple-limit-tags"
      open={open}
      onOpen={() => setOpen(true)}
      onClose={() => setOpen(false)}
      options={options}
      loading={loading || internalLoading}
      loadingText="Fetching data..."
      onChange={handleChange}
      value={selectedValues}
      limitTags={2}
      renderInput={(params) => (
        <TextField
          {...params}
          variant="filled"
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <React.Fragment>
                {internalLoading && !options.length && (
                  <CircularProgress color="primary" size={20} />
                )}
                {params.InputProps.endAdornment}
              </React.Fragment>
            ),
          }}
        />
      )}
      renderOption={(props, option: any, { selected }) => (
        <li {...props}>
          {isCheckbox ? (
            <FormControlLabel
              control={<Checkbox checked={selected} />}
              label={option}
            />
          ) : (
            <span>{option}</span>
          )}
        </li>
      )}
      sx={{
        display: "inline-block",
        width: fullWidth,
        color: darkCharcoalColor,
        backgroundColor: whiteColor,
        "& input": {
          height: "8px ",
          width: fullWidth,
          border: 0,
          maxHeight: "39px",
          overflow: "auto",
          marginBottom: "4px",
          backgroundColor: whiteColor,
        },
      }}
    />
  );
};

export default LeadMultiSelect;
