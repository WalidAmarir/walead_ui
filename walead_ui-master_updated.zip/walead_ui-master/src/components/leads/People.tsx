import React, { useState, useMemo, useCallback } from "react";
import styled from "@emotion/styled";
import FilterComp from "./filter/FilterComp";
import { guttersPx } from "@/styles/variables";
import { LEAD_FINDERS } from "@/lib/graphql/queries/leadFinders";
import { useMutation, useQuery } from "@apollo/client";
import {
  DomainsSVG,
  EmployeesSVG,
  IndustrySVG,
  JobTitlesSVG,
  KeyWordFiltersSVG,
  LocationSVG,
  RevenueSVG,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { LEAD_FINDER_FILTER } from "@/lib/graphql/queries/leadFinderFilter";
import {
  deleteSubOptionFilters,
  filterDataArray,
  formatNumber,
  mapAndFormatItemsOfLeads,
} from "@/utils/optionUtils";
import { getDataFromEdgesKey } from "@/utils/helperUtils";
import PeoplesList from "./PeoplesList";
import { useLeadsContext } from "@/context/leads/leadContext";
import { CREATE_SAVE_SEARCH } from "@/lib/graphql/mutation/createSaveSearch";
import { errorToast } from "@/styles/toaster";

const PeoplesContainer = styled.div``;
const Flex = styled.div`
  display: flex;
  flex-wrap: nowrap;
  flex-direction: row;
  justify-content: space-between;
  gap: ${guttersPx.medium};
`;

// Interface for definning the structure of the data used in the component
export interface Data {
  key: string;
  id: number;
  name: string;
  values: string[];
  icon: React.ReactNode;
}

// Functional component for managing people data
const People: React.FC = () => {
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [dataArr, setDataArr] = useState<Data[]>(FilterData);
  const { setAllFieldsValue, savelistrefetch } = useLeadsContext();
  const [filters, setFilters] = useState({
    search: "",
    startIndex: 0,
    endIndex: 25,
  });
  const { loading, data } = useQuery(LEAD_FINDERS, {
    fetchPolicy: "no-cache",
    variables: {
      first: filters.startIndex,
      after: filters?.endIndex,
      search: filters?.search,
      filterOptions: filterDataArray(dataArr),
      pollInterval: 300,
    },
  });
  const [handleSaveSearch] = useMutation(CREATE_SAVE_SEARCH, {
    onCompleted: () => {
      savelistrefetch();
      setDataArr(FilterData);
      setSelectedItems([]);
    },
    onError: (error) => errorToast(error?.message),
  });
  const { loading: leadFinderFilterloading, data: leadFinderFilterData } =
    useQuery(LEAD_FINDER_FILTER, {
      onCompleted: (res) => setAllFieldsValue(res?.leadFinderFilter),
    });
  const paginationText = `${filters?.startIndex} - ${filters?.endIndex} of ${formatNumber(
    data?.leadFinders?.totalCount,
  )}`;

  // Memoized custom data based on fetched lead finder data
  const getDataFromEdgesKeyObj = getDataFromEdgesKey(data?.leadFinders);
  const customData = useMemo(
    () => mapAndFormatItemsOfLeads(getDataFromEdgesKeyObj),
    [getDataFromEdgesKeyObj, mapAndFormatItemsOfLeads],
  );

  // Memoized function to handle multi-select filter change
  const handleMultiSelectChange = useCallback(
    (itemName: string, selectedValues: any) => {
      setDataArr((prevDataArr) =>
        prevDataArr.map((item) =>
          item.name === itemName ? { ...item, values: selectedValues } : item,
        ),
      );
    },
    [setDataArr],
  );

  // Function to handle click event for selecting items
  const handleClick = (id: number) => {
    setSelectedItems(
      selectedItems?.includes(id)
        ? selectedItems.filter((item) => item !== id)
        : [...selectedItems, id],
    );
  };

  // Function to delete all filters
  const deleteAllFilters = () => {
    handleSaveSearch({
      variables: {
        input: {
          lead: String(data?.leadFinders?.totalCount),
          filterOptions: filterDataArray(dataArr),
          isSaveSearch: false,
        },
      },
    });
  };
  // Function to delete specific sub-option filters

  const memoizedDeleteSubOptionFilters = useMemo(
    () => deleteSubOptionFilters(setDataArr, setSelectedItems),
    [],
  );

  // Function to handle save recent save search
  const recentSearchValHandler = (
    selectedItem: {
      id: string;
      value: any;
    }[],
  ) => {
    const updatedArray = dataArr.map((initialItem) => {
      const matchingInputItem = selectedItem?.find(
        (inputItem) => inputItem.id === initialItem.key,
      );
      if (matchingInputItem) {
        setSelectedItems((prev) => [...prev, initialItem?.id]);
        return { ...initialItem, values: matchingInputItem.value };
      }
      return initialItem;
    });
    setDataArr(updatedArray);
  };

  const handleReset = () => setFilters({ ...filters, search: "" });

  const hanldeFilterChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      setFilters({ ...filters, [name]: value });
    },
    [],
  );
  const isFilterOpen =
    selectedItems?.length !== 0 || filters?.search?.trim() !== "";

  return (
    <>
      <PeoplesContainer>
        <Flex>
          {/* Component for filtering */}
          <FilterComp
            selectedItems={selectedItems}
            handleClick={handleClick}
            deleteAllFilters={deleteAllFilters}
            deleteSubOptionFilters={memoizedDeleteSubOptionFilters}
            data={dataArr}
            suggestionData={leadFinderFilterData?.leadFinderFilter}
            handleMultiSelectChange={handleMultiSelectChange}
            loading={leadFinderFilterloading}
            hanldeFilterChange={hanldeFilterChange}
            filterInput={filters?.search}
            handleReset={handleReset}
            totalCount={data?.leadFinders?.totalCount}
          />
          <PeoplesList
            recentSearchValHandler={recentSearchValHandler}
            handlePegination={setFilters}
            loading={loading}
            customData={customData}
            totalCount={data?.leadFinders?.totalCount}
            isFilterOpen={isFilterOpen}
            data={dataArr}
            paginationText={paginationText}
          />
        </Flex>
      </PeoplesContainer>
    </>
  );
};

export default People;

export const FilterData = [
  {
    id: 0,
    key: "jobTitle",
    name: "Job Title",
    icon: <JobTitlesSVG />,
    values: [],
  },
  {
    id: 1,
    key: "industry",
    name: "Industry",
    icon: <IndustrySVG />,
    values: [],
  },
  {
    id: 2,
    key: "location",
    name: "Location",
    icon: <LocationSVG />,
    values: [],
  },
  {
    id: 3,
    name: "Employees",
    key: "employees",
    icon: <EmployeesSVG />,
    values: [],
  },
  {
    id: 4,
    name: "Revenue",
    key: "revenue",
    icon: <RevenueSVG />,
    values: [],
  },
  {
    id: 5,
    name: "Keyword filters",
    key: "keywords",
    icon: <KeyWordFiltersSVG />,
    values: [],
  },
  {
    id: 6,
    name: "Domains",
    key: "domains",
    icon: <DomainsSVG />,
    values: [],
  },
];
