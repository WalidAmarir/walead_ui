import ComboButtons from "@/components/schedulePost/ComboButtons";
import ModalFooter from "@/components/schedulePost/ModalFooter";
import ModalHeader from "@/components/schedulePost/ModalHeader";
import ModalHeading from "@/components/schedulePost/ModalHeading";
import InputBox from "@/components/ui/input/InputBox";
import Modal from "@/components/ui/modal/Modal";
import { Label } from "@/layouts/deals/DealFormComponent";
import {
  darkblueColor,
  darkCharcoalColor,
  guttersPx,
  orangeColor,
  whiteColor,
} from "@/styles/variables";
import { createSearchNameSchema } from "@/utils/formUtils/validations/ValidationUtils";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React from "react";
import MultiInputEnter from "../multiinputenter/MultiInputEnter";
import { errorToast, successToast } from "@/styles/toaster";
import { useMutation } from "@apollo/client";
import { CREATE_SAVE_SEARCH } from "@/lib/graphql/mutation/createSaveSearch";
import { filterDataArray } from "@/utils/optionUtils";
import { getBtnState } from "@/utils/helperUtils";
import { UPDATE_SAVE_SEARCH } from "@/lib/graphql/mutation/updateSaveSearch";
import { useLeadsContext } from "@/context/leads/leadContext";
import { InputContainer } from "@/shared/UserMenu/SharedUserMenuComponents";

const ModalContainer = styled.div`
  width: 647px;
  padding: ${guttersPx.medium};
`;

interface LeadModalProps {
  open: boolean;
  closeModal: () => void;
  saveSearchData?: any;
  totalCount: string;
  title?: string;
  isEdit?: boolean;
  defaultData?: Record<string, any> | null;
  tagsOption?: string[];
}
type HandleSendToPipelineParams = {
  searchname: string;
  tags: string[]; // or whatever type your tags are
};
const LeadModal: React.FC<LeadModalProps> = ({
  open,
  closeModal,
  saveSearchData,
  totalCount,
  title = "Save search",
  isEdit = false,
  defaultData,
}) => {
  const { allFields, savelistrefetch } = useLeadsContext();
  const { employees } = allFields;
  const [handleSaveSearch, { loading }] = useMutation(CREATE_SAVE_SEARCH, {
    onCompleted: (data) => onSuccess(data.createSaveSearch),
    onError: (error) => errorToast(error?.message),
  });

  const [onUpdateSaveSearch] = useMutation(UPDATE_SAVE_SEARCH, {
    onCompleted: (data) => onSuccess(data.updateSaveSearch),
    onError: (error) => errorToast(error?.message),
  });

  const onSuccess = (msg: string) => {
    successToast(msg);
    formik.resetForm();
    closeModal();
    savelistrefetch();
  };

  const handleSendToPipeline = async ({
    searchname,
    tags,
  }: HandleSendToPipelineParams) => {
    await handleSaveSearch({
      variables: {
        input: {
          lead: String(totalCount),
          name: searchname,
          tags: tags,
          filterOptions: filterDataArray(saveSearchData),
        },
      },
    });
  };

  const handleOnUpadteSave = async ({
    searchname,
    tags,
  }: HandleSendToPipelineParams) => {
    await onUpdateSaveSearch({
      variables: {
        input: {
          id: defaultData?.id,
          name: searchname,
          tags: tags,
          isSaveSearch: true,
        },
      },
    });
  };

  const formik = useFormik({
    initialValues: {
      searchname: defaultData?.name || "",
      tags: defaultData?.tags || [],
    },
    validationSchema: createSearchNameSchema,
    enableReinitialize: true,
    onSubmit: async (values) => {
      if (isEdit) {
        handleOnUpadteSave(values);
      } else {
        handleSendToPipeline(values);
      }
    },
  });

  const buttonsConfig = [
    {
      backgroundColor: whiteColor,
      color: darkCharcoalColor,
      outline: true,
      buttonText: "Cancel",
      onclick: closeModal,
    },
    {
      backgroundColor: darkblueColor,
      color: whiteColor,
      outline: false,
      buttonText: getBtnState("Save", loading),
      onclick: formik.handleSubmit,
    },
  ];

  return (
    <>
      <Modal
        open={open}
        width="647px"
        maxWidth="lg"
        closeModal={closeModal}
        styles={{ borderRadius: guttersPx.mediumHalf }}
      >
        <ModalContainer>
          <ModalHeader
            component={<ModalHeading heading={title} />}
            showClose={true}
            onclose={closeModal}
          />
          <InputContainer>
            <Label>Name</Label>
            <InputBox
              fullborder
              type="text"
              placeholder={"Enter the list name"}
              name="searchname"
              value={formik.values.searchname}
              onChange={formik.handleChange}
              autocomplete="off"
              error={formik.errors.searchname}
              Icon="none"
            />
          </InputContainer>
          <InputContainer>
            <Label>Tags</Label>
            <MultiInputEnter
              options={employees}
              color={orangeColor}
              formik={formik}
            />
          </InputContainer>
          <ModalFooter
            componentRight={<ComboButtons buttons={buttonsConfig} />}
          />
        </ModalContainer>
      </Modal>
    </>
  );
};

export default LeadModal;
