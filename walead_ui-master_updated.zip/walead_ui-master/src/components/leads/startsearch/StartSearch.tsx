// Importing required modules and components

import {
  typographyCaptionNormal,
  typographyParagraph,
  typographySubtitle2Normal,
} from "@/styles/typography";
import styled from "@emotion/styled";
import React, { useState } from "react";
import Image from "next/image";
import {
  buttonCursor,
  darkblueColor,
  fontWeightNormal,
  greyColor,
  guttersPx,
  lightSilverColor,
  viewPortHeight,
} from "@/styles/variables";
import {
  AntiClockSVG,
  LongBackArrowSVG,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { useLeadsContext } from "@/context/leads/leadContext";
import dayjs from "dayjs";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import LeadModal from "../leadmodal/LeadModal";
import { Data } from "../People";
// Common Flex styles

const CommonFlex = {
  display: "flex",
  alignItems: "center",
};
// Styled components for different elements

const StartSearchContainer = styled.div`
  flex-direction: column;
  justify-content: center;
  height: ${viewPortHeight};
  position: relative;
  ${CommonFlex};
`;

const ParaText = styled.div`
  font-weight: ${fontWeightNormal};
  font-size: 18px;
  text-align: center;
  width: 310px;
  padding-bottom: 60px;
`;

const Flex = styled.div`
  ${CommonFlex};
  gap: ${guttersPx.medium};
  justify-content: center;
  padding-bottom: 35px;
`;

const RecentSearch = styled.div`
  ${typographyParagraph}
`;
const TableBoxContainer = styled.div`
  width: 462px;
  height: fit-content;
  box-shadow: 0px 1px 3px 1px #00000040;
`;

const TableBox = styled.div`
  ${CommonFlex};
  justify-content: space-between;
  border-bottom: 1px solid ${lightSilverColor};
  padding: ${guttersPx.small};
`;

const Date = styled.div`
  ${typographyCaptionNormal};
  color: ${darkblueColor};
`;

const Heads = styled.div`
  ${typographyCaptionNormal};
  color: ${greyColor};
`;

const Save = styled.div`
  cursor: ${buttonCursor};
  ${typographyCaptionNormal};
  color: ${darkblueColor};
`;
const ImageWrapper = styled.div`
  padding-bottom: ${guttersPx.medium};
`;
const ArrowWithText = styled.div`
  position: absolute;
  left: 20px;
  top: 100px;
`;
const Arrowtext = styled.div`
  ${typographySubtitle2Normal};
  width: 140px;
`;

const LeftWrapper = styled.div`
  ${flexStyle};
  gap: ${guttersPx.extraLarge};
`;
// StartSearch component definition
interface StartSearchProps {
  saveHandler: (arg: any) => void;
  totalCount: string;
  filtervalues: Data[];
}
const StartSearch: React.FC<StartSearchProps> = ({
  saveHandler,
  totalCount,
}) => {
  const [isSaveSearch, setIsSaveSearch] = useState(false);
  const [filterOption, setFilterOption] = useState({});
  const handleOpenSaveSearch = (databyId: React.SetStateAction<{}>) => {
    setIsSaveSearch(true);
    setFilterOption(databyId);
  };
  const handleCloseSaveSearch = () => setIsSaveSearch(false);
  const { filterSaveListData } = useLeadsContext();
  const filterList = filterSaveListData?.filter(
    (item: { isSaveSearch: boolean }) => !item.isSaveSearch,
  );

  return (
    <StartSearchContainer>
      <ArrowWithText>
        <LongBackArrowSVG />
        <Arrowtext>Add filters to begin your search </Arrowtext>
      </ArrowWithText>
      <ImageWrapper>
        <Image
          src="/assets/images/leads/Group.png"
          width={240}
          height={117}
          alt="Recent search icon"
        />
      </ImageWrapper>

      <ParaText>
        Start your people search by applying filters on the left side
      </ParaText>
      <Flex>
        <AntiClockSVG />
        <RecentSearch>Recent Searches</RecentSearch>
      </Flex>
      <TableBoxContainer>
        {filterList
          ?.slice(0, 5)
          ?.map(
            (item: {
              filterOptions: any;
              tags: string[];
              updated_at: string;
              id: React.Key;
            }) => {
              return (
                <TableBox key={item.id}>
                  {" "}
                  <LeftWrapper>
                    <Date>
                      {dayjs(item?.updated_at).format("YYYY-MM-DD h:mm A")}
                    </Date>
                    <Heads onClick={() => saveHandler(item?.filterOptions)}>
                      {item?.filterOptions?.map(
                        (val: { value: string[] }, index: React.Key) => (
                          <React.Fragment key={index}>
                            {val?.value.join(",")}
                            {index === item.filterOptions.length - 1
                              ? ""
                              : " , "}
                          </React.Fragment>
                        ),
                      )}
                    </Heads>
                  </LeftWrapper>
                  <Save onClick={() => handleOpenSaveSearch(item)}>Save</Save>
                </TableBox>
              );
            },
          )}
        <LeadModal
          closeModal={handleCloseSaveSearch}
          open={isSaveSearch}
          defaultData={filterOption}
          totalCount={totalCount}
          isEdit
        />
      </TableBoxContainer>
    </StartSearchContainer>
  );
};

export default StartSearch;
