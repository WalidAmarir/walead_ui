"use client";
import React from "react";

const error = () => {
  return <div>error in reset password screen</div>;
};

export default error;
