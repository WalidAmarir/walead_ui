"use client";

import React from "react";

const loading = () => {
  return <div>loading</div>;
};

export default loading;
