"use client";
import React from "react";

const error = () => {
  return <div>error in forget password...</div>;
};

export default error;
