"use client";
import Login from "@/components/auth/login/Login";
import React from "react";

const page = () => {
  return (
    <>
      <Login />
    </>
  );
};

export default page;
