"use client";
import SignUp from "@/components/auth/signUp/SignUp";
import React from "react";

const page = () => {
  return (
    <>
      <SignUp />
    </>
  );
};

export default page;
