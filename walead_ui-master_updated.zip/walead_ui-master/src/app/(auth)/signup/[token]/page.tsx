"use client";
import SignUp from "@/components/auth/signUp/SignUp";
import React from "react";

const page = ({ params }: { params: { token: string } }) => {
  return (
    <div>
      <SignUp token={params?.token} />
    </div>
  );
};

export default page;
