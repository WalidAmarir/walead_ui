"use client";
// Importing components and hooks

import Landing from "@/components/landing/Landing";
import LandingNextSection from "@/components/landing/LandingNextSection";
import { useAuth } from "@/context/auth/authContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import LandingLayout from "./landingLayout";

// Default component for initial route
export default function Home() {
  // Initializing router and auth context

  const router = useRouter();
  const { isLoggedIn } = useAuth();

  // Effect to redirect user to dashboard if logged in

  useEffect(() => {
    if (isLoggedIn) {
      router.push("/dashboard");
    }
  }, [isLoggedIn, router]);

  // Rendering Landing components within LandingLayout
  return (
    <LandingLayout>
      <Landing />
      <LandingNextSection />
    </LandingLayout>
  );
}
