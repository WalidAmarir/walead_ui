"use client";
// Importing React and LinkedInCallback component

import React from "react";
import { LinkedInCallback } from "react-linkedin-login-oauth2";

// Callback page component for LinkedIn OAuth2 authentication

const page = () => {
  return <LinkedInCallback />;
};

export default page;
