"use client";

import MessageCard from "@/components/ui/MessageCard/MessageCard";
import React from "react";

const page = () => {
  return (
    <MessageCard title="Error" message="Something went wrong"></MessageCard>
  );
};

export default page;
