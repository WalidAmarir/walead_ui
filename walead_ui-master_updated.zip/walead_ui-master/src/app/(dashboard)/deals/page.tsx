"use client";
import DealList from "@/components/deals/DealList";
import DealListHeader from "@/components/deals/DealListHeader";
// component for the deal import and management page.
import WelcomeModal from "@/components/ui/modal/deals/WelcomeModal";
import { useDealContext } from "@/context/deal/dealContext";
import { useQueryContext } from "@/context/query/queryContext";
import usePageVisibility from "@/hooks/usePageVisibility";
import { pipeLineValidation } from "@/utils/formUtils/validations/ValidationUtils";
import { filterById } from "@/utils/optionUtils";

import { useFormik } from "formik";
import { useEffect, useMemo, useState } from "react";

// this component renders the user interface for importing and managing deals.
const Page = () => {
  // It queries data related to the kanban board using useQueryContext and useLazyQuery hooks.
  const [welcome, setWelcome] = useState(false);

  const {
    data: kanbanBoardvalue,
    teammembers,
    isEmptyDeal,
    setDealfilterData,
    setMembersByPipelineId,
    profiledata,
  } = useQueryContext();
  const { handleheaderActions, headerActions, isDefaultID, filteredPipeLines } =
    useDealContext();
  const isTabActive = usePageVisibility();
  const { isAdd, isEdit } = headerActions;
  const isAction = !isAdd && !isEdit;
  const handleWelcomPopup = () => {
    setWelcome(true);
  };

  useEffect(() => {
    const showWelcomePopup = () => {
      if (kanbanBoardvalue?.kanbanBoard && isEmptyDeal) {
        handleWelcomPopup();
      } else {
        setWelcome(false);
      }
    };
    showWelcomePopup();
  }, [kanbanBoardvalue, isEmptyDeal]);

  const {
    values,
    handleChange,
    errors,
    setFieldValue,
    isValid,
    handleSubmit,
    resetForm,
  }: any = useFormik({
    initialValues: {
      memberIds: isAdd ? [profiledata?.getUserDetailsById?.id] : [],
      status: "All",
      pipelineId: isDefaultID?.id,
      pipelineName: "",
    },
    validationSchema: pipeLineValidation,
    enableReinitialize: true,
    onSubmit: () => {
      console.log("test");
    },
  });
  const statusValue = useMemo(() => {
    return values.status === "All" ? [] : [values.status];
  }, [values.status]);

  useEffect(() => {
    if (!isAdd) {
      const finalValue = {
        status: statusValue,
        memberIds: values?.memberIds,
        pipelineId: values?.pipelineId,
      };
      setDealfilterData(finalValue);
    }
  }, [statusValue, values?.memberIds, values?.pipelineId, isTabActive]);

  const membersByPipelineId = useMemo(() => {
    const findMembers =
      filteredPipeLines?.find(
        (member: { id: string }) => member.id === values?.pipelineId,
      ) ?? [];
    const filteredBudgetData = filterById(
      findMembers?.teamMembers,
      teammembers?.getTeamMembersByCompanyId,
    );
    const isDefaultPipeline =
      isDefaultID?.id === values?.pipelineId
        ? teammembers?.getTeamMembersByCompanyId
        : filteredBudgetData;
    setMembersByPipelineId(isDefaultPipeline);
    return isDefaultPipeline;
  }, [values?.pipelineId, filteredPipeLines, teammembers, isDefaultID]);
  return (
    <>
      <DealListHeader
        handleChange={handleChange}
        handleSelect={handleChange}
        budgeData={membersByPipelineId}
        values={values}
        errors={errors}
        isValid={isValid}
        handleheaderActions={handleheaderActions}
        isAction={isAction}
        isAdd={isAdd}
        isEdit={isEdit}
        setFieldValue={setFieldValue}
        resetForm={resetForm}
        handleSubmit={handleSubmit}
      />
      <DealList
        isPipelineAction={isAction}
        membersByPipelineId={membersByPipelineId}
      />
      <WelcomeModal isOpen={welcome} onClose={handleWelcomPopup} />
    </>
  );
};

export default Page;
