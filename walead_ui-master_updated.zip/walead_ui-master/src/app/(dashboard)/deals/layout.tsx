"use client";
import DealContextProvider from "@/context/deal/DealContextProvider";
import { Props } from "@/utils/hoc/withPrivateRoute";
import React from "react";

const layout = ({ children }: Props) => {
  return (
    <>
      <DealContextProvider>{children}</DealContextProvider>
    </>
  );
};

export default layout;
