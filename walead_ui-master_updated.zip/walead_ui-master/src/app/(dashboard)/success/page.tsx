"use client";
// Importing React and MessageCard component

import MessageCard from "@/components/ui/MessageCard/MessageCard";
import React from "react";

// Success page component for redirection after payment success
const page = () => {
  // Rendering MessageCard component with success message
  return (
    <MessageCard
      title="Success"
      message="You are now subscribed to your current plan"
    />
  );
};

export default page;
