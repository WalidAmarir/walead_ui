"use client";

// Importing React and necessary components/hooks
import CalendarPage from "@/components/schedulePost/ScheduleCalender";
import { GroupBadge } from "@/components/ui/avatar/Avatar";
import Dropdown from "@/components/ui/input/DropDown";
import AddMemberSocial from "@/components/ui/modal/schedulePost/addmember/AddMemberSocial";
import CreateTeam from "@/components/ui/modal/schedulePost/CreateTeam";
import TeamsAccount from "@/components/ui/modal/schedulePost/TeamsAccount";
import { useQueryContext } from "@/context/query/queryContext";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import ScheduledContextProvider from "@/context/schedule/ScheduledContextProvider";
import { darkblueColor } from "@/styles/variables";
import { AddIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React, { useEffect, useMemo, useState } from "react";

interface FormValues {
  teamMembers: string[];
}
// Page component for post scheduling

const Page = () => {
  const { accountActionType, teammembers, handleAccountActionType, dealData } =
    useQueryContext();
  const [isOpen, setIsOpen] = useState(false);
  const handleClose = () => {
    setIsOpen(false);
    handleAccountActionType("");
  };

  const handleItemClick = (item: string) => {
    setIsOpen(true);
    handleAccountActionType(item);
  };

  // Generating modal content based on action type
  const getModal = useMemo(() => {
    if (accountActionType === "Add member") {
      return <AddMemberSocial open={isOpen} onclose={handleClose} />;
    } else if (accountActionType === "Create a new team") {
      return <CreateTeam open={isOpen} onclose={handleClose} />;
    } else {
      return <TeamsAccount open={isOpen} onclose={handleClose} />;
    }
  }, [accountActionType, isOpen]);

  // Rendering page content within ScheduledContextProvider
  return (
    <ScheduledContextProvider>
      <MainContainer isPadding={!!dealData}>
        <TeamMembers
          data={teammembers?.getTeamMembersByCompanyId}
          handleItemClick={handleItemClick}
        />
        <CalendarPage />
      </MainContainer>
      {getModal}
    </ScheduledContextProvider>
  );
};

export default Page;

// Styled components
const MainContainer = styled.div<{
  isPadding: boolean;
}>(
  ({ isPadding = false }) => css`
    padding: ${isPadding ? "10px" : 0};
  `,
);
const BudgeWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
  margin-bottom: 5px;
  & :nth-child(1) {
    margin: 0;
  }
`;
const IconWrapper = styled.div`
  border-radius: 100px;
  border: 1px solid ${darkblueColor};
  width: 43px;
  height: 43px;
`;

// Options for dropdown menu
const options = [
  {
    id: 2,
    name: "Create a new team",
    value: "Create a new team",
  },
  {
    id: 3,
    name: "Team Accounts",
    value: "Team Accounts",
  },
];

// TeamMembers component for managing team members in post scheduling.

const TeamMembers = ({
  handleItemClick,
  data,
}: {
  handleItemClick: (arg: string) => void;
  data: any;
}) => {
  const { searchPosts, isMember, setIsMember } = useScheduledContext();
  const { values, handleChange, resetForm }: any = useFormik<FormValues>({
    initialValues: {
      teamMembers: [],
    },
    onSubmit: () => {
      console.log("test");
    },
  });

  useEffect(() => {
    setIsMember(values.teamMembers.length > 0);
    searchPosts(
      values.teamMembers.length > 0
        ? { teamMembers: values.teamMembers }
        : { search: "" },
    );
  }, [values.teamMembers]);

  useEffect(() => {
    if (!isMember) {
      resetForm();
    }
  }, [isMember]);
  return (
    <BudgeWrapper>
      <IconWrapper>
        <Dropdown items={options} onItemClick={handleItemClick}>
          <AddIcon width={"41"} height={"41"} />
        </Dropdown>
      </IconWrapper>
      <GroupBadge
        data={data || []}
        dimension={"43"}
        name="teamMembers"
        imgDimension={43}
        isBudge
        selectable
        defaultValues={values.teamMembers}
        handleCheked={handleChange}
      />
    </BudgeWrapper>
  );
};
