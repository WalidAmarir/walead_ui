"use client";

// component for managing user profile and account-related actions.
import React, { useEffect } from "react";
import styled from "@emotion/styled";
import {
  fullWidth,
  lightGreyColor,
  darkCharcoalColor,
  guttersPx,
} from "@/styles/variables";
import { useQueryContext } from "@/context/query/queryContext";
import { typographyH2 } from "@/styles/typography";
import TabComponent from "@/components/ui/tabs/TabComponent";
import {
  BillingIcon,
  PaymentIcon,
  ProfileIcon,
  WorkSpaceIcon,
} from "@/utils/formUtils/InputSvg/InputSvg";
import WorkSpace from "@/layouts/userprofile/profileactions/account/workspace/WorkSpace";
import Profile from "@/layouts/userprofile/profileactions/account/profile/Profile";
import Billing from "@/layouts/userprofile/profileactions/billing/Billing";
import { PricingPoints } from "@/utils/constant";
import PaymentInvoice from "@/layouts/userprofile/profileactions/billing/PaymentInvoice";
import { useQuery } from "@apollo/client";
import { GET_SUBSCRIBTION } from "@/lib/graphql/queries/getSubscription";

interface ChildComponent {
  label: string;
  icon: JSX.Element;
  content: JSX.Element;
  heading?: string;
}

interface ParentComponent {
  label: string;
  child: ChildComponent[];
}

const CenteredContainer = styled.div`
  background: ${lightGreyColor};
  width: ${fullWidth};
  padding: ${guttersPx.medium} 60px;
  height: 100%;
  min-height: 100vh;
`;
const SubContainer = styled.div``;
const ProfileHeading = styled.div`
  color: ${darkCharcoalColor};
  ${typographyH2}
`;
const TabWrapper = styled.div`
  padding: ${guttersPx.extraLarge} 0;
`;

// This component renders a user profile page with tabs for different account actions.

const Page = () => {
  const { profiledata, handleSubscriptionDetails, loader } = useQueryContext();
  const { fullName, role } = profiledata?.getUserDetailsById || {};
  const { data } = useQuery(GET_SUBSCRIBTION, {
    fetchPolicy: "no-cache",
  });

  useEffect(() => {
    handleSubscriptionDetails(data?.getSubscription);
  }, [data, handleSubscriptionDetails]);

  function filterComponents(
    childcomponents: ParentComponent[],
    userrole: string,
  ): ParentComponent[] {
    if (userrole === "Owner" || userrole === "Admin") {
      return childcomponents;
    } else {
      return childcomponents
        .filter((component) => component.label !== "Billing & Usage")
        .map((childComp) => {
          return {
            ...childComp,
            child: childComp.child.filter(
              (item) => item.label !== "Workspace & members",
            ),
          };
        });
    }
  }

  const componentsByRole = filterComponents(components, role?.role);

  return (
    <CenteredContainer>
      {/* Loader is displayed while fetching data, and the user profile data is rendered once loaded. */}
      {loader ? (
        "loading data..."
      ) : (
        <SubContainer>
          <ProfileHeading>Hello, {fullName}!</ProfileHeading>
          <TabWrapper>
            {/* The content components are rendered based on the selected tab. */}
            <TabComponent tabs={componentsByRole} />
          </TabWrapper>
        </SubContainer>
      )}
    </CenteredContainer>
  );
};
export default Page;

// The components object defines the structure of tabs and their contents.
// Each tab consists of a label, icon, and content component.
const components = [
  {
    label: "Account",
    child: [
      {
        label: "Profile",
        icon: <ProfileIcon />,
        content: <Profile />,
        heading: "Profile",
      },
      {
        label: "Workspace & members",
        icon: <WorkSpaceIcon />,
        content: <WorkSpace />,
        heading: "Workspace",
      },
    ],
  },
  {
    label: "Billing & Usage",
    child: [
      {
        label: "Billing",
        icon: <BillingIcon />,
        content: (
          <Billing
            keypoints={PricingPoints}
            topimage="/assets/images/manonsofa.png"
            showButton={true}
          />
        ),
      },
      {
        label: "Payment & invoices",
        icon: <PaymentIcon />,
        content: <PaymentInvoice />,
      },
    ],
  },
];
