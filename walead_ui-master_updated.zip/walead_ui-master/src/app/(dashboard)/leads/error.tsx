"use client";

const error = () => {
  return <div>error</div>;
};

export default error;
