"use client";
import React from "react";
import styled from "@emotion/styled";
import {
  fullWidth,
  lightGreyColor,
  guttersPx,
  darkCharcoalColor,
  darkblueColor,
  viewPortHeight,
} from "@/styles/variables";
import TabComponent from "@/components/ui/tabs/TabComponent";
import {
  LeadTab1IconSVG,
  LeadTab2IconSVG,
} from "@/utils/formUtils/InputSvg/InputSvg";
import SavedList from "@/components/leads/SavedList";
import People from "@/components/leads/People";
import LeadContextProvider from "@/context/leads/LeadsContextProvider";

const CenteredContainer = styled.div`
  background: ${lightGreyColor};
  width: ${fullWidth};
  padding: ${guttersPx.medium};
  height: ${fullWidth};
  min-height: ${viewPortHeight};
`;
const SubContainer = styled.div``;

const Page = () => {
  const [activeTab, setactiveTab] = React.useState(0);

  const callbackHorizontalTabNum = (val: number) => {
    setactiveTab(val);
  };

  const components = [
    {
      label: "People",
      icon: (
        <LeadTab1IconSVG
          color={activeTab ? darkCharcoalColor : darkblueColor}
        />
      ),
      content: <People />,
      heading: "People",
    },
    {
      label: "Saved List",
      icon: (
        <LeadTab2IconSVG
          color={activeTab ? darkblueColor : darkCharcoalColor}
        />
      ),
      content: <SavedList />,
      heading: "Saved List",
    },
  ];

  return (
    <LeadContextProvider>
      <CenteredContainer>
        <SubContainer>
          <TabComponent tabs={components} onChange={callbackHorizontalTabNum} />
        </SubContainer>
      </CenteredContainer>
    </LeadContextProvider>
  );
};
export default Page;
