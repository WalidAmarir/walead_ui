"use client";
import React, { useEffect, useMemo, useState } from "react";
import AcceleratorCard from "@/components/ui/CardContainer/AcceleratorCard";
import styled from "@emotion/styled";
import { blackColor, guttersPx } from "@/styles/variables";
import { typographyParagraph } from "@/styles/typography";
import SearchBarInput from "@/components/ui/input/SearchBarInput";
import PopupCard from "@/components/ui/CardContainer/PopupCard";
import { GET_ACCELERATORS } from "@/lib/graphql/queries/getAccelerators";
import { useLazyQuery, useMutation } from "@apollo/client";
import ProgressBar from "@/components/ui/input/ProgressBar";
import { COURSE_ACCELERETOR_RATING } from "@/lib/graphql/mutation/updateAccelerator";
import { formatNumberToDecimalPlaces } from "@/utils/helperUtils";
const Container = styled.div`
  padding: ${guttersPx.medium};
`;
const FlexContainer = styled.div`
  display: flex;
  align-items: center;
`;
const DivContainer = styled(FlexContainer)`
  justify-content: space-between;
  margin-bottom: ${guttersPx.medium};
`;
const DivLeft = styled.div``;
const DivRight = styled.div`
  .input-icon {
    z-index: 1;
  }
`;
const ProgressTitle = styled.div`
  ${typographyParagraph};
  color: ${blackColor};
`;
export interface DetailsProps {
  [key: string]: any;
}
interface Accelerator {
  status: unknown;
  node: {
    status: boolean;
  };
}

const ProgressContainer = styled(FlexContainer)``;
const Page = () => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const [acceleratorDetails, setAcceleratorsDetails] = useState<DetailsProps>(
    {},
  );
  const [fetchAccelerators, { data, loading, refetch }] = useLazyQuery(
    GET_ACCELERATORS,
    { fetchPolicy: "no-cache" },
  );

  const [handleUpdateRating] = useMutation(COURSE_ACCELERETOR_RATING, {
    onCompleted: refetch,
  });

  const updateRating = (id: string, rating: string) => {
    handleUpdateRating({
      variables: {
        input: {
          accelerator: id,
          rating: rating,
        },
      },
    });
  };
  const hanldeSearch = (e: {
    target: { value: React.SetStateAction<string> };
  }) => {
    setSearch(e.target.value);
  };

  useEffect(() => {
    fetchAccelerators({
      variables: {
        search: search,
      },
    });
  }, [search, fetchAccelerators]);

  const { accelerators } = data ?? {};

  const filteredData = useMemo(() => {
    const filterValue: Accelerator[] =
      accelerators?.edges?.map(({ node }: any) => ({ ...node })) ?? [];
    return filterValue?.filter((item) => item.status);
  }, [data]);

  const handleView = () => {
    setOpen(!open);
  };

  const totoalAvgProgress = formatNumberToDecimalPlaces(
    accelerators?.totalAvgProgress,
    2,
  );

  return (
    <Container>
      {open ? (
        <PopupCard
          updateRating={updateRating}
          setOpen={handleView}
          details={acceleratorDetails}
        />
      ) : (
        <>
          <DivContainer>
            <DivLeft>
              <ProgressTitle>Overal progress</ProgressTitle>
              <ProgressContainer>
                <ProgressBar
                  value={totoalAvgProgress}
                  loading={loading}
                  isLabel
                />
              </ProgressContainer>
            </DivLeft>
            <DivRight>
              <SearchBarInput search={search} handleSearch={hanldeSearch} />
            </DivRight>
          </DivContainer>
          <AcceleratorCard
            setOpen={handleView}
            setDetails={setAcceleratorsDetails}
            data={filteredData}
            loading={loading}
          />
        </>
      )}
    </Container>
  );
};
export default Page;
