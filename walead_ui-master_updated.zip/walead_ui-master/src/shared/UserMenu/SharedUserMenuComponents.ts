import SmallButton from "@/components/ui/button/SmallButton";
import { mqMax } from "@/styles/base";
import {
  typographyBody2,
  typographyCaptionNormal,
  typographyParagraph,
  typographySubtitle1,
} from "@/styles/typography";
import { DataGrid } from "@mui/x-data-grid";

import {
  borderRadiusTiny,
  buttonCursor,
  darkblueColor,
  darkCharcoalColor,
  fontFamily,
  fontWeightSemibold,
  greyColor,
  gutters,
  guttersPx,
  lightBlueColor,
  whiteColor,
} from "@/styles/variables";
import { css } from "@emotion/core";
import styled from "@emotion/styled";
import Link from "next/link";

export const StyledInput = styled.input(
  [typographySubtitle1],
  css`
    border: none;
    width: 100%;
    min-height: ${gutters.large * 2}px;
    border-bottom: 0.8px solid ${greyColor};
    padding-left: ${gutters.small}px;
    color: ${darkCharcoalColor};
    background-color: ${whiteColor};
    &::placeholder {
      color: ${darkCharcoalColor};
      font-weight: ${fontWeightSemibold};
    }
    &:focus {
      outline: none;
    }
    &:focus::placeholder {
      color: #ccc; /* Placeholder color when focused */
    }
    &:read-only {
      cursor: default;
    }
  `,
);
export const ErrorMessage = styled.span(
  [typographyBody2],
  css`
    font-size: ${guttersPx.mediumHalf};
    color: red;
    padding: 0 ${guttersPx.mediumHalf};
  `,
);

export const ButtonFlex = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
`;

const Button = styled(SmallButton)`
  width: 105px;
  height: 36px;
  border-radius: 5px;
  font-size: 14px;
`;

export const DraftButton = styled(Button)<{
  isHide?: boolean;
}>(
  ({ isHide = true }) => css`
    background: white;
    color: ${darkCharcoalColor};
    display: ${!isHide ? "none" : "block"};
    border: 1px solid ${darkCharcoalColor};
    box-shadow: none;
    &:hover {
      border: 1px solid ${darkblueColor};
      background: ${whiteColor};
      color: ${darkblueColor};
    }
  `,
);

export const ScheduleButton = styled(Button)<{
  isHide?: boolean;
}>(
  ({ isHide = true }) => css`
    background: ${darkblueColor};
    display: ${!isHide ? "none" : "block"};
    box-shadow: none;
    &:hover {
      border: 1px solid ${darkblueColor};
      background: ${whiteColor};
      color: ${darkblueColor};
    }
  `,
);

const BASE_URL = process.env.AWS_S3_URL;
console.log(BASE_URL);
export const imageLoader = ({ src, width, quality }: any) => {
  return `${BASE_URL}/${src}?w=${width}&q=${quality || 75}`;
};

export const HR = styled.hr<{
  color?: string;
}>(
  ({ color = "#878787" }) => css`
    color=${color}
  `,
);

export const InputFlex = styled.div<{
  pr?: string;
  gap?: string;
}>(
  ({ gap = "40px", pr = guttersPx.medium }) => css`
    display: flex;
    gap: ${gap};
    padding-right: ${pr};
  `,
);

export const InputContainer = styled.div<{
  width?: string;
}>(
  ({ width = "100%" }) => css`
    width: ${width};
  `,
);

export const ButtonContainer = styled.div`
  display: flex;
  justify-content: end;
`;

export const InputIconWrapper = styled.div`
  position: relative;
  svg {
    position: absolute;
    top: 20%;
    right: 10px;
  }
`;

export const StyledLink = styled(Link)`
  color: ${darkblueColor};
`;

const menuStyle = {
  background: whiteColor,
  borderRadius: "2px",
  m: "5px",
};

export const selectInputProp = {
  MenuProps: {
    PaperProps: {
      style: {
        border: `1px solid ${greyColor}`,
      },
    },
    sx: {
      "&& .Mui-selected": {
        backgroundColor: darkblueColor,
        color: `${whiteColor} !important`,
        fontFamily: fontFamily,
        "&:hover": {
          backgroundColor: darkblueColor,
        },
      },
    },
    MenuListProps: {
      sx: { ...menuStyle },
    },
  },
};

export const flexStyle = `
display: flex;
align-items: center;
`;

type ContainerProps = {
  maxWidth?: string;
  width?: string;
  minWidth?: string;
  padding?: string;
};

export const Container = styled.div<ContainerProps>`
  max-width: ${(props) => props.maxWidth || "100%"};
  width: ${(props) => props.width || "100%"};
  min-width: ${(props) => props.minWidth || "0"};
  padding: ${(props) => props.padding || "0"};
`;

export const InputWrapperWithBottomBorder = styled.div`
  input {
    border: none;
    border-bottom: 1px solid ${greyColor};
    &:focus {
      border: none !important;
      border-bottom: 1px solid ${darkblueColor} !important;
    }
  }
`;
export const svgStyle = {
  cursor: "pointer",
};

export const chekIndex = (fIndex: string | number, lIndex: string | number) => {
  let style: string = "";
  if (fIndex !== lIndex) {
    style += `&::before {
      content: "";
      position: absolute;
      right: -9px;
      ${mqMax.desktop}{
        right: -8px;
      };
      bottom: 0;
      width: 0;
      top:0;
      height: 0;
      border-left: 10px solid #a8d8cc;
      border-top: 25px solid transparent;
      border-bottom: 24px solid transparent;
    }`;
  }
  if (fIndex !== 0) {
    style += `&::after {
    content: "";
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    width: 0;
    height: 0;
    border-left: 10px solid white;
    border-top: 25px solid transparent;
    border-bottom: 25px solid transparent;`;
  }
  return style;
};

export const StyledDataGrid = styled(DataGrid)`
  .MuiDataGrid-row.Mui-selected {
    border-radius: ${borderRadiusTiny};
    background: ${lightBlueColor};
  }
  .MuiDataGrid-root {
    border: none;
  }
  .MuiDataGrid-cell {
    border: none;
  }
  .columnHeaderTitle {
    ${typographyParagraph};
    color: ${darkCharcoalColor};
    cursor: ${buttonCursor};
  }
  .cellContent {
    color: ${darkCharcoalColor};
    ${typographyCaptionNormal};
    cursor: ${buttonCursor};
  }
`;
