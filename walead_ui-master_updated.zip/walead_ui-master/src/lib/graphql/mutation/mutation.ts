import { gql } from "@apollo/client";
export const CREATE_USER = gql`
  mutation CreateUser($input: CreateUserInput!) {
    createUser(input: $input) {
      id
      email
      mobileNumber
      countryCode
      jobRole
      experience
      firstWishlist
      weLeadUserInCompany
      fullName
      companySize
      profilePicture
      industry
      login_isActive
      linkedinUserName
      isConnectedOnLinkedin
      timeZone
    }
  }
`;
