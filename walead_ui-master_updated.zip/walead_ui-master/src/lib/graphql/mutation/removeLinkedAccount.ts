import { gql } from "@apollo/client";
export const REMOVE_LINKEDIN_ACCOUNTS = gql`
  mutation Mutation {
    removeLinkedAccount
  }
`;
