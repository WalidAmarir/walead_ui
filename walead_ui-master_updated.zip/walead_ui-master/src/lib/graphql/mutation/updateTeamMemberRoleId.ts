import { gql } from "@apollo/client";

export const UPDATE_TEAM_MEMBER_ROLE = gql`
  mutation UpdateTeamMemberRole(
    $role: String
    $updateTeamMemberRoleId: String
  ) {
    updateTeamMemberRole(role: $role, id: $updateTeamMemberRoleId)
  }
`;
