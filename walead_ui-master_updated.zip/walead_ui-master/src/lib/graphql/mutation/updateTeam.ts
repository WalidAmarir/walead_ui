import { gql } from "@apollo/client";

export const UPDATE_TEAM = gql`
  mutation UpdateTeam($input: UpdateTeamInput) {
    updateTeam(input: $input) {
      id
      teamMembers
      teamName
      createdBy
    }
  }
`;
