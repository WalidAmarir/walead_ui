import { gql } from "@apollo/client";

export const UPDATE_SAVE_SEARCH = gql`
  mutation UpdateSaveSearch($input: UpdateSaveSearchInput) {
    updateSaveSearch(input: $input)
  }
`;
