import { gql } from "@apollo/client";
export const SEND_LEAD_TO_PIPELINE = gql`
  mutation SendLeadToPipeline($input: SendLeadToPipelneInput) {
    sendLeadToPipeline(input: $input)
  }
`;
