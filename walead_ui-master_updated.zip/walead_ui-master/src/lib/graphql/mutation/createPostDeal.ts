import { gql } from "@apollo/client";
export const CREATE_POST_DEAL = gql`
  mutation CreatePostDeal($input: postDealAssosiantionInput) {
    createPostDeal(input: $input)
  }
`;
