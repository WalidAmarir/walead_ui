import { gql } from "@apollo/client";
export const COURSE_ACCELERETOR_RATING = gql`
  mutation AcceleratorRating($input: AcceleratorRatingInput) {
    acceleratorRating(input: $input) {
      id
      rating
      accelerator
    }
  }
`;
