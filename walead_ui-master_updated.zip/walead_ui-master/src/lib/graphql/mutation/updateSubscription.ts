import { gql } from "@apollo/client";

export const UPDATE_SUBSCRIPTION = gql`
  mutation UpdateSubscription($input: updateSessionInput) {
    updateSubscription(input: $input)
  }
`;
