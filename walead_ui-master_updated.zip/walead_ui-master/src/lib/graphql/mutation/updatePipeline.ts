import { gql } from "@apollo/client";

export const UPDATE_PIPELINE = gql`
  mutation UpdatePipeline($input: UpdatePipelineInput) {
    updatePipeline(input: $input)
  }
`;
