import { gql } from "@apollo/client";
export const CREATE_SCHEDULE_POST = gql`
  mutation CreatePost($input: PostInput) {
    createPost(input: $input) {
      commentId
      content
    }
  }
`;
