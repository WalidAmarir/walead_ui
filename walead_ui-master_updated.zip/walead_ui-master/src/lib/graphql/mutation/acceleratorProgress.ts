import { gql } from "@apollo/client";
export const ACCELERETOT_PROGRESS = gql`
  mutation AcceleratorProgress($input: AcceleratorProgressInput) {
    acceleratorProgress(input: $input) {
      id
      accelerator
      course
      progress
    }
  }
`;
