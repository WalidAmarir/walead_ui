import { gql } from "@apollo/client";
export const CREATE_SAVE_SEARCH = gql`
  mutation CreateSaveSearch($input: SaveSearchInput) {
    createSaveSearch(input: $input)
  }
`;
