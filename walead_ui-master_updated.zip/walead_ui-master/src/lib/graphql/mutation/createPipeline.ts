import { gql } from "@apollo/client";
export const CREATE_PIPE_LINE = gql`
  mutation CreatePipeline($input: PipelineInput) {
    createPipeline(input: $input)
  }
`;
