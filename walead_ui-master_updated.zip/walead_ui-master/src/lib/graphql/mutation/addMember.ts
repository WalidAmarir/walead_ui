import { gql } from "@apollo/client";
export const ADD_A_MEMBER = gql`
  mutation AddMember($input: InviteUserInput) {
    addMember(input: $input)
  }
`;
