import { gql } from "@apollo/client";
export const GET_INVITED_USER_BY_TOKEN = gql`
  query GetInvitedUserByToken($token: String) {
    getInvitedUserByToken(token: $token) {
      email
      token
      company {
        name
        isActive
        id
      }
      role {
        id
        role
        roleConstraint
      }
    }
  }
`;
