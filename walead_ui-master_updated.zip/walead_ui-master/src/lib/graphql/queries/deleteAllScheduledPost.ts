import { gql } from "@apollo/client";
export const DELETE_ALL_SCHEDULED_POST = gql`
  query Query {
    deleteAllScheduledPost
  }
`;
