import { gql } from "@apollo/client";
export const DELETE_PIPELINE_BY_ID = gql`
  query Query($deletePipelineByIdId: String) {
    deletePipelineById(id: $deletePipelineByIdId)
  }
`;
