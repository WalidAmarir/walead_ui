import { gql } from "@apollo/client";
export const LEAD_FINDER_FILTER = gql`
  query LeadFinderFilter {
    leadFinderFilter {
      industry
      employees
      location
      jobTitle
      domain
      keyword
    }
  }
`;
