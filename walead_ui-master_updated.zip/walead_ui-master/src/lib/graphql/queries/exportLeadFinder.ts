import { gql } from "@apollo/client";
export const EXPORT_LEAD_FINDER = gql`
  query ExportLeadFinder($leadCount: String) {
    exportLeadFinder(leadCount: $leadCount) {
      downloadedLead
      availableCreditScore
    }
  }
`;
