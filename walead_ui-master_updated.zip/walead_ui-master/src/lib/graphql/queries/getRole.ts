import { gql } from "@apollo/client";
export const GET_Role = gql`
  query GetRole {
    getRole {
      id
      role
      roleConstraint
    }
  }
`;
