import { gql } from "@apollo/client";
export const DELETE_USER_BY_ID = gql`
  query Query($deleteUserByIdId: String) {
    deleteUserById(id: $deleteUserByIdId)
  }
`;
