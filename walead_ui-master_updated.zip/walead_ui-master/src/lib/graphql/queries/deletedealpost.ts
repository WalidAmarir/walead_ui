import { gql } from "@apollo/client";
export const DELETE_DEAL_POST = gql`
  query Query($ids: [String], $postId: String) {
    deleteDealPost(ids: $ids, postId: $postId)
  }
`;
