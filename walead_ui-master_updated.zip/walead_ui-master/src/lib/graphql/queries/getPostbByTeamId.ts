import { gql } from "@apollo/client";
export const GET_POST_BY_TEAM_ID = gql`
  query GetPostsByTeam($teamId: String) {
    getPostsByTeam(teamId: $teamId) {
      totalCount
      edges {
        node {
          id
          content
          teamMembers
          img
          status
          schedulePostDate
          schedulePostTime
          createdFor {
            id
            email
            fullName
            profilePicture
          }
          createdBy {
            id
            email
            mobileNumber
            countryCode
            jobRole
            experience
            firstWishlist
            company {
              id
              name
              isActive
            }
            weLeadUserInCompany
            fullName
            companySize
            profilePicture
            industry
            login_isActive
          }
          postPublishtDate
          createdAt
          draftPosttDate
          displayDate
        }
        cursor
      }
    }
  }
`;
