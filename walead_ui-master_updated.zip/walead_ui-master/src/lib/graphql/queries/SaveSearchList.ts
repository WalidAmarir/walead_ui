import { gql } from "@apollo/client";

export const SAVE_SEARCH_LIST = gql`
  query SaveSearchList {
    SaveSearchList {
      totalCount
      edges {
        node {
          id
          userId {
            id
            email
            fullName
          }
          name
          lead
          tags
          isSaveSearch
          filterOptions
          created_at
          updated_at
        }
      }
    }
  }
`;
