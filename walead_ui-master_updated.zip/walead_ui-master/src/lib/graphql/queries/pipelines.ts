import { gql } from "@apollo/client";

export const GET_PIPELINES = gql`
  query Pipelines {
    pipelines {
      totalCount
      edges {
        node {
          id
          userId
          pipelineName
          stage {
            id
            userId
            boardName
            isDefault
            isDeleted
            orderBy
          }
          teamMembers
          isDefault
          isDeleted
        }
        cursor
      }
    }
  }
`;
