FOr queries
