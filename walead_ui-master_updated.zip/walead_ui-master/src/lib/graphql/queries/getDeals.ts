import { gql } from "@apollo/client";
export const GET_DEALS = gql`
  query GetDeals($search: String, $pipelineId: String) {
    getDeals(search: $search, pipelineId: $pipelineId) {
      edges {
        node {
          id
          userId
          name
          organization
          value
          valueType
          email
          tags
          leadImage
        }
      }
      totalCount
    }
  }
`;
