import { gql } from "@apollo/client";
export const GET_SCHEDULE_POST = gql`
  query Posts($search: String, $teamMembers: [String]) {
    posts(search: $search, teamMembers: $teamMembers) {
      edges {
        node {
          id
          content
          teamMembers
          img
          status
          schedulePostDate
          schedulePostTime
          postPublishtDate
          createdAt
          draftPosttDate
          dealMember {
            email
            name
            leadImage
            webURL
            id
            organization
            userId
          }
          displayDate
          dbContent
          commentContent
          commentImg
          commentId
          createdBy {
            fullName
            profilePicture
            id
          }
          createdFor {
            id
            email
            fullName
            profilePicture
          }
        }
      }
      totalCount
    }
  }
`;
