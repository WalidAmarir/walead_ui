import { gql } from "@apollo/client";
export const DELETE_STAGE_BY_ID = gql`
  query Query($deleteStageByIdId: String, $updateStageId: String) {
    deleteStageById(id: $deleteStageByIdId, updateStageId: $updateStageId)
  }
`;
