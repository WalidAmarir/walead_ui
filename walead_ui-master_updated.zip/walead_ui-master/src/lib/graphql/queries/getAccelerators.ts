import { gql } from "@apollo/client";
export const GET_ACCELERATORS = gql`
  query Accelerators($search: String) {
    accelerators(search: $search) {
      totalCount
      edges {
        node {
          id
          name
          description
          createdBy {
            id
            email
          }
          img
          status
          createdAt
          avgRating
          highlight
          avgProgress
        }
        cursor
      }
      totalAvgProgress
    }
  }
`;
