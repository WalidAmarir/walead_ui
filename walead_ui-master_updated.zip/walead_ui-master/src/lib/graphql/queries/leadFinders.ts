import { gql } from "@apollo/client";
export const LEAD_FINDERS = gql`
  query LeadFinders(
    $first: Int
    $search: String
    $after: Int
    $filterOptions: JSON
  ) {
    leadFinders(
      first: $first
      search: $search
      after: $after
      filterOptions: $filterOptions
    ) {
      totalCount
      edges {
        node {
          id
          email
          profileImage
          firstName
          lastName
          name
          linkedIn
          title
          headline
          city
          state
          country
          orgNumber
          orgFoundedYear
          organizationLogo
          organizationDomain
          phoneNumber
          organizationID
          organizationName
          organizationWebsite
          inputFilters
        }
        cursor
      }
    }
  }
`;
