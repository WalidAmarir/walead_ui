import { gql } from "@apollo/client";
export const GET_COURSES = gql`
  query Courses($coursesId: String) {
    courses(id: $coursesId) {
      totalCount
      edges {
        node {
          id
          title
          description
          type
          link
          videoUrl
          accelerator {
            id
            name
            description
            createdBy {
              id
              email
            }
            img
            status
            createdAt
            avgRating
          }
          status
          videoTitle
          progress
        }
        cursor
      }
    }
  }
`;
