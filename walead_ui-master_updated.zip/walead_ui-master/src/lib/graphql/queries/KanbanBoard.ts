import { gql } from "@apollo/client";
export const BOARD_DATA = gql`
  query KanbanBoard(
    $status: [String]
    $memberIds: [String]
    $pipelineId: String
  ) {
    kanbanBoard(
      status: $status
      memberIds: $memberIds
      pipelineId: $pipelineId
    ) {
      boardConstraint
      boardName
      dealdata {
        id
        userId
        name
        organization
        value
        valueType
        stage {
          id
          boardName
          boardConstraint
        }
        email
        phone
        phoneType
        linkedin
        calendly
        webURL
        probability
        notes
        estimate
        tags
        teamMembers {
          id
          fullName
          profilePicture
          isConnectedOnLinkedin
        }
        leadImage
        isincomplete
        expectedCloseDate
        createdAt
        dealManagement_isDeleted
        dealManagement_isWon
        dealManagement_isLost
        dealManagement_status
      }
      id
      price
    }
  }
`;
