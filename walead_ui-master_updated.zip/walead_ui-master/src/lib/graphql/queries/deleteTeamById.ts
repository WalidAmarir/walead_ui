import { gql } from "@apollo/client";
export const DELETE_TEAM_BY_ID = gql`
  query Query($deleteTeamByIdId: String) {
    deleteTeamById(id: $deleteTeamByIdId)
  }
`;
