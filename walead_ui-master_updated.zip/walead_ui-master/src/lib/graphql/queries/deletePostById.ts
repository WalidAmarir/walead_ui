import { gql } from "@apollo/client";
export const DELETE_POST_BY_ID = gql`
  query Query($deletePostByIdId: String) {
    deletePostById(id: $deletePostByIdId)
  }
`;
