import { gql } from "@apollo/client";
export const GET_SUBSCRIBTION = gql`
  query GetSubscription {
    getSubscription {
      id
      userId
      email
      stripeCustomerId
      subscriptionId
      status
      currentPeriodStart
      currentPeriodEnd
      trialStart
      trialEnd
      createdAt
      quantity
      amount
      isSubscription
    }
  }
`;
