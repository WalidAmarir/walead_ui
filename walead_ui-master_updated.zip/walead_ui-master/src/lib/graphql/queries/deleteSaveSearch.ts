import { gql } from "@apollo/client";
export const DELETE_SAVE_SEARCH = gql`
  query Query($deleteSaveSearchId: String) {
    deleteSaveSearch(id: $deleteSaveSearchId)
  }
`;
