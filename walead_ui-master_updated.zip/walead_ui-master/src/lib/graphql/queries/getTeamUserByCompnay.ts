import { gql } from "@apollo/client";
export const GET_TEAMUSER_BY_COMPANY = gql`
  query Query {
    getTeamUserByCompnay {
      totalCount
      companyID
      companyName
      edges {
        node {
          id
          email
          fullName
          role {
            id
            role
            roleConstraint
          }
        }
        cursor
      }
    }
  }
`;
