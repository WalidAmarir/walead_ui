import { gql } from "@apollo/client";
export const CONNECTED_ON_LINKEDIN_ACCOUNT = gql`
  mutation ConnectedOnLinkedinAccount($isConnectedOnLinkedin: Boolean) {
    connectedOnLinkedinAccount(isConnectedOnLinkedin: $isConnectedOnLinkedin)
  }
`;
