import { FormValues } from "@/hooks/useFormikForm";
import { FormikErrors } from "formik";

export type LocalStorageKey = "AUTH_TOKEN" | "user";

export interface IAuth {
  isLoggedIn: boolean;
  authenticateUser: (token: string) => void;
  logout: () => void;
  isDashboard: boolean;
  handleDealdata: any;
  data: any;
  loading: boolean;
  refetch: () => void;
}

export interface ActionProps {
  isPreview: boolean;
  isComment: boolean;
  [key: string]: boolean;
}

interface EditorProp {
  [key: string]: string;
}
export interface SchedulePostProp {
  [x: string]: any;
  content: string;
  teamMembers: string[];
  img: string[];
  isRepost?: boolean;
  isPublish: boolean;
  schedulePostDate: string;
  postPublishtDate: string;
  time: string;
  schedulePostTime: string;
  status: string;
  displayDate: string;
}

export interface TeamsProp {
  id: any;
  teamMembers: string[];
  teamName: string;
}

export interface TeamMember {
  title: string;
  id?: string;
  icon: string | null;
}
export interface TeamMember2 {
  label: string;
  value: string;
  name?: string;
}

interface InitialFilterScheduler {
  search: string;
  members: string;
  data: string;
}

export interface IScheduler {
  handleChange: (event: React.ChangeEvent<any>) => void;
  resetForm: (nextValues?: FormValues) => void;
  values: FormValues;
  errors: FormikErrors<InitialFilterScheduler>;
  calenderType: string;
  editorErr: EditorProp;
  editorState: EditorProp;
  onSecheduleOpen: boolean;
  postactionType: ActionProps;
  filteredData: SchedulePostProp[];
  weeklyDates: any[];
  teamMembers: TeamMember2[];
  handleScheduleType: (value: string) => void;
  setEditorState: (value: EditorProp) => void;
  getEditorErr: (name: string, value: string) => boolean;
  handleSetWeeklyDates: (dates: any) => void;
  handleSetOnScheduleOpen: (value: boolean) => void;
  handleScheduleActions: (value: keyof ActionProps, value2: boolean) => void;
  setEditorError: (value: EditorProp) => void;
  refetch: () => void;
  setIsMember: (arg: boolean) => void;
  setIsLoader: (arg: boolean) => void;
  teamsDataRefetch: () => void;
  searchPosts: (
    value: { [key: string]: string | string[] },
    arg?: boolean,
  ) => void;
  isMember: boolean;
  isLoader: boolean;
}
export interface IArray {
  [key: string]: any;
}
export interface Theme {
  colors: {
    primary: string;
    action: string;
  };
}

export interface ChildProps {
  children: React.ReactNode;
}

export interface RegistrationValues {
  fullName: string;
  password: string;
  code: string | number;
  number: string | number;
  helpfulTips: boolean;
  termandcondition: boolean;
  jobrole: string;
  experience: string;
  need: string;
  companyname: string;
  companySize: string;
  companyindustry: string;
}

export interface RegistrationFormFields {
  fullName: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  password: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  code: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  phonenumber: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  helpfulTips: {
    name: string;
    label: string;
  };
  termandcondition: {
    name: string;
    label: string;
  };
  jobRole: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  experience: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  need: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  companyname: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  companySize: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
  companyindustry: {
    name: string;
    label: string;
    requiredErrorMsg: string;
  };
}

export interface NewDealFormInitialProps {
  name: string;
  organization: string;
  value: string;
  valueType: string;
  phone: string;
  phoneType: string;
  email: string;
  expectedCloseDate: string;
  tags: string[];
  stage: string[];
  linkedin: string;
  teamMembers: string[];
  leadImage: any;
  calendly: string;
}
export interface WorkOption {
  label: string;
  value: string;
}

interface Deal {
  __typename: string;
  id: string;
  userId: string;
  name: string;
  organization: string;
  value: string;
  valueType: string;
  stage: {
    __typename: string;
    id: string;
    boardName: string;
    boardConstraint: string;
  };
  email: string;
  phone: string;
  phoneType: string;
  linkedin: string;
  calendly: string;
  webURL: string | null;
  tags: string[];
  teamMembers: {
    __typename: string;
    id: string;
    fullName: string;
  }[];
  leadImage: string;
  expectedCloseDate: string;
  createdAt: string;
  dealManagement_isDeleted: boolean | null;
  dealManagement_isWon: boolean | null;
  dealManagement_isLost: boolean | null;
}

interface DealEdge {
  __typename: string;
  node: Deal;
  cursor: string;
}

export interface DealArray {
  edges: DealEdge[];
  pageInfo: {
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    startCursor: string;
    endCursor: string;
  };
}

export interface File {
  name: string;
  size: number;
  type: string;
  preview: string;
}

export interface ButtonConfigProp {
  backgroundColor: string;
  color: string;
  outline: boolean;
  buttonText: string;
  onclick: () => void;
}
export interface ImageProp {
  img: Array<{ file: File; previewUrl: string }>;
}

export interface TeamMember {
  title: string;
  id?: string;
  icon: string | null;
}

export interface WeekProp {
  from: Date;
  to: Date;
}

export interface ICalender {
  weeks: WeekProp;
  months: Date[];
  monthName: string;
  dates: Date;
  getCurrentWeek: (arg: string | number | Date) => void;
  handlePrevWeekClick: () => void;
  handleNextWeekClick: () => void;
  handleCurrentWeek: () => void;
  handleNextMonthClick: () => void;
  handlePrevMonthClick: () => void;
  handleCurrentMonth: () => void;
  handlePrevDate: () => void;
  handleNextDate: () => void;
  handleCurrentDay: () => void;
  handleSelectedMonth: (arg: Date) => void;
  handleSelectedDate: (arg: Date) => void;
}

export interface CalenderTimeinitialValuesProp {
  hours: string;
  minutes: string;
}
export interface CalenderValueProps {
  date: string;
  time: any;
}

export interface Role {
  id: string;
  role: string;
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: Role;
}

export interface InviteUser {
  email: string;
  token: string;
  company: Company;
  role: Role;
}

interface Company {
  name: string;
  isActive: boolean;
  id: string;
}

export interface Subscription {
  id: string;
  userId: string;
  email: string;
  stripeCustomerId: string;
  subscriptionId: string;
  status: string;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  trialStart: string;
  trialEnd: string;
  createdAt: string;
  subscribed: boolean;
  quantity: string;
  amount: string;
}

export interface UserEdge {
  id: string;
  node: User;
}

interface Company {
  id: string;
  name: string;
  isActive: boolean;
}

export interface UserDetail {
  id: string;
  email: string;
  mobileNumber: string;
  countryCode: string;
  jobRole: string;
  experience: string;
  firstWishlist: string;
  company: Company;
  role: Role;
  weLeadUserInCompany: string;
  fullName: string;
  companySize: string;
  profilePicture: string;
  industry: string;
  login_isActive: boolean;
  linkedinUserName: string;
  isConnectedOnLinkedin: boolean;
  timeZone: string;
  dealCount: string;
}

export interface ProfileData {
  profiledata: {
    getUserDetailsById: UserDetail;
  };
  profileLoading: boolean;
  isEmptyDeal: boolean;
}

export interface HeaderBudgeProps {
  name: string;
  background: string;
  value?: string;
  profilePicture?: string;
}

export interface AllTeamMember extends HeaderBudgeProps {
  id: string;
  profilePicture: string | undefined;
  fullName: string;
}

export interface LeadFinder {
  id: string;
  email: string;
  profileImage: string | null;
  firstName: string;
  lastName: string;
  name: string | null;
  linkedIn: string;
  title: string;
  headline: string | null;
  city: string;
  state: string;
  country: string | null;
  orgNumber: string | null;
  orgFoundedYear: string | null;
  organizationLogo: string | null;
  organizationDomain: string | null;
  phoneNumber: string;
  organizationID: string | null;
  organizationName: string;
  organizationWebsite: string;
  inputFilters: any | null;
}
