export interface LoginInput {
  email: string;
  password: string;
  remember: boolean;
}
export interface LoginKeys {
  email: string;
  password: string;
}

export interface BoardObj {
  name: string;
  title: string;
  price: number;
  profiles: string[];
  item: any;
  id: string;
}

export interface PipelineData {
  [key: string]: {
    name: string;
    title: string;
    price: string;
    profiles: any[];
    item: any[];
    id: string;
  };
}
