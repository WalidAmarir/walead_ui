import ModalHeader from "@/components/schedulePost/ModalHeader";
import SchedulePostCard from "@/components/ui/CardContainer/SchedulePostCard";
import Modal from "@/components/ui/modal/Modal";
import DeleteDeal from "@/components/ui/modal/schedulePost/DeleteDeal";
import PostAction from "@/components/ui/modal/schedulePost/PostActions";
import { useQueryContext } from "@/context/query/queryContext";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { useBrowserCheck } from "@/hooks/useBrowserCheck";
import ProfileCard from "@/layouts/userprofile/ProfileCard";
import { CREATE_POST_DEAL } from "@/lib/graphql/mutation/createPostDeal";
import { borderStyle } from "@/styles/base";
import { errorToast, successToast } from "@/styles/toaster";
import { typographyParagraph, typographySubtitle1 } from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightGreyColor,
  silverGrayColor,
  whiteColor,
} from "@/styles/variables";
import { SchedulePostProp } from "@/types/global";
import {
  getDate,
  getDateWithMonth,
  isCurrentDate,
  isFutureDate,
  weekDayName,
} from "@/utils/helperUtils";
import { useMutation } from "@apollo/client";
import { css } from "@emotion/core";
import styled from "@emotion/styled";
import React, { useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import AddSchedulepost from "../AddSchedulepost";

const WeeklyCalender = ({ handleUpdate }: any) => {
  const { weeklyDates, onSecheduleOpen, filteredData, refetch } =
    useScheduledContext();
  const { dealData, setDealData } = useQueryContext();
  const [addDealToPost] = useMutation(CREATE_POST_DEAL, {
    onCompleted: refetch,
  });
  const isBrowser = useBrowserCheck();
  const [addDealOpen, setAddDealOpen] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [isDeleteDeal, setIsDeleteDeal] = useState<boolean>(false);
  const [isAction, setIsAction] = useState<boolean>(false);
  const [deatils, setDetails] = useState({});

  const handleOnDeleteOpen = (
    event: { stopPropagation: () => void },
    dealdatabyid: SchedulePostProp,
  ) => {
    event.stopPropagation();
    setOpen(null);
    setDetails(dealdatabyid);
    setIsDeleteDeal(true);
  };

  const handleClose = () => {
    setIsAction(false);
  };
  const handleOpen = (data: SchedulePostProp) => {
    setIsAction(true);
    setDetails(data);
    setOpen(null);
  };
  const onAddDealClose = () => {
    setAddDealOpen(false);
    setDealData(null);
  };

  const handleAddDealToPost = async (dealId: string, postId: string) => {
    try {
      const { data } = await addDealToPost({
        variables: {
          input: {
            dealMember: dealId,
            postId: postId,
          },
        },
      });
      if (data?.createPostDeal) {
        successToast(data?.createPostDeal);
        setAddDealOpen(true);
      }
    } catch (err: any) {
      errorToast(err?.message);
    }
  };

  const handleDragEnd = (result: {
    type: string;
    source: any;
    draggableId: any;
    destination: any;
  }) => {
    if (!result.destination) {
      return;
    }
    const { destination, source, draggableId } = result;
    if (result?.type === "DEAL") {
      handleAddDealToPost(draggableId, destination?.droppableId);
      return;
    }
    if (destination?.droppableId !== source?.droppableId) {
      handleUpdate(destination?.droppableId, draggableId, filteredData);
    }
  };
  const handleDragStart = (item: { source: any }) => {
    if (!item.source) return;
  };
  return (
    isBrowser && (
      <Wrapper>
        <DragDropContext
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <WeeklyCalenderWrapper>
            {weeklyDates?.map((weekDayitem, index) => {
              const date = getDateWithMonth(weeklyDates?.[index]);
              const items = filteredData.filter(
                (i: { displayDate: string | number | Date }) =>
                  getDate(i.displayDate, weeklyDates?.[index]),
              );
              const dayName = weeklyDates?.[index]?.toLocaleDateString(
                "en-US",
                {
                  weekday: "long",
                },
              );
              return (
                <Droppable
                  droppableId={weeklyDates?.[index]?.toString()}
                  key={index}
                  isDropDisabled={
                    !isFutureDate(weekDayitem) || isCurrentDate(weekDayitem)
                  }
                  type="POST"
                  isCombineEnabled
                >
                  {(provided) => (
                    <WeekluCalenderItems
                      ispast={isFutureDate(weekDayitem)}
                      key={index}
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      onMouseEnter={() => {
                        if (!onSecheduleOpen && isFutureDate(weekDayitem)) {
                          setOpen(weekDayitem);
                        }
                      }}
                      onMouseLeave={() => {
                        if (!onSecheduleOpen && isFutureDate(weekDayitem)) {
                          setOpen(null);
                        }
                      }}
                      index={index}
                    >
                      <DayName>{dayName ? dayName : "Loading..."}</DayName>
                      <ContentWrapper>
                        <DateWithMonth
                          isCurrent={isCurrentDate(weeklyDates?.[index])}
                        >
                          {date ? date : "Loading..."}
                        </DateWithMonth>
                        {open === weekDayitem && (
                          <AddSchedulepost data={weekDayitem} />
                        )}
                        {items?.map((item: SchedulePostProp, postIndex) => {
                          return (
                            <Draggable
                              key={item?.id}
                              draggableId={item?.id}
                              index={postIndex}
                              isDragDisabled={item?.status === "Posted"}
                            >
                              {(providedList) => {
                                return (
                                  <div
                                    ref={providedList.innerRef}
                                    {...providedList.draggableProps}
                                    {...providedList.dragHandleProps}
                                  >
                                    <Droppable
                                      droppableId={item.id}
                                      type="DEAL"
                                      key={1}
                                    >
                                      {(providedDeal) => (
                                        <div
                                          ref={providedDeal.innerRef}
                                          {...providedDeal.droppableProps}
                                        >
                                          <div style={{ zIndex: "1000" }}>
                                            <SchedulePostCard
                                              onClick={() => {
                                                handleOpen(item);
                                              }}
                                              onDeleteDeal={handleOnDeleteOpen}
                                              key={postIndex + 2}
                                              data={item}
                                            />
                                          </div>
                                        </div>
                                      )}
                                    </Droppable>
                                  </div>
                                );
                              }}
                            </Draggable>
                          );
                        })}
                      </ContentWrapper>
                    </WeekluCalenderItems>
                  )}
                </Droppable>
              );
            })}
          </WeeklyCalenderWrapper>
          <Droppable droppableId={"DealId"} type="DEAL">
            {(providedDeal) => (
              <div ref={providedDeal.innerRef} {...providedDeal.droppableProps}>
                {dealData && (
                  <Draggable
                    key={dealData?.id + 1}
                    draggableId={dealData?.id}
                    index={1}
                  >
                    {(providedDealList) => {
                      return (
                        <DealWrapper
                          style={{ zIndex: "2" }}
                          ref={providedDealList.innerRef}
                          {...providedDealList.draggableProps}
                          {...providedDealList.dragHandleProps}
                        >
                          <ProfileCard data={dealData} />
                        </DealWrapper>
                      );
                    }}
                  </Draggable>
                )}
              </div>
            )}
          </Droppable>
        </DragDropContext>
        <PostAction open={isAction} data={deatils} onClose={handleClose} />
        <Modal
          open={addDealOpen}
          width="700"
          closeModal={onAddDealClose}
          maxWidth="lg"
          styles={borderStyle}
        >
          <ModalHeader showClose={true} onclose={onAddDealClose} />
          <ModalContainer>
            <ContentWrapper>
              <DealCardWrapper>
                <ProfileCard data={dealData} />
              </DealCardWrapper>
              <AlertTitle>You added {dealData?.name} to this post</AlertTitle>
            </ContentWrapper>
          </ModalContainer>
        </Modal>
        <DeleteDeal
          data={deatils}
          isOpen={isDeleteDeal}
          onclose={setIsDeleteDeal}
        />
      </Wrapper>
    )
  );
};

export default WeeklyCalender;

const WeeklyCalenderWrapper = styled.div`
  display: flex;
  width: 100%;
  border-radius: 10px;
  display: flex;
  justify-content: center;
  flex-wrap: nowrap !important;
  align-items: strech;
  min-height: 100vh;
`;
const WeekluCalenderItems = styled.div<{
  index: number;
  ispast: boolean;
}>(
  ({ index, ispast }) => css`
    background: ${ispast ? silverGrayColor : lightGreyColor};
    width: 100%;
    border: 1px solid ${greyColor};
    ${getBorder(index)}
  `,
);
const ContentWrapper = styled.div`
  padding: ${guttersPx.smallHalf};
`;
const DayName = styled.h1`
  ${typographySubtitle1};
  color: ${darkCharcoalColor};
  min-height: 50px;
  background: ${whiteColor};
  padding: ${guttersPx.smallHalf};
  display: flex;
  align-items: center;
  width: 100%;
  border-bottom: 1px solid ${greyColor};
`;
export const DateWithMonth = styled.h1<{
  isCurrent: boolean;
}>(
  ({ isCurrent = false }) => css`
    ${typographyParagraph};
    color: ${greyColor};
    background-color: transparent;
    ${isCurrent ? getCurrentDateStye() : ""}
  `,
);

const getCurrentDateStye = () => css`
  padding: 5px 10px;
  width: fit-content;
  border-radius: 20px;
  background-color: ${darkblueColor};
  color: ${whiteColor};
`;

const getBorder = (index: number) => {
  const isFirstDayOfWeek = index === 0;
  const isLastDayOfWeek = index === weekDayName.length - 1;
  return `
          ${
            isFirstDayOfWeek
              ? "border-top-left-radius: 10px; border-bottom-left-radius: 10px; overflow: hidden;"
              : ""
          }
          ${
            isLastDayOfWeek
              ? "border-top-right-radius: 10px; border-bottom-right-radius: 10px; overflow: hidden;"
              : ""
          }
          `;
};

const Wrapper = styled.div`
  position: relative;
`;

const DealWrapper = styled.div`
  position: absolute;
  right: -30px;
  bottom: -30px;
  width: 100%;
  max-width: 237px;
`;

const ModalContainer = styled.div`
  min-width: 452px;
  padding: 28px;
  padding-top: 0;
`;

const DealCardWrapper = styled.div`
  width: 100%;
  max-width: 237px;
  display: block;
  margin: 10px auto;
  margin-bottom: 28px;
`;

const AlertTitle = styled.h1`
  color: ${darkCharcoalColor};
  text-align: center;
  ${typographyParagraph};
  margin-top: 20px;
`;
