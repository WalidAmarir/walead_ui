import SchedulePostCard from "@/components/ui/CardContainer/SchedulePostCard";
import PostActions from "@/components/ui/modal/schedulePost/PostActions";
import { useCalenderContext } from "@/context/schedule/calenderContext";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { useBrowserCheck } from "@/hooks/useBrowserCheck";
import {
  greyColor,
  guttersPx,
  lightGreyColor,
  silverGrayColor,
} from "@/styles/variables";
import { SchedulePostProp } from "@/types/global";
import {
  getDate,
  getDateWithMonth,
  isCurrentDate,
  isFutureDate,
} from "@/utils/helperUtils";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import React, { useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import AddSchedulepost from "../AddSchedulepost";
import { DateWithMonth } from "./WeeklyCalender";

const MonthlyCalender = ({ handleUpdate }: any) => {
  const { months } = useCalenderContext();
  const { filteredData } = useScheduledContext();
  const { onSecheduleOpen } = useScheduledContext();
  const isBrowser = useBrowserCheck();
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [deatils, setDetails] = useState({});
  const [open, setOpen] = useState<string | null>(null);
  const handleMouseEnter = (currentitem: Date) => {
    setOpen(currentitem?.toLocaleDateString());
  };
  const handleClose = () => {
    setIsOpen(false);
  };
  const handleOpen = (data: SchedulePostProp) => {
    setIsOpen(true);
    setDetails(data);
  };
  const handleDragEnd = (result: {
    source: any;
    draggableId: any;
    destination: any;
  }) => {
    if (!result.destination) {
      return;
    }
    const { destination, source, draggableId } = result;
    if (destination?.droppableId !== source?.droppableId) {
      handleUpdate(destination?.droppableId, draggableId, filteredData);
    }
  };
  const handleDragStart = (item: { source: any }) => {
    if (!item.source) return;
  };

  return (
    isBrowser && (
      <>
        <DragDropContext
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <Container>
            {months?.map((item, index) => {
              const date = getDateWithMonth(item);
              const items = filteredData.filter(
                (i: { displayDate: string | number | Date }) =>
                  getDate(i.displayDate, item),
              );
              return (
                <Droppable
                  droppableId={months?.[index].toString()}
                  key={index}
                  isDropDisabled={!isFutureDate(item) || isCurrentDate(item)}
                >
                  {(provided) => (
                    <Item
                      key={index}
                      {...provided.droppableProps}
                      ispast={isFutureDate(item)}
                      ref={provided.innerRef}
                      onMouseEnter={() => {
                        if (!onSecheduleOpen && isFutureDate(item)) {
                          handleMouseEnter(item);
                        }
                      }}
                      onMouseLeave={() => {
                        if (!onSecheduleOpen && isFutureDate(item)) {
                          setOpen(null);
                        }
                      }}
                    >
                      <DateWithMonth isCurrent={isCurrentDate(item)}>
                        {date}
                      </DateWithMonth>
                      <>
                        {open === item?.toLocaleDateString() && (
                          <AddSchedulepost data={item?.toString()} />
                        )}
                        {items?.map((Dateitem, postIndex) => {
                          return (
                            <Draggable
                              key={Dateitem?.id}
                              draggableId={Dateitem?.id}
                              index={postIndex}
                              isDragDisabled={Dateitem?.status === "Posted"}
                            >
                              {(providedList) => {
                                return (
                                  <div
                                    ref={providedList.innerRef}
                                    {...providedList.draggableProps}
                                    {...providedList.dragHandleProps}
                                  >
                                    <SchedulePostCard
                                      onClick={() => {
                                        handleOpen(Dateitem);
                                      }}
                                      key={postIndex}
                                      data={Dateitem}
                                    />
                                  </div>
                                );
                              }}
                            </Draggable>
                          );
                        })}
                      </>
                    </Item>
                  )}
                </Droppable>
              );
            })}
          </Container>
        </DragDropContext>
        <PostActions open={isOpen} data={deatils} onClose={handleClose} />
      </>
    )
  );
};

export default MonthlyCalender;

const Container = styled.div`
  display: grid;
  grid-template-columns: auto auto auto auto auto auto;
  width: 100%;
  margin: 0;
`;

const Item = styled.div<{
  ispast: boolean;
}>(
  ({ ispast }) => css`
    padding: ${guttersPx.smallHalf};
    box-sizing: border-box;
    min-height: 184px;
    min-width: 185px;
    background: ${ispast ? silverGrayColor : lightGreyColor};
    border: 1px solid ${greyColor};
  `,
);
