import SchedulePostCard from "@/components/ui/CardContainer/SchedulePostCard";
import PostActions from "@/components/ui/modal/schedulePost/PostActions";
import { useCalenderContext } from "@/context/schedule/calenderContext";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { greyColor, guttersPx, lightGreyColor } from "@/styles/variables";
import { SchedulePostProp } from "@/types/global";
import {
  findbeforeTime,
  findTime,
  getDateWithMonth,
  isFutureDate,
  timeZone,
} from "@/utils/helperUtils";
import styled from "@emotion/styled";
import dayjs from "dayjs";
import React, { useState } from "react";
import AddSchedulepost from "../AddSchedulepost";
import { DATE } from "../CalenderHeader";

const DailyCalender = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [deatils, setDetails] = useState({});
  const {
    handlePrevDate,
    handleNextDate,
    handleCurrentDay,
    handleSelectedDate,
    dates,
  } = useCalenderContext();
  const [open, setOpen] = useState<string | null>(null);
  const handleMouseEnter = (currentitem: string) => {
    setOpen(currentitem);
  };
  const { filteredData, onSecheduleOpen } = useScheduledContext();
  const dateTitle = getDateWithMonth(dates) || "";

  function isSameDate(
    dateString2: string | number | Date | dayjs.Dayjs | null | undefined,
  ) {
    if (!dateString2) {
      return;
    }
    const date1 = dayjs(dates);
    const date2 = dayjs(dateString2);
    return date1.isSame(date2, "day");
  }
  const handleClose = () => {
    setIsOpen(false);
  };
  const handleOpen = (data: SchedulePostProp) => {
    setIsOpen(true);
    setDetails(data);
  };
  const onDateSelect = (value: any) => {
    handleSelectedDate(value);
  };
  return (
    <>
      <DailyCalenderWrapper>
        <DateWrapper>
          <DATE
            handleprev={handlePrevDate}
            handleNext={handleNextDate}
            title={dateTitle}
            isTime={false}
            handleCurrent={handleCurrentDay}
            onsubmit={onDateSelect}
          />
        </DateWrapper>
        <CalenderWrapper>
          {timeZone.map((time, index) => {
            const items = filteredData.filter(
              (i) =>
                isSameDate(i?.displayDate) && findTime(i.displayDate) === time,
            );
            return (
              <TimeWrapper
                key={index}
                onMouseEnter={() => {
                  if (
                    !onSecheduleOpen &&
                    isFutureDate(dates) &&
                    findbeforeTime(time, dates)
                  ) {
                    handleMouseEnter(time);
                  }
                }}
                onMouseLeave={() => {
                  if (!onSecheduleOpen && isFutureDate(dates)) {
                    setOpen(null);
                  }
                }}
              >
                <HeadingWrapper>
                  <Time>{time}</Time>
                  <Hr></Hr>
                </HeadingWrapper>
                {open === time && (
                  <AddSchedulepostWrapper>
                    <AddSchedulepost data={dates?.toString()} />
                  </AddSchedulepostWrapper>
                )}
                <CardWrapper>
                  {items?.map((Dateitem, postIndex) => (
                    <SchedulePostCard
                      onClick={() => {
                        handleOpen(Dateitem);
                      }}
                      key={postIndex}
                      data={Dateitem}
                    />
                  ))}
                </CardWrapper>
              </TimeWrapper>
            );
          })}
        </CalenderWrapper>
      </DailyCalenderWrapper>
      <PostActions open={isOpen} data={deatils} onClose={handleClose} />
    </>
  );
};

export default DailyCalender;

const DailyCalenderWrapper = styled.div`
  background: ${lightGreyColor};
  border-radius: ${guttersPx.small};
  border: 1px solid ${greyColor};
  padding: ${guttersPx.small};
`;
const DateWrapper = styled.div`
  display: flex;
  justify-content: center;
  padding: ${guttersPx.small};
`;
const CalenderWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 40px;
  padding: ${guttersPx.small} 0;
`;
const CardWrapper = styled.div`
  margin-left: 100px;
  & > div {
    max-width: 348px;
  }
  max-height: 200px;
  overflow-y: auto;
  overflow-x: auto;
  ::-webkit-scrollbar {
    width: ${guttersPx.smallHalf};
    border-radius: 20px;
  }
  ::-webkit-scrollbar-track {
    background: transparent;
  }

  ::-webkit-scrollbar-thumb {
    background: #d9d9d9;
  }
`;

const TimeWrapper = styled.div``;
const HeadingWrapper = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const Time = styled.div``;
const Hr = styled.hr`
  border: 1px dashed ${greyColor};
  width: 100%;
`;

const AddSchedulepostWrapper = styled.div`
  max-width: 200px;
  margin-left: 50px;
`;
