import SmallButton from "@/components/ui/button/SmallButton";
import InputBox from "@/components/ui/input/InputBox";
import DatePickerModal from "@/components/ui/modal/DatePickerModal";
import SelectBox from "@/components/ui/selectBox/SelectBox";
import CustomTooltip from "@/components/ui/tooltip/CustomTooltip";
import { useCalenderContext } from "@/context/schedule/calenderContext";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import {
  typographyH4Regular,
  typographySmall,
  typographySubtitle2Normal,
} from "@/styles/typography";
import {
  darkblueColor,
  darkCharcoalColor,
  fontFamily,
  fontSizeBody2,
  fontWeightNormal,
  GreenTeal,
  guttersPx,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import { WeekProp } from "@/types/global";
import { schedulePostOption } from "@/utils/constant";
import {
  DateIcon,
  searchIcon,
  TodayIcon,
} from "@/utils/formUtils/InputSvg/InputSvg";
import { formatDateRange, getWeekBounds } from "@/utils/helperUtils";
import { css } from "@emotion/core";
import styled from "@emotion/styled";
import Image from "next/image";
import React, { useEffect, useState } from "react";

const CalenderHeader = () => {
  const {
    teamMembers,
    calenderType,
    isMember,
    setIsMember,
    searchPosts,
    handleScheduleType,
    handleChange,
    resetForm,
    values,
    errors,
    handleSetWeeklyDates,
  } = useScheduledContext();
  const {
    weeks,
    monthName,
    handlePrevWeekClick,
    handleNextMonthClick,
    handlePrevMonthClick,
    handleNextWeekClick,
    handleCurrentWeek,
    handleCurrentMonth,
    getCurrentWeek,
    handleSelectedMonth,
  } = useCalenderContext();

  function getDatesBetween(
    startDate: string | number | Date,
    endDate: number | Date,
  ) {
    const dates = [];
    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return dates;
  }

  function handleWeeklyDates(weeksData: WeekProp) {
    const weekBounds = getWeekBounds(weeksData);
    const weeklyDates = getDatesBetween(weekBounds.from, weekBounds.to);
    handleSetWeeklyDates(weeklyDates);
    return weeklyDates;
  }

  useEffect(() => {
    handleWeeklyDates(weeks);
  }, [weeks.from, weeks.to]);

  const DateTitle = formatDateRange(weeks);

  const handleFilter = (e: any) => {
    handleChange(e);
    const { value, name } = e.target;
    const defaults = ["All members"];
    const filterValue = defaults.includes(value) ? "" : value;
    const isMemberSearch = name === "members" && filterValue !== "";
    setIsMember(false);
    if (isMemberSearch) {
      searchPosts({ search: filterValue }, isMemberSearch);
    }
  };

  const onWeekSelect = (value: any) => {
    getCurrentWeek(value);
  };
  const onMonthSelect = (value: any) => {
    handleSelectedMonth(value);
  };

  useEffect(() => {
    if (isMember) {
      resetForm();
    }
  }, [isMember, resetForm]);

  return (
    <HeaderWrapper>
      <LeftContentWrapper>
        <InputWrapper>
          <InputBox
            type="text"
            placeholder={"Search"}
            name="search"
            value={values.search}
            autocomplete="off"
            error={errors.search || ""}
            onChange={handleFilter}
            Icon={searchIcon}
          />
        </InputWrapper>
        <SelectBox
          name="members"
          options={teamMembers}
          value={values?.members}
          onChange={handleFilter}
          sx={selectBoxstyle}
        />
        <SelectBox
          name="data"
          options={schedulePostOption}
          value={values?.data}
          onChange={handleFilter}
          sx={selectBoxstyle}
        />
      </LeftContentWrapper>
      {calenderType === "weekly" && (
        <DATE
          handleprev={handlePrevWeekClick}
          handleNext={handleNextWeekClick}
          title={DateTitle}
          isTime={false}
          handleCurrent={handleCurrentWeek}
          onsubmit={onWeekSelect}
        />
      )}
      {calenderType === "monthly" && (
        <DATE
          handleprev={handlePrevMonthClick}
          handleNext={handleNextMonthClick}
          title={monthName}
          isTime={false}
          onsubmit={onMonthSelect}
          handleCurrent={handleCurrentMonth}
        />
      )}
      <RightContentWrapper>
        {btnType.map((btn) => (
          <StyledBtn
            bgcolor={calenderType === btn.value ? darkblueColor : whiteColor}
            color={calenderType === btn.value ? whiteColor : darkCharcoalColor}
            key={btn.id}
            onClick={() => {
              handleScheduleType(btn.value);
            }}
          >
            {btn.name}
          </StyledBtn>
        ))}
      </RightContentWrapper>
    </HeaderWrapper>
  );
};

export default CalenderHeader;

const HeaderWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  padding: ${guttersPx.extraLarge} 0;
`;
const StyledBtn = styled(SmallButton)<{ bgcolor?: string; color: string }>(
  ({ bgcolor, color }) => css`
    background: ${bgcolor};
    color: ${color};
    border-radius: 5px;
    width: auto;
    ${typographySmall};
    border: 1px solid ${darkblueColor};
  `,
);

const LeftContentWrapper = styled.div`
  display: flex;
  gap: ${guttersPx.smallHalf};
`;
const CenterContent = styled.div`
  display: flex;
  align-items: center;
  gap: ${guttersPx.small};
  svg {
    cursor: pointer;
  }
`;
const InputWrapper = styled.div`
  width: 100%;
  input {
    ${typographySubtitle2Normal};
  }
  span {
    display: block;
    z-index: 1;
  }
  span:nth-of-type(2) {
    display: none;
  }
`;
const RightContentWrapper = styled.div`
  display: flex;
  gap: ${guttersPx.small};
`;
export const selectBoxstyle = {
  mb: 1,
  color: darkCharcoalColor,
  fontFamily: fontFamily,
  fontSize: fontSizeBody2,
  fontWeight: fontWeightNormal,
};
const btnType = [
  {
    id: 1,
    name: "Daily",
    value: "daily",
  },
  {
    id: 2,
    name: "Weekly",
    value: "weekly",
  },
  {
    id: 3,
    name: "Monthly",
    value: "monthly",
  },
];

export const DATE = ({
  handleprev,
  handleNext,
  handleCurrent,
  title,
  isTime = true,
  onsubmit,
}: {
  handleprev: () => void;
  handleNext: () => void;
  handleCurrent: () => void;
  title: string;
  isTime?: boolean;
  onsubmit: (value: string) => void;
}) => {
  const [open, setOpen] = useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <CenterContent>
        <CustomTooltip title="Go to today" placement="bottom">
          <TodayIcon color={lightRedColor} onclick={handleCurrent} />
        </CustomTooltip>
        <CustomTooltip title="Change data" placement="bottom">
          <DateIcon color={GreenTeal} onclick={handleClickOpen} />
        </CustomTooltip>
        <StyledICon
          onClick={handleprev}
          src="/assets/icons/nextIcon.png"
          width={10}
          height={16}
          alt="next"
        />
        <StyledDate>{title}</StyledDate>
        <StyledICon
          onClick={handleNext}
          src="/assets/icons/prevIcon.png"
          width={10}
          height={16}
          alt="prev"
        />
      </CenterContent>
      <DatePickerModal
        isTime={isTime}
        open={open}
        closeModal={handleClose}
        onSchedule={onsubmit}
        disablePast={false}
      />
    </>
  );
};

const StyledICon = styled(Image)`
  object-fit: contain;
  cursor: pointer;
`;
const StyledDate = styled.div`
  ${typographyH4Regular};
  color: ${darkCharcoalColor};
`;
