import SchedulePost from "@/components/ui/modal/schedulePost/SchedulePost";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { CREATE_SCHEDULE_POST } from "@/lib/graphql/mutation/schedulePost";
import { errorToast, successToast } from "@/styles/toaster";
import { darkblueColor, guttersPx } from "@/styles/variables";
import { AddIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { useMutation } from "@apollo/client";
import styled from "@emotion/styled";
import React, { useEffect, useState } from "react";

const AddSchedulepost = ({ data = "" }: { data?: string }) => {
  const { handleSetOnScheduleOpen, refetch, onSecheduleOpen, setIsLoader } =
    useScheduledContext();
  const [handleSchedulePost, { loading }] = useMutation(CREATE_SCHEDULE_POST, {
    fetchPolicy: "no-cache",
    onCompleted: refetch,
  });

  const [isCalender, setIsCalender] = useState(false);

  const handleCalenderClose = () => {
    setIsCalender(false);
  };
  const handleCalenderOpen = () => {
    setIsCalender(true);
  };
  const handleOpen = () => {
    handleSetOnScheduleOpen(true);
  };
  const handleClose = () => {
    handleSetOnScheduleOpen(false);
  };
  const onSchedulePost = async (value: any, resetForm: any) => {
    try {
      const { data: postData } = await handleSchedulePost({
        variables: { input: value },
      });
      if (postData?.createPost) {
        successToast("Post created successfully");
        handleCalenderClose();
        resetForm();
        handleClose();
      }
    } catch (error: any) {
      handleCalenderClose();
      errorToast(error?.message);
    } finally {
      setIsLoader(false);
    }
  };

  useEffect(() => {
    setIsLoader(loading);
  }, [loading]);

  return (
    <>
      <Wrapper onClick={handleOpen}>
        <AddIcon width="20" height="20" />
      </Wrapper>
      <SchedulePost
        data={data}
        open={onSecheduleOpen}
        onOpen={handleOpen}
        onClose={handleClose}
        edit={false}
        handleCalenderOpen={handleCalenderOpen}
        onSubmit={onSchedulePost}
        loading={false}
        calenderOpen={isCalender}
        onCalenderClose={handleCalenderClose}
      />
    </>
  );
};

export default AddSchedulepost;

const Wrapper = styled.div`
  padding: 2px;
  display: flex;
  justify-content: center;
  border: 1px solid ${darkblueColor};
  border-radius: 5px;
  margin-top: ${guttersPx.smallHalf};
  width: 100%;
  cursor: pointer;
`;
