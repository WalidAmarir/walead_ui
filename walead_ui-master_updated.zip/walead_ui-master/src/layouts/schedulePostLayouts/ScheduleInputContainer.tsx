import React from "react";
import {
  greyColor,
  buttonCursor,
  borderRadiusLarger,
  silverGrayColor,
  guttersPx,
  lighOrange,
  redColor,
} from "@/styles/variables";
import styled from "@emotion/styled";
import { CommentIcon, ViewIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { useScheduledContext } from "@/context/schedule/scheduledContext";
import { ActionProps } from "@/types/global";
import DropZone from "@/components/ui/fileUpload/DropZone";
import CustomTooltip from "@/components/ui/tooltip/CustomTooltip";

const TextEditor = dynamic(() => import("@/components/ui/input/TextEditor"), {
  ssr: false,
});

import { css } from "@emotion/react";
import { getInnerText } from "@/utils/helperUtils";
import dynamic from "next/dynamic";

const TextAreaContainer = styled.div`
  width: 100%;
  height: fit-content;
  border-radius: ${borderRadiusLarger};
  border: 1px solid ${greyColor};
  background: ${silverGrayColor};
  margin: 1.5rem 0;
  padding: ${guttersPx.medium};
`;
const TextCount = styled.p<{
  error: boolean;
}>(
  ({ error = false }) => css`
    color: ${error ? redColor : lighOrange};
    display: block;
    text-align: end;
  `,
);

const HrRule = styled.div`
  height: 0.5px;
  background: ${greyColor};
  margin: ${guttersPx.mediumHalf} auto;
`;

const FlexIcon = styled.div`
  display: flex;
  align-items: center;
  gap: ${guttersPx.medium};
  svg {
    cursor: ${buttonCursor};
  }
`;
export interface Obj {
  [key: string]: string | string[];
}

const ScheduleInputContainer = ({
  postaction,
  placeholderTextArea,
  setValues,
  name,
  imgName = "img",
  values,
  errors,
  isEdit = false,
  readOnly = false,
}: {
  placeholderTextArea: string;
  postaction?: boolean;
  setValues?: any;
  name: string;
  values: Obj;
  imgName: string;
  errors: Obj;
  isEdit?: boolean;
  readOnly?: boolean;
}) => {
  const { handleScheduleActions } = useScheduledContext();
  const hanldeOpen = (Iconname: keyof ActionProps) => {
    handleScheduleActions(Iconname, true);
  };

  return (
    <>
      <TextAreaContainer>
        <TextEditor
          readOnly={readOnly}
          name={name}
          editorError={errors?.[name]}
          editorValue={values?.[name]}
          setValues={setValues}
          placeholder={placeholderTextArea}
          hideLink
        />
        {!isEdit && (
          <DropZone
            name={imgName}
            defaultValues={values?.img}
            isEdit={isEdit}
            setValues={setValues}
          />
        )}
        {postaction && (
          <>
            <HrRule />
            <TextCount error={!!errors?.[name]}>
              {getInnerText(values?.[name] as string)?.length}
            </TextCount>
            <FlexIcon>
              <CustomTooltip title="Preview" placement="bottom">
                <ViewIcon
                  onClick={() => {
                    hanldeOpen("isPreview");
                  }}
                />
              </CustomTooltip>
              {!isEdit && (
                <CustomTooltip title="Write a comment" placement="bottom">
                  <CommentIcon
                    onClick={() => {
                      hanldeOpen("isComment");
                    }}
                  />
                </CustomTooltip>
              )}
            </FlexIcon>
          </>
        )}
      </TextAreaContainer>
    </>
  );
};

export default ScheduleInputContainer;
