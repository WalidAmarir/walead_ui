import Image from "next/image";

export const WaleadLogo = () => {
  return (
    <Image
      src="/assets/images/Logo.png"
      height={37}
      width={156.018}
      alt="logo"
    />
  );
};
