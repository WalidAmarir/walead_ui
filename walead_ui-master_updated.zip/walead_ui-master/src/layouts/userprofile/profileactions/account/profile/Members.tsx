import React, { useState } from "react";
import styled from "@emotion/styled";
import Link from "next/link";
import {
  darkblueColor,
  darkCharcoalColor,
  guttersPx,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import ContentContainer from "../../ContentContainer";
import AddMember from "@/components/ui/modal/profileModals/AddMember";
import TeamMembersCard from "@/components/profile/TeamMembersCard";
import AlertPoPup from "@/components/ui/modal/schedulePost/AlertPoPup";
import { Role, User, UserEdge, WorkOption } from "@/types/global";
import { useLazyQuery, useQuery } from "@apollo/client";
import { DELETE_USER_BY_ID } from "@/lib/graphql/queries/deleteUserById";
import { errorToast, successToast } from "@/styles/toaster";
import { GET_Role } from "@/lib/graphql/queries/getRole";
import { sortArrayByOwner } from "@/utils/helperUtils";

export interface TeamMember {
  id: number;
  name: string;
  email: string;
  type: string;
  option?: WorkOption[];
}
interface MembersProps {
  Edges: UserEdge[];
  refetch: () => void;
}
const Members: React.FC<MembersProps> = ({ Edges, refetch }) => {
  const [deleteMember, setDeleteMember] = useState(false);
  const [selectedData, setSelectedData] = useState<User | null>(null);
  const [loadingDelete, setLoadingDelete] = useState(false);

  const [fetchAccelerators] = useLazyQuery(DELETE_USER_BY_ID, {
    fetchPolicy: "no-cache",
  });

  const { data } = useQuery(GET_Role, {
    fetchPolicy: "no-cache",
  });

  const cancelButtonConfig = {
    backgroundColor: whiteColor,
    color: darkCharcoalColor,
    outline: true,
    buttonText: "Cancel",
    onclick: () => setDeleteMember(false),
  };

  const deleteButtonConfig = {
    backgroundColor: lightRedColor,
    color: whiteColor,
    outline: false,
    buttonText: loadingDelete ? "Deleting..." : "Delete",
    onclick: async () => {
      try {
        setLoadingDelete(true);
        await fetchAccelerators({
          variables: {
            deleteUserByIdId: selectedData?.id,
          },
        });
        setLoadingDelete(false);
        successToast("Member removed successfully");
        refetch();
        setDeleteMember(false);
      } catch (error: any) {
        setLoadingDelete(false);
        errorToast(
          error?.message || "An error occurred while removing the member",
        );
      }
    },
  };

  const handleOpen = (databyID: User) => {
    setSelectedData(databyID);
    setDeleteMember(true);
  };

  const filterEdges = sortArrayByOwner(Edges);
  return (
    <MembersWrapper>
      <ContentContainer
        heading="Team members"
        leftContent={<AddTeamMember data={data?.getRole} />}
      >
        <Wrapper>
          {filterEdges?.map((item: UserEdge) => {
            return (
              <TeamMembersCard
                key={item?.id}
                item={item?.node}
                data={data?.getRole}
                onclick={handleOpen}
              />
            );
          })}
        </Wrapper>
      </ContentContainer>
      <AlertPoPup
        subheading="Are you sure you want to delete"
        name={selectedData?.fullName}
        open={deleteMember}
        onclose={() => setDeleteMember(false)}
        ButtonConfig={[cancelButtonConfig, deleteButtonConfig]}
        heading="Delete member"
      />
    </MembersWrapper>
  );
};

export default Members;

const MembersWrapper = styled.div`
  margin-top: ${guttersPx.extraLarge};
`;

const AddTeamMember = ({ data }: { data: Role[] }) => {
  const [openModalMember, seModalMember] = useState(false);
  const handleOpenModalMember = () => {
    seModalMember(true);
  };
  const handleCloseModalMember = () => {
    seModalMember(false);
  };
  return (
    <div>
      <StyledLink href={""} onClick={handleOpenModalMember}>
        Add a member
      </StyledLink>
      <AddMember
        open={openModalMember}
        onClose={handleCloseModalMember}
        selectdata={data}
      />
    </div>
  );
};

const StyledLink = styled(Link)`
  color: ${darkblueColor};
  cursor: pointer;
  text-decoration: underline;
`;
const Wrapper = styled.div``;
