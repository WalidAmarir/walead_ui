import { useQueryContext } from "@/context/query/queryContext";
import { CONNECTED_ON_LINKEDIN_ACCOUNT } from "@/lib/graphql/queries/connectedOnLinkedinAccount";
import { successToast } from "@/styles/toaster";
import { useMutation } from "@apollo/client";
import React, { useState } from "react";
import AccountAction from "./AccountAction";
import UserProfile from "./UserProfile";

const Profile = () => {
  const [isAction, setAction] = useState(false);
  const [loading, setLoading] = useState(false);
  const { profileRefecth } = useQueryContext();
  const handleAction = () => {
    setAction(true);
  };
  const [onConnectAccount] = useMutation(CONNECTED_ON_LINKEDIN_ACCOUNT, {
    onCompleted: () => {
      setAction(false);
      profileRefecth();
    },
  });
  const handleConnect = async (value: boolean) => {
    setLoading(true);
    try {
      const { data } = await onConnectAccount({
        variables: {
          isConnectedOnLinkedin: value,
        },
      });
      successToast(data?.connectedOnLinkedinAccount);
    } catch (error) {
      console.error("Error while connecting account:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {isAction ? (
        <AccountAction onConnect={handleConnect} />
      ) : (
        <UserProfile
          handleAction={handleAction}
          onConnect={handleConnect}
          connectloading={loading}
        />
      )}
    </div>
  );
};

export default Profile;
