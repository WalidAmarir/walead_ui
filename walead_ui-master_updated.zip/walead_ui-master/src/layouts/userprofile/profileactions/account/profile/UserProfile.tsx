import ProfileUpload from "@/components/profile/ProfileUpload";
import { useAuth } from "@/context/auth/authContext";
import { useQueryContext } from "@/context/query/queryContext";
import { PROFILE_UPDATE } from "@/lib/graphql/mutation/profileUpdate";
import { errorToast, successToast } from "@/styles/toaster";
import { s3UploadMethod } from "@/utils/awsFileUploder";
import { getProfileAddSchema } from "@/utils/formUtils/validations/ValidationUtils";
import { useMutation } from "@apollo/client";
import { useFormik } from "formik";
import Label from "@/components/ui/input/Label";
import InputBox from "@/components/ui/input/InputBox";
import Button from "@/components/ui/button/Button";
import React from "react";
import styled from "@emotion/styled";
import {
  borderRadiusTiny,
  buttonCursor,
  darkblueColor,
  darkCharcoalColor,
  fontSizeBody1,
  greyColor,
  guttersPx,
  lightGreyColor,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import ChangePasswordFromProfile from "@/components/profile/ChangePasswordFromProfile";
import ContentContainer from "../../ContentContainer";
import {
  typographyParagraph,
  typographySubtitle2Normal,
} from "@/styles/typography";
import ConnectedAccountCard from "@/components/profile/ConnectedAccountCard";
import AddAccounts from "@/components/ui/modal/profileModals/AddAccounts";
import { getBtnState } from "@/utils/helperUtils";
import ConnectAccount from "@/components/ui/modal/profileModals/ConnectAccount";
import { SearchSuggestWithLabel } from "@/components/ui/input/SearchSuggestWithLabel";
interface User {
  fullName: string;
  mobileNumber: string;
  profilePicture: string;
  timeZone: string;
}
const UserProfile = ({
  handleAction,
  onConnect,
  connectloading,
}: {
  handleAction: () => void;
  onConnect: (arg: boolean) => void;
  connectloading: boolean;
}) => {
  const { profiledata, profileRefecth } = useQueryContext();
  const [openModal, setOpenModal] = React.useState(false);
  const [openAccount, setOpenAccount] = React.useState(false);
  const [connectAccount, setConnectAccount] = React.useState(false);
  const [hasInteractedWithUpload, setHasInteractedWithUpload] =
    React.useState(false);
  const [loginUpdate, { loading }] = useMutation(PROFILE_UPDATE, {
    onCompleted: profileRefecth,
  });
  const { authenticateUser } = useAuth();

  const { fullName, mobileNumber, email, profilePicture, timeZone } =
    profiledata?.getUserDetailsById || {};
  const [timezone, setTimezone] = React.useState(timeZone || null);

  const validationSchema = getProfileAddSchema(hasInteractedWithUpload);
  const { values, errors, handleChange, handleSubmit, setFieldValue } =
    useFormik({
      initialValues: {
        fullName: fullName,
        mobileNumber: mobileNumber,
        profilePicture: profilePicture,
        timeZone: timeZone,
      },
      validationSchema: validationSchema,
      enableReinitialize: true,
      onSubmit: async () => {
        const folderName = `profilePicture/${email}`;
        if (
          values.profilePicture &&
          typeof values.profilePicture !== "string"
        ) {
          const location: any = await s3UploadMethod(
            [values.profilePicture],
            folderName,
          );
          if (!location) {
            errorToast("Something went wrong");
            return;
          }
          values["profilePicture"] = location[0];
        }
        try {
          const arr: User = values;
          const keys: (keyof User)[] = Object.keys(values) as (keyof User)[];
          keys.forEach((key) => {
            if (values[key] === null) {
              delete values[key];
            }
          });
          const { data, errors: responseErr } = await loginUpdate({
            variables: {
              input: { ...arr, timeZone: timezone },
            },
          });
          if (data && !responseErr) {
            successToast("Data updated successfully");
            authenticateUser(data?.loginUpdate?.token);
          }
        } catch (error: any) {
          errorToast(error?.message);
        }
      },
    });
  const handleOpener = () => {
    setOpenModal(true);
  };
  const handleCloser = () => {
    setOpenModal(false);
  };
  const onCloseAccount = () => {
    setOpenAccount(false);
  };
  const onOpentAccount = () => {
    setOpenAccount(true);
  };
  const onCloseConnect = () => {
    setConnectAccount(false);
  };
  const isLinkedinConnected =
    profiledata?.getUserDetailsById?.isConnectedOnLinkedin;

  return (
    <div>
      <ContentContainer heading="Profile">
        <ProfileEditor>
          <ProfileUploadFlex>
            <ProfileUpload
              profilePicture={profilePicture}
              fullName={fullName}
              setFieldValue={(field, value) => {
                if (field === "profilePicture" && !profilePicture) {
                  setHasInteractedWithUpload(true);
                }
                setFieldValue(field, value);
              }}
              error={errors.profilePicture}
            />
          </ProfileUploadFlex>
          <form onSubmit={handleSubmit}>
            <Row>
              <Column>
                <Label labelText="Name" />
                <BreakLine></BreakLine>
                <InputBox
                  type={"text"}
                  placeholder={"Name"}
                  name={"fullName"}
                  value={values.fullName}
                  onChange={handleChange}
                  autocomplete={"off"}
                  error={errors.fullName || ""}
                  fullborder
                />
              </Column>
              <Column>
                <Label labelText="Phone" />
                <BreakLine></BreakLine>
                <InputBox
                  type={"text"}
                  placeholder={"Number"}
                  name={"mobileNumber"}
                  value={values.mobileNumber}
                  onChange={handleChange}
                  autocomplete={"off"}
                  error={errors.mobileNumber || ""}
                  fullborder
                />
              </Column>
            </Row>
            <Row>
              <Column>
                <Label labelText="Email" />
                <BreakLine></BreakLine>
                <InputBox
                  type={"email"}
                  placeholder={"Email"}
                  name={"email"}
                  value={email}
                  onChange={handleChange}
                  autocomplete={"off"}
                  readOnly
                  error={""}
                  fullborder
                />
              </Column>
              <Column>
                <Label labelText="Timezone" />
                <BreakLine></BreakLine>
                <SearchSuggestWithLabel
                  setTimezone={setTimezone}
                  timezone={timezone}
                />
              </Column>
              <Column>
                <Label labelText="Password" />
                <Uploadbutton onClick={handleOpener}>
                  Change password
                </Uploadbutton>
              </Column>
            </Row>
            {!isLinkedinConnected && (
              <Row>
                <Column>
                  <Label labelText="LinkedIn Account" />
                  <BreakLine></BreakLine>
                  <AddLinkedinText>
                    Please add your LinkedIn account
                  </AddLinkedinText>
                </Column>
                <Column>
                  <StyledAccountBtn onClick={onOpentAccount}>
                    Add account
                  </StyledAccountBtn>
                </Column>
              </Row>
            )}
            <ButtonWrapper>
              <StyledBtn type="submit">
                {getBtnState("Save changes", loading)}
              </StyledBtn>
            </ButtonWrapper>
          </form>
          {isLinkedinConnected && (
            <ConnectWrapper>
              <ConnectHeader>
                <Heading>LinkedIn Account</Heading>
                <ConnectButton onClick={onOpentAccount}>
                  + Connect account
                </ConnectButton>
              </ConnectHeader>
              <ConnectedAccountCard
                data={profiledata?.getUserDetailsById}
                onClick={handleAction}
              />{" "}
            </ConnectWrapper>
          )}
        </ProfileEditor>
      </ContentContainer>
      <ChangePasswordFromProfile
        openModal={openModal}
        handleCloser={handleCloser}
        setOpenModal={setOpenModal}
      />
      <AddAccounts
        open={openAccount}
        onClose={onCloseAccount}
        onOpenConnect={setConnectAccount}
      />
      <ConnectAccount
        open={connectAccount}
        connectloading={connectloading}
        onClose={onCloseConnect}
        onConnect={onConnect}
      />
    </div>
  );
};

export default UserProfile;

const BreakLine = styled.div``;
const ButtonWrapper = styled.div`
  display: flex;
  justify-content: end;
`;
const StyledBtn = styled(Button)`
  font-size: ${fontSizeBody1};
`;
const ProfileEditor = styled.div`
  padding-left: ${guttersPx.medium};
`;
const Row = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: streched;
  justify-content: start;
  gap: ${guttersPx.medium};
  margin-bottom: ${guttersPx.small};
`;
const Column = styled.div`
  flex: 0 0 calc(50% - ${guttersPx.medium});
`;
const ProfileUploadFlex = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
`;

const Uploadbutton = styled.label`
  display: inline-block;
  padding: 10px 20px;
  font-size: ${fontSizeBody1};
  font-weight: bold;
  color: ${whiteColor};
  background-color: ${whiteColor};
  border: none;
  border-radius: ${borderRadiusTiny};
  cursor: ${buttonCursor};
  border: 1px solid rgba(135, 135, 135, 0.5);
  color: ${darkCharcoalColor};
`;
const ConnectWrapper = styled.div``;

const ConnectHeader = styled.div`
  display: flex;
  gap: ${guttersPx.small};
  margin-bottom: ${guttersPx.small};
`;

const ConnectButton = styled.button`
  background: transparent;
  border: none !important;
  cursor: pointer;
  color: ${darkblueColor};
  ${typographyParagraph}
`;

const Heading = styled.h1`
  color: ${greyColor};
  ${typographyParagraph}
`;

const StyledAccountBtn = styled(Button)`
  background: transparent;
  color: ${darkCharcoalColor};
  border: 1px solid ${lightGreyColor};
  width: auto;
  padding: 10px 20px;
  ${typographySubtitle2Normal};
  box-shadow: none;
`;

const AddLinkedinText = styled.h1`
  color: ${lightRedColor};
  ${typographySubtitle2Normal}
`;
