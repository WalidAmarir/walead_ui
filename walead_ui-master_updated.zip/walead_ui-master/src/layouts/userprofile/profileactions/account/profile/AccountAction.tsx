import ConnectedAccountCard from "@/components/profile/ConnectedAccountCard";
import Button from "@/components/ui/button/Button";
import AlertPoPup from "@/components/ui/modal/schedulePost/AlertPoPup";
import { useQueryContext } from "@/context/query/queryContext";
import { DELETE_ALL_SCHEDULED_POST } from "@/lib/graphql/queries/deleteAllScheduledPost";
import { errorToast, successToast } from "@/styles/toaster";
import {
  typographyBody2Semibold,
  typographyParagraph,
} from "@/styles/typography";
import {
  blackColor,
  darkblueColor,
  darkCharcoalColor,
  greyColor,
  guttersPx,
  lightRedColor,
  whiteColor,
} from "@/styles/variables";
import { loinAndSignUpVariable } from "@/utils/constant";
import { useLazyQuery } from "@apollo/client";
import { css } from "@emotion/react";
import styled from "@emotion/styled";
import axios from "axios";
import React, { useState } from "react";
import { useLinkedIn } from "react-linkedin-login-oauth2";
import ContentContainer from "../../ContentContainer";

const { scope, windowObject } = loinAndSignUpVariable;

const CLIENT_ID: string = process.env.CLIENT_ID || "";
const baseUrl: string = process.env.API_BASE_URL || "";
const AccountAction = ({
  onConnect,
}: {
  onConnect: (arg: boolean) => void;
}) => {
  const { profiledata, profileRefecth } = useQueryContext();
  const [removeAccount, setRemoveAccount] = useState(false);

  const onError = (err: { message: string }) => {
    errorToast(err?.message);
  };

  const onSuccess = (message: string) => {
    successToast(message);
  };

  const [handleDelete] = useLazyQuery(DELETE_ALL_SCHEDULED_POST, {
    onCompleted: () => onSuccess("Post deleted successfully"),
    onError,
  });

  const cancelButtonConfig = {
    backgroundColor: whiteColor,
    color: darkCharcoalColor,
    outline: true,
    buttonText: "Cancel",
    onclick: () => setRemoveAccount(false),
  };

  const deleteButtonConfig = {
    backgroundColor: lightRedColor,
    color: whiteColor,
    outline: false,
    buttonText: "Remove",
    onclick: () => onConnect(false),
  };

  const { linkedInLogin } = useLinkedIn({
    clientId: CLIENT_ID,
    redirectUri: `${
      typeof window === windowObject && window.location.origin
    }/linkedin`,
    onSuccess: async (code) => {
      try {
        const { data } = await axios.post(`${baseUrl}/linkLinkedinConnection`, {
          code: code,
          userId: profiledata?.getUserDetailsById?.id,
        });
        if (data.success) {
          successToast("Successfully reauthorized");
          profileRefecth();
        }
      } catch (error: any) {
        errorToast(error?.message);
      }
    },
    onError: (err) => {
      console.log(err);
    },
    scope: scope,
  });

  return (
    <>
      <ContentContainer heading="LinkedIn Account">
        <Section>
          <ConnectedAccountCard data={profiledata?.getUserDetailsById} />
          <Wrapper>
            <ActionWrapper>
              <Content>
                <Heading>Reauthorize</Heading>
                <Description>
                  Did WaLead lose connection to this social account?
                </Description>
              </Content>
              <ButtonWrapper>
                <StyledBtn
                  bgColor={darkblueColor}
                  color={whiteColor}
                  onClick={linkedInLogin}
                >
                  Reauthorize
                </StyledBtn>
              </ButtonWrapper>
            </ActionWrapper>
            <ActionWrapper>
              <Content>
                <Heading>Delete scheduled posts</Heading>
                <Description>
                  This will delete all scheduled posts from all users for this
                  social account. This can not be undone!
                </Description>
              </Content>
              <ButtonWrapper>
                <StyledBtn
                  onClick={() => {
                    handleDelete();
                  }}
                  bgColor={lightRedColor}
                  color={whiteColor}
                >
                  Delete
                </StyledBtn>
              </ButtonWrapper>
            </ActionWrapper>
            <ActionWrapper>
              <Content>
                <Heading>Remove LinkedIn account</Heading>
                <Description>
                  This will delete from WaLead all the data related to it, such
                  as scheduled posts, and other settings.
                </Description>
              </Content>
              <ButtonWrapper>
                <StyledBtn
                  bgColor={"transparent"}
                  color={darkCharcoalColor}
                  borderColor={`1px solid ${blackColor}`}
                  onClick={() => setRemoveAccount(true)}
                >
                  Remove
                </StyledBtn>
              </ButtonWrapper>
            </ActionWrapper>
          </Wrapper>
        </Section>
      </ContentContainer>
      <AlertPoPup
        subheading="This account will be removed from WaLead, along with all the posts. This action cannot be undone. Are you sure you want to delete your LinkedIn account?"
        open={removeAccount}
        onclose={() => setRemoveAccount(true)}
        ButtonConfig={[cancelButtonConfig, deleteButtonConfig]}
        heading="Remove LinkedIn account"
      />
    </>
  );
};

export default AccountAction;

const Section = styled.div`
  padding: 0 ${guttersPx.medium};
`;

const Wrapper = styled.div`
  margin: ${guttersPx.medium} 0;
`;

const ActionWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 65px 0;
`;

const Content = styled.div`
  flex: 60%;
`;
const ButtonWrapper = styled.div`
  flex: 40%;
  display: flex;
  justify-content: end;
`;

const Heading = styled.h3`
  color: ${darkCharcoalColor};
  ${typographyParagraph};
`;

const Description = styled.p`
  color: ${greyColor};
  ${typographyParagraph};
`;

const StyledBtn = styled(Button)<{
  bgColor: string;
  color: string;
  borderColor?: string;
}>(
  ({ bgColor, color, borderColor }) => css`
    background: ${bgColor};
    color: ${color};
    ${typographyBody2Semibold};
    border-radius: 5px;
    height: 36px;
    width: 136px;
    display: grid;
    place-content: center;
    border: ${borderColor};
  `,
);
