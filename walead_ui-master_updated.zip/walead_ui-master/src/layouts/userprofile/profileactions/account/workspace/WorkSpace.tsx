import InputBox from "@/components/ui/input/InputBox";
import Label from "@/components/ui/input/Label";
import {
  InputContainer,
  InputFlex,
  InputIconWrapper,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { CopyIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import React from "react";
import ContentContainer from "../../ContentContainer";
import Members from "../profile/Members";
import { useQuery } from "@apollo/client";
import { GET_TEAMUSER_BY_COMPANY } from "@/lib/graphql/queries/getTeamUserByCompnay";
import { truncateWords } from "@/utils/helperUtils";

const WorkSpace = () => {
  const { loading, error, data, refetch } = useQuery(GET_TEAMUSER_BY_COMPANY, {
    fetchPolicy: "no-cache",
  });
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const { companyID, companyName, edges } = data?.getTeamUserByCompnay || {};

  return (
    <div>
      <ContentContainer heading="Workspace">
        <InputFlex pr="0px">
          <InputContainer>
            <Label labelText="Workspace name" />
            <InputBox
              fullborder
              readOnly
              type={"text"}
              placeholder={""}
              name={"workspace"}
              value={companyName}
              autocomplete={"off"}
              error={""}
            />
          </InputContainer>
          <InputContainer>
            <Label labelText="Workspace ID" />
            <InputIconWrapper>
              <InputBox
                fullborder
                type="text"
                placeholder=""
                name="email"
                value={truncateWords(companyID, 30)}
                autocomplete="off"
                error=""
              />
              <CopyIcon content={companyID} />
            </InputIconWrapper>
          </InputContainer>
        </InputFlex>
      </ContentContainer>
      <div>
        <Members Edges={edges} refetch={refetch} />
      </div>
    </div>
  );
};

export default WorkSpace;
