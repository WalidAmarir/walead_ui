import styled from "@emotion/styled";
import {
  whiteColor,
  lightRedColor,
  buttonCursor,
  greyColor,
  darkCharcoalColor,
  darkblueColor,
  fontSizeCaptionSmall,
  fontWeightNormal,
  fontWeightBold,
  guttersPx,
} from "@/styles/variables";
import {
  typographyParagraph,
  typographySubtitle2Normal,
  typographySubtitle2,
  typographyH4,
  typographyH2,
  typographySubtitle2Bold,
} from "@/styles/typography";
import AlertPoPup from "@/components/ui/modal/schedulePost/AlertPoPup";
import React, { useState } from "react";
import { useQueryContext } from "@/context/query/queryContext";
import Button from "@/components/ui/button/Button";
import UpdateQuantity from "@/components/ui/modal/UpdateQuantity";
import { useMutation } from "@apollo/client";
import { CHECKOUT_SESSION } from "@/lib/graphql/mutation/checkoutSession";
import { errorToast, successToast } from "@/styles/toaster";
import { UPDATE_SUBSCRIPTION } from "@/lib/graphql/mutation/updateSubscription";
import { getButtonConfig } from "@/utils/constant";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import ContentContainer from "../ContentContainer";

interface KeyPointProp {
  id: number;
  name: string;
}
interface BillingProps {
  keypoints: KeyPointProp[];
  topimage: string;
  showButton?: boolean;
}
const DeleteCancelText = styled.div`
  color: ${lightRedColor};
  text-align: center;
  font-size: ${fontSizeCaptionSmall};
  font-weight: ${fontWeightNormal};
  margin-top: ${guttersPx.extraLarge};
  cursor: ${buttonCursor};
`;

const ActivePlanWrapper = styled.div`
  color: ${greyColor};
  ${typographyParagraph};
  ${flexStyle};
  gap: ${guttersPx.smallHalf};
  margin-bottom: ${guttersPx.extraLarge};
`;

const Flex = styled.div`
  ${flexStyle};
  gap: ${guttersPx.extraLarge};
  justify-content: space-between;
  margin-top: 40px;
`;

const pricingStyles = `
  color:  ${darkblueColor};
  text-align: center;
  font-size: 45px;
  font-weight: ${fontWeightBold};
`;

const Pricing = styled.div`
  ${pricingStyles};
`;

const UpdatePlan = styled(Button)`
  ${typographySubtitle2};
  width: auto;
  margin: auto;
  display: block;
  margin-bottom: ${guttersPx.extraLarge};
  border: 1px solid ${darkblueColor};
`;

const TextAns = styled.h3`
  ${typographyH4};
  color: ${darkCharcoalColor};
`;

const PricingCard = styled.div`
  border-radius: ${guttersPx.smallHalf};
  background-color: ${whiteColor};
  box-shadow: 0px 0px 4px 2px #00000040;
  min-width: 192px;
`;
const PricingHeader = styled.div`
  background: linear-gradient(
    180deg,
    #0277b6 0%,
    rgba(54, 133, 175, 0.625) 62.72%,
    rgba(107, 179, 218, 0.25) 99.4%,
    rgba(104, 175, 213, 0) 100%
  );
  color: ${whiteColor};
  text-align: center;
  padding: ${guttersPx.medium} 0;
`;

const LeadNo = styled.h3`
  ${typographyH2}
`;

const PlanTypeDes = styled.div`
  ${typographySubtitle2Bold}
`;

const PricingWrapper = styled.div`
  text-align: center;
  padding: 35px 0;
}
`;

const PriceDes = styled.div`
  ${typographySubtitle2Normal}
`;

const Billing: React.FC<BillingProps> = () => {
  const [open, setOpen] = React.useState(false);
  const { subscriptionDetails } = useQueryContext();
  const [isUpdate, setIsUpdate] = useState(false);
  const [isUpgrade, setIsUpgrade] = useState(false);
  const [mutation, { loading }] = useMutation(
    isUpgrade ? UPDATE_SUBSCRIPTION : CHECKOUT_SESSION,
    {
      onCompleted: (data) =>
        isUpgrade
          ? handleOnUpgradeSuccess(data?.updateSubscription)
          : handleOnSuccess(data?.checkoutSession),
      onError: (err) => errorToast(err.message),
    },
  );

  const handlePlan = (qnt: number | string) => {
    mutation({
      variables: {
        input: {
          quantity: qnt.toString(),
        },
      },
    });
  };

  const handleToggleOpen = () => setOpen(!open);

  const onUpdateOpen = (upgrade: boolean) => {
    setIsUpdate(true);
    setIsUpgrade(upgrade);
  };
  const onUpdateClose = () => setIsUpdate(false);

  const handleClose = () => {
    onUpdateClose();
    setOpen(false);
  };
  const handleDelete = () => handlePlan(1);

  const cancelButtonConfig = getButtonConfig(
    whiteColor,
    darkCharcoalColor,
    true,
    "Cancel",
    handleClose,
  );
  const deleteButtonConfig = getButtonConfig(
    lightRedColor,
    whiteColor,
    false,
    "Delete",
    handleDelete,
  );

  const handleOnSuccess = (checkoutSession: string) => {
    window.open(checkoutSession, "_self");
    handleClose();
  };

  const handleOnUpgradeSuccess = (msg: string) => {
    successToast(msg);
    setIsUpgrade(false);
    handleClose();
  };

  return (
    <>
      {open && (
        <AlertPoPup
          heading="Delete your subscription"
          subheading="Are you sure you want to delete your subscription on WaLead?"
          open={open}
          onclose={() => setOpen(false)}
          ButtonConfig={[cancelButtonConfig, deleteButtonConfig]}
        />
      )}
      <ContentContainer heading="Billing">
        <ActivePlanWrapper>
          Actual CRM plan: <TextAns>FREE PLAN ✌️</TextAns>
        </ActivePlanWrapper>
        <ActivePlanWrapper>
          Download lead lists: <TextAns>20,000 leads per month</TextAns>
        </ActivePlanWrapper>
        <Flex>
          {allplanst?.map((item) => (
            <PricingCard key={item.price}>
              <PricingHeader>
                <LeadNo>{item?.noOfleads}</LeadNo>
                <PlanTypeDes>{item.planstype}</PlanTypeDes>
              </PricingHeader>
              <PricingWrapper>
                <Pricing>{item.price}</Pricing>
                <PriceDes>{item.pricetext}</PriceDes>
              </PricingWrapper>
              <UpdatePlan
                bgColor={
                  item.btnType === "filled" ? darkblueColor : "transparent"
                }
                color={item.btnType === "filled" ? whiteColor : darkblueColor}
                borderColor={darkblueColor}
                onClick={() => onUpdateOpen(true)}
              >
                {item.btntext}
              </UpdatePlan>
            </PricingCard>
          ))}
        </Flex>
        {subscriptionDetails?.isSubscription && (
          <DeleteCancelText onClick={handleToggleOpen}>
            Delete all and cancel subscription
          </DeleteCancelText>
        )}
      </ContentContainer>
      <UpdateQuantity
        loading={loading}
        dafaultqty={subscriptionDetails?.quantity}
        open={isUpdate}
        onclose={onUpdateClose}
        onSubmit={handlePlan}
      />
    </>
  );
};

export default Billing;

const allplanst = [
  {
    noOfleads: "2,000",
    planstype: "leads per month",
    price: "29€",
    pricetext: "/month /workspace",
    btntext: "Select plan",
    btnType: "filled",
  },
  {
    noOfleads: "5,000",
    planstype: "leads per month",
    price: "49€",
    pricetext: "/month /workspace",
    btntext: "Select plan",
    btnType: "filled",
  },
  {
    noOfleads: "20,000",
    planstype: "leads per month",
    price: "99€",
    pricetext: "/month /workspace",
    btntext: "Actual plan",
    btnType: "outlined",
  },
];
