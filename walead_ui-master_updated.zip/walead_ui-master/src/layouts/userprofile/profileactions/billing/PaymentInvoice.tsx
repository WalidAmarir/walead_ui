import React, { useState } from "react";
import PaymentMethod from "@/components/profile/billing/PaymentMethod";
import Invoices from "@/components/profile/billing/Invoices";
import EditBillingAddress from "@/components/ui/modal/profileModals/EditBillingAddress";
import PaymentInfo from "@/components/profile/billing/PaymentInfo";
import { useQueryContext } from "@/context/query/queryContext";

const PaymentInvoice = () => {
  const [openBillingAddress, setOpenBillingAddress] = useState(false);
  const { subscriptionDetails } = useQueryContext();
  const data = {
    companyname: "Insurgente Solutions S.L.",
    vat: "B44904290",
    address: "CALLE DEL CAMI DEL RACO, 6 - BL C 3 G",
    location: "SALOU",
    postalcode: "43840",
    province: "Tarragona",
    country: "España",
  };

  const buttonHandler = (val: string) => {
    console.log("button clicked", val);
  };

  const EditHandler = () => {
    setOpenBillingAddress(true);
  };
  const closeEditHandler = () => {
    setOpenBillingAddress(false);
  };
  return (
    <>
      <PaymentMethod buttonHandler={buttonHandler} EditHandler={EditHandler} />
      {subscriptionDetails && <PaymentInfo />}
      <Invoices />
      <EditBillingAddress
        data={data}
        open={openBillingAddress}
        onClose={closeEditHandler}
      />
    </>
  );
};

export default PaymentInvoice;
