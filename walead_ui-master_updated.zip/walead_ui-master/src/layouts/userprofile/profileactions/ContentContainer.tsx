import { HR } from "@/shared/UserMenu/SharedUserMenuComponents";
import { typographySubtitle2Normal } from "@/styles/typography";
import { guttersPx, lightSilverColor, whiteColor } from "@/styles/variables";
import styled from "@emotion/styled";
import React from "react";

const ContentContainer = ({
  heading,
  children,
  leftContent,
}: {
  heading: string;
  children: React.ReactNode;
  leftContent?: React.ReactNode;
}) => {
  return (
    <Container>
      <HeaderWrapper>
        <Heading>{heading}</Heading>
        {leftContent && <>{leftContent}</>}
      </HeaderWrapper>
      <HR color={lightSilverColor} />
      <Content>{children}</Content>
    </Container>
  );
};

export default ContentContainer;

const Container = styled.div`
  border-radius: ${guttersPx.mediumHalf};
  background: ${whiteColor};
  width: 100%;
  height: 100%;
  box-shadow: 0px 0px 4px 2px rgba(2, 119, 182, 0.5);
`;
const Heading = styled.h3`
  ${typographySubtitle2Normal};
`;
const Content = styled.div`
  padding: ${guttersPx.extraLarge} 45px;
`;

const HeaderWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${guttersPx.medium} 45px;
`;
