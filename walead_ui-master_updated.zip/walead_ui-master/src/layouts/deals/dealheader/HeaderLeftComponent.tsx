import ComboButtons from "@/components/schedulePost/ComboButtons";
import AlertPoPup from "@/components/ui/modal/schedulePost/AlertPoPup";
import SelectBox from "@/components/ui/selectBox/SelectBox";
import { useDealContext } from "@/context/deal/dealContext";
import { useQueryContext } from "@/context/query/queryContext";
import { CREATE_PIPE_LINE } from "@/lib/graphql/mutation/createPipeline";
import { UPDATE_PIPELINE } from "@/lib/graphql/mutation/updatePipeline";
import { DELETE_PIPELINE_BY_ID } from "@/lib/graphql/queries/deletePipelineById";
import { flexStyle } from "@/shared/UserMenu/SharedUserMenuComponents";
import { errorToast, successToast } from "@/styles/toaster";
import { typographySubtitle2Normal } from "@/styles/typography";
import {
  blackColor,
  darkblueColor,
  fontFamily,
  guttersPx,
  lightGreenColor,
  redColor,
  shelduckBlueColor,
  whiteColor,
} from "@/styles/variables";
import { defaultPilelineData } from "@/utils/constant";
import {
  CircularIcon,
  DeleteIcon,
  EditIcon2,
} from "@/utils/formUtils/InputSvg/InputSvg";
import {
  convertArrayToKanbanBoards,
  getAllStageNames,
  getButtonsConfigAlert,
} from "@/utils/helperUtils";
import { isBoardNamesUnique } from "@/utils/optionUtils";
import { useLazyQuery, useMutation } from "@apollo/client";
import styled from "@emotion/styled";
import { SelectChangeEvent } from "@mui/material/Select";
import React, { useState } from "react";

interface HeaderLeftComponentProp {
  handleChange: (e: SelectChangeEvent<unknown>) => void;
  values: { [key: string]: any };
  isValid: boolean;
  isAction: boolean;
  isAdd: boolean;
  handleheaderActions: (arg?: string, arg1?: boolean) => void;
  resetForm: () => void;
  setFieldValue: (arg: string, arg1: any) => void;
  handleSubmit: any;
}

const HeaderLeftComponent = ({
  handleChange,
  values,
  isValid,
  isAction,
  handleheaderActions,
  isAdd,
  setFieldValue,
  resetForm,
  handleSubmit,
}: HeaderLeftComponentProp) => {
  const [isDeletePipeLine, setIsDeletePipeLine] = useState(false);
  const { setDealListData, data, dealListData, setListName } =
    useQueryContext();
  const { refetchPipeLine, filteredPipeLines, filteredPipeLinesList } =
    useDealContext();
  const stageData = transformObjectToArray(dealListData);

  const [handleCreate] = useMutation(CREATE_PIPE_LINE, {
    variables: {
      input: {
        boardName: getAllStageNames(dealListData),
        pipelineName: values?.pipelineName,
        teamMembers: values?.memberIds,
      },
    },
    onCompleted: (response) => onSuccess(response?.createPipeline),
    onError: (err) => errorToast(err?.message),
  });

  const [onDeletePipelineByID] = useLazyQuery(DELETE_PIPELINE_BY_ID, {
    onCompleted: (deleteResponse) => {
      onSuccess(deleteResponse?.deletePipelineById);
      setIsDeletePipeLine(false);
      resetForm();
    },
    onError: (err) => errorToast(err?.message),
  });

  const [onUpdatePipelineByID] = useMutation(UPDATE_PIPELINE, {
    onCompleted: (updateResponse) => {
      onSuccess(updateResponse?.updatePipeline);
      setIsDeletePipeLine(false);
    },
    onError: (err) => errorToast(err?.message),
  });

  const onSuccess = (msg: string) => {
    successToast(msg);
    refetchPipeLine();
    handleheaderActions();
  };

  const handleEdit = (selectedOption: { value: string }) => {
    const findName = filteredPipeLines?.find(
      (item: { id: string }) => item.id === selectedOption?.value,
    );
    setFieldValue("pipelineName", findName?.pipelineName);
    handleheaderActions("isEdit", true);
  };

  const addNewPipeLine = () => {
    setDealListData(defaultPilelineData);
    setListName(defaultPilelineData);
    handleheaderActions("isAdd", true);
  };

  const onCancel = () => {
    const list = convertArrayToKanbanBoards(data?.kanbanBoard);
    setDealListData(list);
    setListName(list);
    handleheaderActions();
  };

  const handleUpdatePipeLine = async () => {
    await onUpdatePipelineByID({
      variables: {
        input: {
          pipelineId: values?.pipelineId,
          pipelineName: values?.pipelineName,
          stage: stageData,
        },
      },
    });
  };
  function handlePipeline(
    isValidProp: boolean,
    valuesProp: { pipelineName?: string },
    handlePipelineAction: () => void,
  ) {
    const isUnique = isBoardNamesUnique(stageData);
    if (!isUnique) {
      errorToast("Duplicate stage not allowed");
      return;
    }

    handleSubmit();
    if (isValidProp && valuesProp?.pipelineName?.trim() !== "") {
      handlePipelineAction();
    }
  }

  const handleCreatePipeline = () => {
    handlePipeline(isValid, values, handleCreate);
  };

  const handleEditPipeline = () => {
    handlePipeline(isValid, values, handleUpdatePipeLine);
  };

  const buttonsConfig = [
    {
      backgroundColor: "transparent",
      color: blackColor,
      outline: true,
      buttonText: "Cancel",
      onclick: onCancel,
    },
    {
      backgroundColor: darkblueColor,
      color: whiteColor,
      outline: false,
      buttonText: "Save",
      onclick: isAdd ? handleCreatePipeline : handleEditPipeline,
    },
    {
      color: whiteColor,
      Icon: <DeleteIcon />,
      outline: false,
      buttonText: "Delete",
      isHide: isAdd,
      onclick: () => setIsDeletePipeLine(true),
    },
  ];
  const onCancelDeletePipeline = () => setIsDeletePipeLine(false);
  const onDeletePipeline = () => {
    onDeletePipelineByID({
      variables: {
        deletePipelineByIdId: values?.pipelineId,
      },
    });
  };

  const buttonsConfigAlert = getButtonsConfigAlert(
    onCancelDeletePipeline,
    onDeletePipeline,
  );

  const onPipelineChange = (e: SelectChangeEvent<unknown>) => {
    setFieldValue("memberIds", []);
    handleChange(e);
  };

  return (
    <>
      <SelectWrapper>
        {isAction ? (
          <>
            <SelectBox
              width="173px"
              onChange={onPipelineChange}
              bottomComponent={<AddNewPipeLine handleAdd={addNewPipeLine} />}
              options={filteredPipeLinesList}
              onAction={handleEdit}
              actionIcon={<EditIcon2 width="15" height="15" />}
              name="pipelineId"
              value={values?.pipelineId}
            />
            <SelectBox
              name="status"
              width="173px"
              options={dealType}
              value={values?.status}
              onChange={handleChange}
              defaultVal="Status"
            />
          </>
        ) : (
          <ComboButtons buttons={buttonsConfig} />
        )}
      </SelectWrapper>
      <AlertPoPup
        heading={`Delete ${values?.pipelineName} pipeline`}
        subheading="Are you sure you want to delete this pipeline?"
        open={isDeletePipeLine}
        onclose={() => setIsDeletePipeLine(false)}
        ButtonConfig={buttonsConfigAlert}
      />
    </>
  );
};

export default HeaderLeftComponent;

const SelectWrapper = styled.div`
  ${flexStyle};
  gap: ${guttersPx.medium};
`;

const AddNewPipline = styled.button`
  background: transparent;
  border: none;
  ${typographySubtitle2Normal};
  font-family: ${fontFamily};
  margin-left: ${guttersPx.small};
  cursor: pointer;
`;

const dealType = [
  {
    label: "Status",
    value: "All",
  },
  {
    label: "Pending",
    value: "Pending",
    icon: <CircularIcon color={shelduckBlueColor} />,
  },
  {
    label: "Won",
    value: "Won",
    icon: <CircularIcon color={lightGreenColor} />,
  },
  {
    label: "Lost",
    value: "Lost",
    icon: <CircularIcon color={redColor} />,
  },
];

const AddNewPipeLine = ({ handleAdd }: { handleAdd: () => void }) => {
  return <AddNewPipline onClick={handleAdd}>New Pipeline</AddNewPipline>;
};

function transformObjectToArray(object: { [s: string]: any }) {
  const array = [];
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  for (const [_key, value] of Object.entries(object)) {
    const item: any = {
      boardName: value.name,
      id: value?.isStatic ? null : value.id,
      orderBy: (Object.keys(array).length + 1)?.toString(), // Assuming orderBy is based on array index
    };
    array.push(item);
  }
  return array;
}
