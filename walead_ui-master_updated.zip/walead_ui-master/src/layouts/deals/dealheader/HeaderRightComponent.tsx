import React, { useState } from "react";
import styled from "@emotion/styled";
import { GroupBadge } from "@/components/ui/avatar/Avatar";
import InputBox from "@/components/ui/input/InputBox";
import {
  flexStyle,
  svgStyle,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { PlusIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { AllTeamMember } from "@/types/global";
import AddTeamMember from "@/components/ui/modal/deals/AddTeamMember";
import { greyColor, guttersPx } from "@/styles/variables";
import { filterById } from "@/utils/optionUtils";
import { useQueryContext } from "@/context/query/queryContext";

interface RightHeaderContainerProps {
  isvalid?: boolean; // Define the type for the alignItems prop
}

const HeaderRightComponent = ({
  handleChange,
  budgeData,
  inputvalue,
  errors,
  isAction,
  isEdit,
  isValid,
  setFieldValue,
  resetForm,
}: {
  handleChange: any;
  budgeData: AllTeamMember[];
  inputvalue: any;
  isAction: boolean;
  isEdit: boolean;
  setFieldValue: (arg: string, arg1: any) => void;
  resetForm: () => void;
  errors: { [key: string]: string };
  isValid: boolean;
}) => {
  const [open, setOpen] = useState(false);
  const { teammembers } = useQueryContext();
  const filteredData = filterById(
    inputvalue?.memberIds,
    teammembers?.getTeamMembersByCompanyId,
  );

  if (isAction) {
    return (
      <RightHeaderContainer>
        <GroupBadge
          handleCheked={handleChange}
          name="memberIds"
          selectable
          data={budgeData}
          dimension="22"
          defaultValues={inputvalue.memberIds}
        />
      </RightHeaderContainer>
    );
  }

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  return (
    <>
      <RightHeaderContainer isvalid={isValid}>
        <div>
          <InputBox
            fullborder
            type="text"
            placeholder="Pipeline"
            name="pipelineName"
            value={inputvalue?.pipelineName}
            onChange={handleChange}
            autocomplete="off"
            error={errors?.pipelineName}
          />
        </div>
        <Assignee>
          {isEdit ? (
            <GroupBadge
              handleCheked={handleChange}
              name="teammembers"
              data={budgeData}
              dimension="22"
            />
          ) : (
            <AddAssigneeWrapper>
              <GroupBadge
                handleCheked={handleChange}
                name="teammembers"
                selectable
                data={filteredData}
                dimension="22"
              />
              <PlusIcon
                onClick={handleOpen}
                color={greyColor}
                style={svgStyle}
              />
            </AddAssigneeWrapper>
          )}
        </Assignee>
      </RightHeaderContainer>
      <AddTeamMember
        open={open}
        onClose={handleClose}
        onOpen={handleOpen}
        listData={teammembers?.getTeamMembersByCompanyId}
        setFieldValue={setFieldValue}
        resetForm={resetForm}
        defaultvalue={inputvalue?.memberIds}
      />
    </>
  );
};

export default HeaderRightComponent;

const RightHeaderContainer = styled.div<RightHeaderContainerProps>`
  ${flexStyle};
  align-items: center; /* Accessing props and setting a default value */
  gap: ${guttersPx.mediumHalf};
`;

const AddAssigneeWrapper = styled.div`
  ${flexStyle};
  align-items: center;
  gap: 5px;
`;

const Assignee = styled.div`
  margin-top: -15px !important;
`;
