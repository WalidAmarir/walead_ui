import DealModal from "@/components/deals/DealModal";
import TextArea from "@/components/ui/input/TextArea";
import SelectBox from "@/components/ui/selectBox/SelectBox";
import { useQueryContext } from "@/context/query/queryContext";
import ProfileCard from "@/layouts/userprofile/ProfileCard";
import { typographySubtitle2Normal } from "@/styles/typography";
import { blackColor, guttersPx } from "@/styles/variables";
import { lostReasons } from "@/utils/constant";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React from "react";
import { ProfileWrapper } from "./DeleteDeal";

const CrudFormContainer = styled.div`
  padding: ${guttersPx.extraLarge} 0;
`;

export const InputContainers = styled.div`
  margin-bottom: 10px;
  input,
  textarea {
    border-radius: 5px !important;
  }
`;

export const Label = styled.div(
  [typographySubtitle2Normal],
  `
   color:${blackColor};
   margin-bottom:${guttersPx.mediumHalf}
`,
);

const DealStatus = ({
  id,
  profileData,
  isOpen,
  onClose,
  modalHeading,
  secondButtonText,
  firstButtonColor,
  secondButtonColor,
  isLost = false,
  validationSchema,
  initalValue,
  status,
}: {
  id: string;
  profileData: any;
  onClose: () => void;
  isOpen: boolean;
  modalHeading: string;
  secondButtonText: string;
  firstButtonColor: string;
  secondButtonColor: string;
  isLost?: boolean;
  validationSchema: any;
  initalValue: any;
  status: string;
}) => {
  const { onDealActionSubmit } = useQueryContext();
  const { errors, values, handleChange, handleSubmit, resetForm } = useFormik({
    initialValues: initalValue,
    validationSchema: validationSchema,
    enableReinitialize: true,
    onSubmit: async (formvalues, { resetForm: reset }) => {
      await onDealActionSubmit(
        { ...formvalues, ["dealId"]: id, status: status },
        reset,
      );
    },
  });
  return (
    <div>
      <DealModal
        open={isOpen}
        close={onClose}
        handleSubmit={handleSubmit}
        resetForm={resetForm}
        modalHeadig={modalHeading}
        firstButtonText="Cancel"
        secondButtonText={secondButtonText}
        firstButtonColor={firstButtonColor}
        secondButtonColor={secondButtonColor}
      >
        <ProfileWrapper>
          <ProfileCard data={profileData} />
        </ProfileWrapper>
        <CrudFormContainer>
          {isLost && (
            <InputContainers>
              <Label>Lost reason</Label>
              <SelectBox
                name="lostReason"
                options={lostReasons}
                value={values.lostReason}
                onChange={handleChange}
              />
            </InputContainers>
          )}
          <InputContainers>
            <Label>Comments</Label>
            <TextArea
              name="comment"
              onChange={handleChange}
              value={values.comment}
              placeholder={""}
              autocomplete={""}
              error={errors?.comment || ("" as any)}
            />
          </InputContainers>
        </CrudFormContainer>
      </DealModal>
    </div>
  );
};

export default DealStatus;
