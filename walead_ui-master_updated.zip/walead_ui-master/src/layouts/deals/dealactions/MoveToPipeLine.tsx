import DealModal from "@/components/deals/DealModal";
import DealCheckBox, { LabelText } from "@/components/ui/Checkbox/DealCheckBox";
import SelectBox from "@/components/ui/selectBox/SelectBox";
import { useQueryContext } from "@/context/query/queryContext";
import ProfileCard from "@/layouts/userprofile/ProfileCard";
import { guttersPx, whiteColor, darkblueColor } from "@/styles/variables";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React, { useEffect, useState } from "react";
import { useDealContext } from "@/context/deal/dealContext";
import { UPDATE_DEAL } from "@/lib/graphql/mutation/updateDeal";
import { useMutation } from "@apollo/client";
import { errorToast, successToast } from "@/styles/toaster";
import { Label } from "./DealStatus";
import * as Yup from "yup";

const CrudFormContainer = styled.div`
  padding: ${guttersPx.extraLarge} 0;
`;

export const InputContainers = styled.div`
  margin-bottom: 10px;
  input,
  textarea {
    border-radius: 5px !important;
  }
`;

const ProfileWrapper = styled.div`
  width: auto;
  margin-top: 16px;
`;

const MoveToPipeLine = ({
  id,
  profileData,
}: {
  id: string;
  profileData: any;
}) => {
  const { dealactions, dealActionsClose, listData, dealfilterData } =
    useQueryContext();
  const { filteredPipeLinesList, filteredPipeLines } = useDealContext();
  const [label, setLabel] = useState<any>(null);

  const [handleDealupdate] = useMutation(UPDATE_DEAL, {
    onCompleted: () => {
      listData();
      successToast("Deal moved successfully");
      resetForm();
      dealActionsClose();
    },
    onError: (err) => errorToast(err?.message),
  });
  const removeCurrent = filteredPipeLinesList?.filter(
    (item: { value: any }) => item.value !== dealfilterData?.pipelineId,
  );
  const {
    values,
    errors,
    handleChange,
    handleSubmit,
    resetForm,
    setFieldValue,
  }: any = useFormik({
    initialValues: { pipelineId: removeCurrent[0]?.value, stage: [] },
    enableReinitialize: true,
    validationSchema: addstageschema,
    onSubmit: async (formvalues) => {
      await handleDealupdate({
        variables: {
          input: { stage: formvalues?.stage?.at(-1), id: id },
        },
      });
    },
  });

  const pipeline = filteredPipeLines.find(
    (item: { id: any }) => item.id === values?.pipelineId,
  );

  // Extract the stages from the pipeline object and filter out null stages
  const stages = pipeline
    ? pipeline.stage.filter((stage: null) => stage !== null)
    : [];
  const dealStage = stages.map((stage: { boardName: string; id: string }) => ({
    label: stage.boardName,
    value: stage.id,
  }));

  useEffect(() => {
    setLabel("");
    setFieldValue("stage", []);
  }, [values?.pipelineId]);
  return (
    <div>
      <DealModal
        open={dealactions?.other}
        close={dealActionsClose}
        handleSubmit={handleSubmit}
        resetForm={resetForm}
        modalHeadig="Move to other pipeline"
        firstButtonText="Cancel"
        secondButtonText="MOVE"
        firstButtonColor={whiteColor}
        secondButtonColor={darkblueColor}
        contentWidth="300px"
      >
        <ProfileWrapper>
          <ProfileCard data={profileData} />
        </ProfileWrapper>
        <CrudFormContainer>
          <InputContainers>
            <Label>Pipeline</Label>
            <SelectBox
              name="pipelineId"
              options={removeCurrent}
              value={values.pipelineId}
              onChange={handleChange}
            />
          </InputContainers>
          <InputContainers>
            <Label>Stage</Label>
            <DealCheckBox
              wrapperWidth="300px"
              error={errors?.stage || ""}
              handleChecked={handleChange}
              setFieldValue={setFieldValue}
              name="stage"
              setStageName={setLabel}
              dealStage={dealStage}
            />
            <LabelText>{label}</LabelText>
          </InputContainers>
        </CrudFormContainer>
      </DealModal>
    </div>
  );
};

export default MoveToPipeLine;

const addstageschema = Yup.object().shape({
  stage: Yup.array().min(1, "Select at least one value").required("required"),
});
