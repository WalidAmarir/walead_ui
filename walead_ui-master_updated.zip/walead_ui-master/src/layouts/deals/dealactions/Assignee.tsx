import { ErrorMessage } from "@/components/ui/input/InputBox";
import MultiSelectDropdown from "@/components/ui/input/MultiSelectDropdown";
import { useQueryContext } from "@/context/query/queryContext";
import { UPDATE_DEAL } from "@/lib/graphql/mutation/updateDeal";
import { PlusIcon } from "@/styles/base";
import { GreenTeal, guttersPx } from "@/styles/variables";
import { AllTeamMember, User } from "@/types/global";
import { CancelIcon, CheckIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import { assigneeSchema } from "@/utils/formUtils/validations/ValidationUtils";
import { mergeArrays } from "@/utils/optionUtils";
import { useMutation } from "@apollo/client";
import styled from "@emotion/styled";
import { useFormik } from "formik";
import React, { useState } from "react";

const Wrapper = styled.div`
  display: block;
  width: 100%;
`;
export const IconWrapper = styled.div`
  display: flex;
  justify-content: center;
  gap: ${guttersPx.small};
  align-items: center;
  padding-top: ${guttersPx.smallHalf};
  cursor: pointer;
`;
const AddIConWrapper = styled.div`
  display: flex;
  justify-content: end;
  width: 100%;
`;
const Assignee = ({
  handleForm,
  defaultdata,
  isNotAssigned,
  membersByPipelineId,
}: {
  handleForm: (arg1: any, arg2: boolean) => void;
  defaultdata: User[];
  isNotAssigned: boolean;
  membersByPipelineId: AllTeamMember[];
}) => {
  const { listData, dealId } = useQueryContext();
  const [isAssignee, setIsAssignee] = useState(false);

  const uniqueArray = mergeArrays(defaultdata, membersByPipelineId);
  function isIdExists(idToCheck: any) {
    return membersByPipelineId?.every((item) => item.id !== idToCheck.value);
  }
  const getOptions = uniqueArray?.map(
    (item: { fullName: string; id: string }) => ({
      label: item.fullName,
      value: item.id,
    }),
  );

  const getteamMemberId = (inputs: any[]) => {
    return inputs?.map((item) => {
      return item.value;
    });
  };

  const [handleDealupdate] = useMutation(UPDATE_DEAL, {
    onCompleted: listData,
  });

  function getAllIds(array: any[]) {
    return (
      array?.map((item: { fullName: any; id: string }) => ({
        label: item?.fullName,
        value: item?.id,
      })) ?? []
    );
  }
  const { errors, values, setFieldValue, resetForm, handleSubmit }: any =
    useFormik({
      initialValues: { teamMembers: getAllIds(defaultdata) || [] },
      validationSchema: assigneeSchema,
      enableReinitialize: true,
      onSubmit: async () => {
        const { data } = await handleDealupdate({
          variables: {
            input: {
              teamMembers: getteamMemberId(values?.teamMembers),
              id: dealId,
            },
          },
        });
        if (data?.updateDeal) {
          handleAssignee();
        }
      },
    });

  const handleAssignee = () => {
    resetForm();
    handleForm("assignee", false);
    setIsAssignee(!isAssignee);
  };
  return !isAssignee && isNotAssigned ? (
    <AddIConWrapper>
      <PlusIcon onClick={handleAssignee}>+</PlusIcon>
    </AddIConWrapper>
  ) : (
    <Wrapper>
      <MultiSelectDropdown
        options={getOptions}
        name="teamMembers"
        setFieldValue={setFieldValue}
        defaultvalue={values.teamMembers}
        disableOptions={isIdExists}
      />
      {errors?.teamMembers && (
        <ErrorMessage>{errors?.teamMembers}</ErrorMessage>
      )}
      <IconWrapper>
        <CheckIcon
          onClick={handleSubmit}
          color={GreenTeal}
          width="18"
          height="18"
        />
        <CancelIcon onClick={handleAssignee} width="18" height="18" />
      </IconWrapper>
    </Wrapper>
  );
};

export default Assignee;
