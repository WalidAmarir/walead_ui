import { AllSections } from "@/components/deals/DealList";
import Button from "@/components/ui/button/Button";
import EditableText from "@/components/ui/editor/EditableText";
import RadioButton from "@/components/ui/input/RadioButton";
import AlertPoPup from "@/components/ui/modal/schedulePost/AlertPoPup";
import CustomSelectBox from "@/components/ui/selectBox/SelectBox";
import { useQueryContext } from "@/context/query/queryContext";
import ProfileCard from "@/layouts/userprofile/ProfileCard";
import { DELETE_STAGE_BY_ID } from "@/lib/graphql/queries/deleteStageById";
import {
  flexStyle,
  svgStyle,
} from "@/shared/UserMenu/SharedUserMenuComponents";
import { scrollStyle } from "@/styles/base";
import { errorToast, successToast } from "@/styles/toaster";
import {
  typographySubtitle2,
  typographySubtitle2Normal,
} from "@/styles/typography";
import { darkblueColor, greyColor, guttersPx } from "@/styles/variables";
import { defaultNewStage } from "@/utils/constant";
import { DeleteIcon, PlusIcon } from "@/utils/formUtils/InputSvg/InputSvg";
import {
  addObjectNextToId,
  deleteObjectById,
  formatedValues,
  getButtonsConfigAlert,
} from "@/utils/helperUtils";
import { useLazyQuery } from "@apollo/client";
import styled from "@emotion/styled";
import React, { useState } from "react";
import { Draggable, Droppable } from "react-beautiful-dnd";

const DroppableDealCard = ({
  id,
  isPipelineAction,
  listId,
  title,
  item,
  index,
  lastlength,
  prices,
  onProfileOpen,
}: {
  id: string;
  isPipelineAction: boolean;
  listId: string;
  title: string;
  item: any;
  index: number;
  lastlength: number;
  prices: string;
  onProfileOpen: (arg: string) => void;
}) => {
  const {
    setDealListData,
    dealListData,
    listData,
    setState,
    setListName,
    state,
  } = useQueryContext();
  const [count, setCount] = useState(0);
  const [activeIndex, setActiveIndex] = useState(null);
  const [handleDeleteStage] = useLazyQuery(DELETE_STAGE_BY_ID, {
    onCompleted: (data) => {
      successToast(data?.deleteStageById);
      filterafterDelete();
      listData();
    },
    onError: (err) => {
      errorToast(err?.message);
    },
  });
  const [isDeleteStage, setIsDeleteStage] = useState(false);
  const onCancelDeleteStage = () => setIsDeleteStage(false);
  const onDeleteStage = () => setIsDeleteStage(false);
  const allStage = Object.keys(dealListData);
  const length = allStage?.length;
  const filterStage = allStage?.filter(
    (stageitem) =>
      dealListData[stageitem]?.id !== id && !dealListData[stageitem].isStatic,
  );
  const initialStage = dealListData[filterStage[0]]?.id; // Get the first valid stage or an empty string if filterStage is empty
  const [statusValue, setStatusValue] = useState({
    option: "move",
    stage: initialStage, // Use the initialStage value
  });

  const option = filterStage?.map((filteritem) => ({
    label: filteritem,
    value: dealListData[filteritem]?.id,
  }));

  const handleRadioChange = (event: any) => {
    const { name, value } = event.target;
    setStatusValue({ ...statusValue, [name]: value });
  };

  const filterafterDelete = () => {
    const filterArr = deleteObjectById(dealListData, id);
    setDealListData(filterArr);
  };
  const deleteStage = async () => {
    // Check if the length is less than 2, show an error message and return
    if (length <= 2) {
      return errorToast("Minimum number of stages required is 2");
    }
    // Check if there is at least one non-static stage
    const hasValidStage = allStage?.some(
      (staticitems) => dealListData[staticitems].isStatic,
    );
    const inputVar = {
      deleteStageByIdId: id,
      updateStageId: statusValue?.stage,
    };
    const { deleteStageByIdId } = inputVar;
    const finalPayload =
      statusValue?.option === "delete"
        ? { deleteStageByIdId: deleteStageByIdId }
        : inputVar;

    if (!hasValidStage) {
      await handleDeleteStage({ variables: finalPayload });
    } else {
      filterafterDelete();
    }
    // Always call onDeleteStage after processing
    onDeleteStage();
  };

  const buttonsConfigAlert = getButtonsConfigAlert(
    onCancelDeleteStage,
    deleteStage,
  );

  const addNewStage = (stageindex: number) => {
    setCount((prevCount) => prevCount + 1);
    if (length >= 14) {
      return errorToast("Pipeline length is less than equal to 14");
    }
    const updatedData = addObjectNextToId(
      dealListData,
      stageindex,
      defaultNewStage(id + count, title + count),
      title + count,
    );
    setDealListData(updatedData);
    setListName(updatedData);
  };

  const handleNameChange = (event: {
    target: { name: string; value: string };
  }) => {
    const { value } = event.target;
    const shouldUpdate = dealListData[listId]?.id === id;
    if (!shouldUpdate) return;
    const updatedValue = value.trim() === "" ? title : value;
    const updatedDealListData = {
      ...dealListData,
      [listId]: {
        ...dealListData[listId],
        name: updatedValue,
        title: updatedValue,
      },
    };
    setState((prev: any) => ({
      ...prev,
      [title]: updatedValue,
    }));
    setDealListData(updatedDealListData);
  };

  const handleMouseEnter = (currentindex: any) => {
    if (!isPipelineAction) {
      setActiveIndex(currentindex);
    }
  };

  const handleMouseLeave = () => {
    setActiveIndex(null);
  };

  return (
    <Draggable
      key={listId}
      draggableId={listId}
      index={index}
      isDragDisabled={isPipelineAction}
      // Add any additional props you need for the draggable here
    >
      {(providedDraggable, snapshot) => (
        <AllSections
          onMouseEnter={() => handleMouseEnter(index)}
          onMouseLeave={handleMouseLeave}
          length={length}
          index={index}
          lastIndex={lastlength - 1}
          key={index}
          isPipelineAction={isPipelineAction}
          iscurrentItem={activeIndex === index || snapshot.isDragging}
          ref={providedDraggable.innerRef}
          {...providedDraggable.draggableProps}
          {...providedDraggable.dragHandleProps}
        >
          <Droppable droppableId={listId} key={listId}>
            {(provided) => {
              return (
                <Item>
                  <HeadingsWrapper>
                    <EditableText
                      name={title}
                      handleNameChange={handleNameChange}
                      value={state?.[title]}
                      readOnly={isPipelineAction}
                    />
                    <SubTitle>{formatedValues(prices)}€</SubTitle>
                  </HeadingsWrapper>
                  <DealsWrapper
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                  >
                    {item?.map(
                      (
                        itemlist: {
                          id: string;
                          dealManagement_isLost: boolean;
                        },
                        listindex: number,
                      ) => {
                        return (
                          <Draggable
                            key={itemlist?.id}
                            draggableId={itemlist?.id}
                            index={listindex}
                            isDragDisabled={!isPipelineAction}
                          >
                            {(providedList) => {
                              return (
                                <ProfileWrapper
                                  ref={providedList.innerRef}
                                  {...providedList.draggableProps}
                                  {...providedList.dragHandleProps}
                                >
                                  <ProfileCard
                                    data={itemlist}
                                    onProfileOpen={onProfileOpen}
                                  />
                                </ProfileWrapper>
                              );
                            }}
                          </Draggable>
                        );
                      },
                    )}
                  </DealsWrapper>
                  {!isPipelineAction && (
                    <>
                      <StyledDeleteBtn
                        onClick={() => setIsDeleteStage(true)}
                        color={greyColor}
                        bgColor="transparent"
                      >
                        <DeleteIcon color={greyColor} /> Delete status
                      </StyledDeleteBtn>
                      <AddStageWrapper onClick={() => addNewStage(index)}>
                        <PlusIcon color={darkblueColor} />
                      </AddStageWrapper>
                    </>
                  )}
                </Item>
              );
            }}
          </Droppable>
          <AlertPoPup
            heading={`Delete ${title}`}
            component={
              <MoveStatus
                option={option}
                handleRadioChange={handleRadioChange}
                statusValue={statusValue}
              />
            }
            subheading="Before deleting this status, choose what you want to do with the opportunities:"
            open={isDeleteStage}
            onclose={onCancelDeleteStage}
            ButtonConfig={buttonsConfigAlert}
          />
        </AllSections>
      )}
    </Draggable>
  );
};

export default DroppableDealCard;

const MoveStatus = ({
  option,
  handleRadioChange,
  statusValue,
}: {
  statusValue: any;
  option: any;
  handleRadioChange: any;
}) => {
  const options = [
    {
      label: "Move to another status",
      value: "move",
      component: (
        <CustomSelectBox
          name="stage"
          options={option}
          value={statusValue?.stage}
          onChange={handleRadioChange}
        />
      ),
    },
    { label: "Delete opportunities", value: "delete" },
  ];
  return (
    <Container>
      <RadioButton
        row
        options={options}
        name="option"
        selectedOption={statusValue.option}
        onChange={handleRadioChange}
      />
    </Container>
  );
};

const HeadingsWrapper = styled.div`
  padding: 10px ${guttersPx.large};
`;

const ProfileWrapper = styled.div`
  display: flex;
  justify-content: center;
  padding: 15px 10px 0px 10px;
`;

const StyledDeleteBtn = styled(Button)`
  box-shadow: none;
  position: absolute;
  bottom: 0;
  left: 50%;
  right: 0;
  transform: translate(-50%, 0);
  width: 100%;
  ${flexStyle};
  gap: ${guttersPx.smallHalf};
  ${typographySubtitle2}
`;

const AddStageWrapper = styled.div`
  position: absolute;
  top: ${guttersPx.mediumHalf};
  right: -${guttersPx.small};
  z-index: 1000;
  ${svgStyle}
`;

const SubTitle = styled.div(
  [typographySubtitle2Normal],
  `
   color:${greyColor};
  line-height:21px
  `,
);

const DealsWrapper = styled.div`
  height: calc(100vh - 220px);
  overflow: auto;
  overflow-x: hidden;
  ${scrollStyle};
  ::-webkit-scrollbar {
    display: none !important;
  }
`;

const Item = styled.div`
  margin-bottom: 10px;
  width: 100%;
`;

const Container = styled.div`
  margin: 50px 0;
  max-width: 75%;
`;
