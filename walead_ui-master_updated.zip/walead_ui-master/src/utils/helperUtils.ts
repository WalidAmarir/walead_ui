import { IArray, Theme, UserEdge } from "@/types/global";
import dayjs from "dayjs";
import { pipe } from "fp-ts/lib/pipeable";
import { SupportedLanguages, ThemeColor } from "../types/enums";
import { IMAGE_URL_REGEXT } from "./formUtils/validations/ValidationUtils";
import moment, { MomentInput } from "moment";
import { BoardObj, PipelineData } from "@/types/user";
import { blackColor, redColor, whiteColor } from "@/styles/variables";
moment.updateLocale("en", {
  week: {
    dow: 1,
  },
});
type DateString = string | number | Date;

export const removeAt = (
  index: number,
  array: ReadonlyArray<any>,
): ReadonlyArray<any> => array.filter((_, i) => i !== index);

export const getColor = (color: ThemeColor | string, theme: Theme): string => {
  if (color === ThemeColor.Action) return theme.colors.action;
  if (color === ThemeColor.Primary) return theme.colors.primary;
  return color;
};

export const getIdFromName = (name: string | null): string => {
  if (!name) return "";

  return name
    .split(" ")
    .filter((value) => value !== "")
    .map((value, index) => {
      return index === 0
        ? value.toLowerCase()
        : value.charAt(0).toUpperCase() + value.toLowerCase().slice(1);
    })
    .join("");
};

export const isBrowser = typeof window !== `undefined`;

export const getQueryParams = () =>
  isBrowser && window.location.search
    ? pipe(
        window.location.search
          .substring(1)
          .split("&")
          .map((urlParam) => urlParam.split("=")),
      )
    : [];

export const addLeadingSlashIfNotPresent = (uri: string) =>
  uri.indexOf("/") === 0 ? uri : `/${uri}`;

export const getNumberOfDays = (seconds: number) => {
  const days = Math.floor(seconds / 86400);
  return days === 0 ? 1 : days;
};

export const closestInteger = (number: number, divider: number) => {
  const c1 = number - (number % divider);
  const sum = number + divider;
  const c2 = sum - (number % divider);

  if (number - c1 > c2 - number) {
    return c2;
  }
  return c1;
};

export const getTotalPages = (pages: number, itemsPerPage: number) =>
  Math.ceil(pages / itemsPerPage);

export const getNoLineBreakDescription = (description: string) => {
  return description.replace(/(\r\n|\n|\r)/gm, "");
};

export const getTruncationCutWithoutAnchor = ({
  content,
  truncationLength,
}: {
  content: string;
  truncationLength: number;
}) => {
  const firstTruncationVisible = content.substr(0, truncationLength);
  const firstTruncationRest = content.substr(truncationLength);
  const numberOpeningTagsInFirstCut = (
    firstTruncationVisible.match(/<a/g) || []
  ).length;
  const numberOfClosingTagsInFirstCut = (
    firstTruncationVisible.match(/<\/a>/g) || []
  ).length;
  const firstLinkEndsRest = firstTruncationRest.indexOf("</a>");
  const cutIndex =
    numberOpeningTagsInFirstCut === numberOfClosingTagsInFirstCut
      ? truncationLength
      : firstLinkEndsRest + 4 + truncationLength;

  const visibleDescription = content.substr(0, cutIndex);
  const restDescription = content.substr(cutIndex);
  return { visibleDescription, restDescription };
};

export const getUUID = (a = ""): string => {
  const crypto = window.crypto || window.Crypto;
  if (!crypto) {
    throw new Error("Crypto API not available");
  }
  const buffer = new Uint8Array(16);
  crypto.getRandomValues(buffer);
  const bits = buffer.map((x: any) => x.toString(16).padStart(2, "0")).join("");
  return a
    ? `${Number(a).toString(16)}-${bits.substr(0, 8)}-${bits.substr(
        8,
        4,
      )}-${bits.substr(12, 4)}-${bits.substr(16, 12)}`
    : `${bits.substr(0, 8)}-${bits.substr(8, 4)}-${bits.substr(
        12,
        4,
      )}-${bits.substr(16, 4)}-${bits.substr(20, 12)}`;
};

export const partition = <T>(
  array: Array<T>,
  predicate: (elemt: T) => boolean,
): [Array<T>, Array<T>] =>
  array.reduce(
    ([pass, fail], elem) => {
      return predicate(elem)
        ? [[...pass, elem], fail]
        : [pass, [...fail, elem]];
    },
    [[] as Array<T>, [] as Array<T>],
  );

export const removeDuplicates = (array: IArray, uniqueKeyIdentifier: string) =>
  array.filter(
    (currentValue: IArray, index: number, resultArray: IArray) =>
      resultArray.findIndex(
        (testValue: IArray) =>
          testValue[uniqueKeyIdentifier] === currentValue[uniqueKeyIdentifier],
      ) === index,
  );

export const getDuration = (durationInSeconds: number) => {
  const hours = Math.trunc(durationInSeconds / 3600);
  const remainingSeconds = durationInSeconds % 3600;
  const minutes = Math.trunc(remainingSeconds / 60);
  return [hours, minutes];
};

export const getHourDaysMinutesDuration = ({
  durationInSeconds,
}: {
  durationInSeconds: number;
}) => {
  const days = Math.trunc(durationInSeconds / (3600 * 24));
  const remainingSeconds = durationInSeconds % (3600 * 24);
  const [hours, minutes] = getDuration(remainingSeconds);
  return { days, hours, minutes };
};

export const getWithDefault = <T>({
  maybeValue,
  defaultValue,
}: {
  maybeValue?: T;
  defaultValue: T;
}) => maybeValue ?? defaultValue;

export const isInPreviewMode = (ssrCookie?: string) =>
  (typeof document !== "undefined" ? document.cookie : ssrCookie)?.includes(
    "preview=1",
  ) ?? false;

export const getResizeObserver = (
  callback: () => void,
): [ResizeObserver, { rafId?: number }] => {
  const mutableRequestAnimationFrameRef: { rafId?: number } = {
    rafId: undefined,
  };

  const resizeObserver = new ResizeObserver((entries) => {
    // We wrap it in requestAnimationFrame to avoid resize observer loop error
    const rafId = window.requestAnimationFrame(() => {
      if (!Array.isArray(entries) || !entries.length) return;
      callback();
    });
    if (mutableRequestAnimationFrameRef) {
      mutableRequestAnimationFrameRef.rafId = rafId;
    }
  });

  return [resizeObserver, mutableRequestAnimationFrameRef];
};

export const isTouchDevice = () =>
  isBrowser && window.matchMedia("(pointer: coarse)").matches;

export const normalizeGraphCMSLocale = (activeLocale: string) =>
  activeLocale === SupportedLanguages.Chinese
    ? SupportedLanguages.LegacyChinese
    : activeLocale;

const commonEntities = {
  lt: "<",
  gt: ">",
  sol: "/",
  quot: '"',
  apos: "'",
  amp: "&",
  copy: "©",
  reg: "®",
  deg: "°",
  laquo: "«",
  raquo: "»",
  nbsp: " ",
  trade: `™`,
  hellip: `…`,
  mdash: `—`,
  bull: `•`,
  ldquo: `“`,
  rdquo: `”`,
  lsquo: `‘`,
  rsquo: `’`,
  larr: `←`,
  rarr: `→`,
  darr: `↓`,
  uarr: `↑`,
};

export const decodeHtmlEntity = (str: string) => {
  return str
    .replace(/&#(\d+);/g, (_match: string, dec: number) => {
      return String.fromCharCode(dec);
    })
    .replace(
      new RegExp(`&(${Object.keys(commonEntities).join("|")});`, "g"),
      (_match: string, entity: keyof typeof commonEntities) => {
        return commonEntities[entity];
      },
    );
};

export const decodeHTMLTitle = (title: string | undefined) => {
  // eslint-disable-next-line prefer-regex-literals
  const specialCharRegex = new RegExp(/[#&;]/);
  if (title && specialCharRegex.test(title)) return decodeHtmlEntity(title);
  return title;
};

export const getHttpsUrl = (url?: string) =>
  url?.replace(/^http:\/\//i, "https://");

export const removeTrailingCommas = (text: string) => {
  return text.replace(/,\s*$/, "");
};

export const formatNumericValueToHumanReadable = (
  value: string | number,
): string | number => {
  return String(value).match(/^\d{5,}$/)
    ? Number(value).toLocaleString()
    : value;
};

export const decodeJwtResponse = (token: string) => {
  const base64Url = token.split(".")[1];
  const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  const jsonPayload = decodeURIComponent(
    window
      .atob(base64)
      .split("")
      .map((c) => {
        const hex = c.charCodeAt(0).toString(16);
        return "%" + (hex.length === 1 ? "0" + hex : hex);
      })
      .join(""),
  );

  return JSON.parse(jsonPayload);
};

export const isAlphabetic = (str: string) =>
  typeof str === "string" ? /^[a-zA-Z]+$/.test(str) : false;

export const isNullOrUndefined = (obj?: unknown) => obj == null;

/**
 * removeHTMLCharactersFromText only works in CSR
 */
export const removeHTMLCharactersFromText = (str?: string) => {
  if (str && isBrowser) {
    const div = document.createElement("div");
    div.innerHTML = str;
    return div.textContent || div.innerText || str;
  }
  return str;
};

export const getLastIndex = <T>(arr: T[]): number => {
  return arr.length - 1;
};
export const checkEmptydataArray = (arr: any[]) => {
  return arr?.every((item) => !item.dealdata.length);
};

export const getStages = (length: number, array: any[]) => {
  let stageName = "";
  array?.forEach((item: { id: string }, index: number) => {
    if (index === length - 1) {
      stageName = item.id;
    }
  });
  return stageName;
};

export const disablePastDates = () => {
  return new Date()?.toISOString()?.split("T")[0];
};

export const copyToClipboard = (value: string) => {
  return navigator.clipboard.writeText(value);
};
export const openToNewTab = (Taburl: string, type: string) => {
  if (!Taburl) {
    return;
  }
  const openInNewTab = (NeTaburl: string) => {
    window.open(NeTaburl, "_blank");
  };
  switch (type) {
    case "email":
      return openInNewTab(`mailto:${Taburl}`);
    case "phone":
      return openInNewTab(`tel:${Taburl}`);
    default:
      return openInNewTab(Taburl);
  }
};

export const formatDate = (dateString: DateString) => {
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, "0");
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const year = date.getFullYear().toString();
  return `${month}/${day}/${year}`;
};

export const dateHandler = (selectedOption: string) => {
  const date = new Date();
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const formattedMonth = month.toString().padStart(2, "0");
  const formattedDay = date.getDate().toString().padStart(2, "0");
  const startdate = `${formattedMonth}/${formattedDay}/${year}`;
  const lastDay = new Date(year, month - 1, 0).getDate();
  let startDateInput: string = "";
  let endDateInput: string = "";
  if (selectedOption) {
    if (selectedOption === "Current month") {
      startDateInput = `${formattedMonth}/01/${year}`;
      endDateInput = startdate;
    } else if (selectedOption === "Last month") {
      const prevMonth = (month - 1).toString().padStart(2, "0");
      startDateInput = `${prevMonth}/01/${year}`;
      endDateInput = `${prevMonth}/${lastDay}/${year}`;
    } else if (selectedOption === "Last year") {
      startDateInput = `01/01/${year - 1}`;
      endDateInput = `12/31/${year - 1}`;
    } else if (selectedOption === "Historical") {
      startDateInput = `01/01/2000`;
      endDateInput = `${dayjs(date).format("MM/DD/YYYY")}`;
    } else if (selectedOption === "Last quarter") {
      let lastQuarterStartMonth = ((month - 1) / 3) * 3;
      lastQuarterStartMonth = lastQuarterStartMonth - 2;
      const lastQuarterStartFormattedMonth = lastQuarterStartMonth
        .toString()
        .padStart(2, "0");
      const lastQuarterEndMonth = lastQuarterStartMonth + 2;
      const lastQuarterEndFormattedMonth = lastQuarterEndMonth
        .toString()
        .padStart(2, "0");
      startDateInput = `${lastQuarterStartFormattedMonth}/01/${year}`;
      endDateInput = `${lastQuarterEndFormattedMonth}/${lastDay}/${year}`;
    }
  }
  return { startDateInput, endDateInput };
};

export function isValidImageUrl(url: string) {
  const pattern = IMAGE_URL_REGEXT;
  return pattern.test(url);
}

export const keyType = {
  ENTER_KEY: "Enter",
  E_KEY: "e" || "E",
  DOT_KEY: ".",
  LEFT: 0,
  RIGHT: 2,
};

export const getSymbol = (valueType: string) => {
  if (valueType === "US Dollar (USD)") {
    return "$";
  } else if (valueType === "Euro (EUR)") {
    return "€";
  }
  return "£";
};

export const formatedValues = (value: string) => {
  const price = Number(value);
  return price ? price.toFixed(2) : value;
};

export const truncateWords = (sentence: string, amount: number) => {
  if (sentence?.length > amount) {
    return `${sentence?.slice(0, amount)}...`;
  }
  return sentence;
};

export const monthNames = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];
export const weekDayName = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];
export const timeZone = [
  "00:00",
  "01:00",
  "02:00",
  "03:00",
  "04:00",
  "05:00",
  "06:00",
  "07:00",
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
  "18:00",
  "19:00",
  "20:00",
  "21:00",
  "22:00",
  "23:00",
  "24:00",
];

export function formatDateRange(dateRange: {
  from: DateString;
  to: DateString;
}) {
  const fromDate = new Date(dateRange.from);
  const toDate = new Date(dateRange.to);
  const formattedFrom = `${fromDate.getDate()} ${
    monthNames[fromDate.getMonth()]
  } -`;
  const formattedTo = `${toDate.getDate()} ${monthNames[toDate.getMonth()]}`;
  return `${formattedFrom} ${formattedTo}`;
}

export function getDateWithMonth(date: Date) {
  if (!date) {
    return;
  }
  return `${date?.getDate()} ${monthNames[date?.getMonth()]}`;
}

export const getCurrentMonthDates = () => {
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
  const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
  const datesArray = [];
  for (
    let currentDate = firstDayOfMonth;
    currentDate <= lastDayOfMonth;
    currentDate.setDate(currentDate.getDate() + 1)
  ) {
    datesArray.push(new Date(currentDate));
  }
  return datesArray;
};

export const getPrevMonthDates = (year: number, month: number) => {
  const prevMonth = new Date(year, month - 1, 1);
  const firstDayOfMonth = new Date(prevMonth);
  const lastDayOfMonth = new Date(
    prevMonth.getFullYear(),
    prevMonth.getMonth() + 1,
    0,
  );
  const datesArray = [];
  for (
    let currentDate = firstDayOfMonth;
    currentDate <= lastDayOfMonth;
    currentDate.setDate(currentDate.getDate() + 1)
  ) {
    datesArray.push(new Date(currentDate));
  }
  return datesArray;
};
export const getSelectedMonthDates = (inputDate: string) => {
  const dateObj = new Date(inputDate);
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth() + 1; // Note: getMonth() returns 0-based month

  const selectedMonth = new Date(year, month - 1, 1);
  const firstDayOfMonth = new Date(selectedMonth);
  const lastDayOfMonth = new Date(
    selectedMonth.getFullYear(),
    selectedMonth.getMonth() + 1,
    0,
  );

  const datesArray = [];
  for (
    let currentDate = firstDayOfMonth;
    currentDate <= lastDayOfMonth;
    currentDate.setDate(currentDate.getDate() + 1)
  ) {
    datesArray.push(new Date(currentDate));
  }

  return datesArray;
};

export const getNextMonthDates = (year: number, month: number) => {
  const nextMonth = new Date(year, month + 1, 1);
  const firstDayOfMonth = new Date(nextMonth);
  const lastDayOfMonth = new Date(
    nextMonth.getFullYear(),
    nextMonth.getMonth() + 1,
    0,
  );
  const datesArray = [];
  for (
    let currentDate = firstDayOfMonth;
    currentDate <= lastDayOfMonth;
    currentDate.setDate(currentDate.getDate() + 1)
  ) {
    datesArray.push(new Date(currentDate));
  }
  return datesArray;
};
export const getCurrentWeekDates = () => {
  const startDate = moment().startOf("week");
  const endDate = moment().endOf("week");
  return {
    from: new Date(startDate.format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ (z)")),
    to: new Date(endDate.format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ (z)")),
  };
};

export function isCurrentDate(dateString: DateString) {
  const date = new Date(dateString);
  const currentDate = new Date();

  return (
    date.getFullYear() === currentDate.getFullYear() &&
    date.getMonth() === currentDate.getMonth() &&
    date.getDate() === currentDate.getDate()
  );
}

export function isFutureDate(dateString: Date) {
  const date = new Date(dateString);
  const now = new Date();
  return isCurrentDate(date) || date.getTime() > now.getTime() ? true : false;
}

export const allRoutes = [
  {
    route: "/schedulePost",
    title: "Schedule posts",
  },
  {
    route: "/leads",
    title: "Lead Finder",
  },
  {
    route: "/deals",
    title: "Deals",
  },
  {
    route: "/accelerator",
    title: "WaLead Accelerator",
  },
  {
    route: "/integrations",
    title: "Integrations",
  },
  {
    route: "/gems",
    title: "Gems",
  },
];
export function removePreviewUrl(
  arr: Array<{ file: File; previewUrl: string }>,
) {
  return arr.map((obj) => {
    const { previewUrl, ...rest } = obj;
    return rest;
  });
}

export function getDate(dateString: DateString, dateString2: DateString) {
  return formatDate(dateString) === formatDate(dateString2);
}

function findExTime(
  dateString: string | number | Date | dayjs.Dayjs | null | undefined,
) {
  return dayjs(dateString).format("HH:mm");
}

export const findTime = (exTime: string) => {
  if (!exTime) {
    return;
  }
  const getTime = findExTime(exTime);
  const time2 = getTime.split(":");
  return timeZone.find((time) => {
    const time1 = time.split(":");
    return Number(time2[0]) === Number(time1[0]);
  });
};
const hour = dayjs().hour();
const minute = dayjs().minute();
const currentTime = `${hour}:${minute}`;

export const findbeforeTime = (givenTime: string, dates: any) => {
  if (!givenTime || !isCurrentDate(dates)) {
    return true;
  }
  const time1 = givenTime.split(":");
  const time2 = currentTime.split(":");
  return Number(time2[0]) <= Number(time1[0]);
};
export const listData = (
  listArray: { fullName: string; id: string; profilePicture: string | null }[],
) => {
  if (!listArray) {
    return [];
  }
  return listArray.map(({ fullName, id, profilePicture }) => ({
    title: fullName,
    icon: profilePicture,
    id,
  }));
};

export const getBtnState = (name: string, loading: boolean) => {
  return loading ? "Loading" : name;
};

export const getSchedulePostStatus = (value: string) => {
  if (value === "draftPosttDate") {
    return "Drafts";
  } else if (value === "schedulePostDate") {
    return "Scheduled";
  } else {
    return "Posted";
  }
};

export const getFinalValue = (
  name: string,
  finalValue: {
    [x: string]: string;
    schedulePostTime: string;
    schedulePostDate: string;
  },
) => {
  if (name === "draftPosttDate") {
    const { schedulePostTime, schedulePostDate, ...rest } = finalValue;
    return rest;
  } else if (name === "schedulePostDate") {
    const { draftPosttDate, ...rest } = finalValue;
    return rest;
  } else {
    const {
      draftPosttDate,
      schedulePostDate,
      schedulePostTime,
      Posted,
      ...rest
    } = finalValue;
    return rest;
  }
};

export const getPostStatus = (data: { status: string }) => {
  const isDraft = data?.status === "Drafts";
  const isPublished = data?.status === "Posted";
  const isScheduled = data?.status === "Scheduled";
  return { isDraft, isPublished, isScheduled };
};

export function getInnerText(htmlString: any) {
  if (!htmlString) {
    return;
  }
  const parser = new DOMParser();
  const doc = parser?.parseFromString(htmlString, "text/html");
  return doc.body.innerText;
}

export const filterImgWithoutUpdate = (
  updateFile: File[] = [],
  newFile: File[] = [],
) => {
  // Check if updateFile contains valid files
  if (updateFile && updateFile.length !== 0) {
    // Return updateFile as is
    return updateFile;
  }

  // Filter out duplicate files from newFile
  const uniqueImg: File[] = [];
  newFile.forEach((img) => {
    if (
      !uniqueImg.some(
        (unique) => unique?.name === img?.name && unique?.size === img?.size,
      )
    ) {
      uniqueImg.push(img);
    }
  });

  // Convert File objects to URLs for rendering
  return uniqueImg.map((img) => {
    return typeof img !== "string" ? URL.createObjectURL(img) : img;
  });
};

export function checkLinkType(link: string) {
  const links = {
    isPdf: false,
    isYoutube: false,
    isLink: false,
  };

  // Regular expressions for checking different link types
  const pdfRegex = /\.pdf$/i;
  const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/|youtu\.be\/)/i;

  // Check if the link is a PDF link
  if (pdfRegex.test(link)) {
    links.isPdf = true;
  }

  // Check if the link is a YouTube link
  if (youtubeRegex.test(link)) {
    links.isYoutube = true;
  }

  // If it doesn't match PDF or YouTube, consider it a generic web link
  if (!links.isPdf && !links.isYoutube) {
    links.isLink = true;
  }

  return links;
}

export const handleDownload = (url: string) => {
  if (!url) {
    return;
  }
  const link = document.createElement("a");
  link.target = "_blank";
  link.download = "PDF-File";
  link.href = url;
  link.click();
};

export const handleKeyPress = (event: {
  charCode: any;
  preventDefault: () => void;
}) => {
  const charCode = event.charCode;
  if (charCode < 48 || charCode > 57) {
    event.preventDefault();
  }
};

export const extractVideoId = (url: string) => {
  if (!url) {
    return;
  }
  const match = url?.match(
    /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
  );
  return match ? match[1] : null;
};

export function getWeekBounds(weeks: {
  from: {
    getFullYear: () => number;
    getMonth: () => number;
    getDate: () => number | undefined;
  };
  to: {
    getFullYear: () => number;
    getMonth: () => number;
    getDate: () => number | undefined;
  };
}) {
  return {
    from: new Date(
      weeks.from.getFullYear(),
      weeks.from.getMonth(),
      weeks.from.getDate(),
    ),
    to: new Date(
      weeks.to.getFullYear(),
      weeks.to.getMonth(),
      weeks.to.getDate(),
    ),
  };
}

export const formatGMTDate = (
  dateValue: string | number | Date | dayjs.Dayjs,
) => {
  if (!dateValue) {
    return;
  }
  return dayjs(dateValue).format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ");
};

export function isURL(text: string) {
  const urlRegex = /^https:\/\/\S+/i;
  return urlRegex.test(text);
}

export function parseQuillContent(htmlContent: string) {
  if (!htmlContent) {
    return;
  }
  const parser = new DOMParser();
  const parsedDocument = parser.parseFromString(htmlContent, "text/html");

  const paragraphs = Array.from(parsedDocument.body.querySelectorAll("p"));
  const textArray = paragraphs.map((paragraph) => {
    const links = Array.from(paragraph.querySelectorAll("a"));
    links.forEach((link) => {
      const href = link.getAttribute("href") || "";
      const innerText = link.innerText;
      let markdownLink = "";
      if (isURL(innerText) === isURL(href)) {
        markdownLink = innerText;
      } else {
        markdownLink = `${innerText}\n${href}`;
      }
      paragraph.innerHTML = paragraph.innerHTML.replace(
        link.outerHTML,
        markdownLink,
      );
    });
    return paragraph.innerText;
  });
  return textArray.join("\n");
}

interface Fonts {
  normal: string;
  sans: string;
  sansBold: string;
  sansItalic: string;
  sansBoldItalic: string;
  [key: string]: string;
}

const fonts: Fonts = {
  normal:
    "\"\\ !#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~",
  sans: "\"\\ !#$%&'()*+,-./𝟢𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫:;<=>?@𝖠𝖡𝖢𝖣𝖤𝖥𝖦𝖧𝖨𝖩𝖪𝖫𝖬𝖭𝖮𝖯𝖰𝖱𝖲𝖳𝖴𝖵𝖶𝖷𝖸𝖹[]^_`𝖺𝖻𝖼𝖽𝖾𝖿𝗀𝗁𝗂𝗃𝗄𝗅𝗆𝗇𝗈𝗉𝗊𝗋𝗌𝗍𝗎𝗏𝗐𝗑𝗒𝗓{|}~",
  sansBold:
    "\"\\ !#$%&'()*+,-./𝟬𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵:;<=>?@𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭[]^_`𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇{|}~",
  sansItalic:
    "\"\\ !#$%&'()*+,-./0123456789:;<=>?@𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡[]^_`𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻{|}~",
  sansBoldItalic:
    "\"\\ !#$%&'()*+,-./0123456789:;<=>?@𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕[]^_`𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯{|}~",
};

const allCharacters = new Set(Object.values(fonts).join(""));

const alreadyFormatted = (text: string, font: string | number) => {
  const fontCharacters = new Set(fonts[font]);
  return Array.from(text).every(
    (char) => fontCharacters.has(char) || !allCharacters.has(char),
  );
};

const alreadyAppended = (text: string, append: unknown) => {
  return (
    Array.from(text).filter((char) => char === append).length >= text.length / 2
  );
};

export function formatText(
  text: string,
  font: string,
  options: { append?: any; remove?: any; reverse?: any; clear?: any },
) {
  if (fonts[font] && alreadyFormatted(text, font)) {
    font = "normal";
  }

  if (options?.append) {
    options.remove = options.append;
    options.append = !alreadyAppended(text, options.append)
      ? options.append
      : "";
  }

  let newText = Array.from(text);

  if (fonts[font]) {
    const targetFont = Array.from(fonts[font]);
    const charLists = Object.values(fonts);
    newText = newText.map((char) => {
      let index: any;
      const found = charLists.some((charList) => {
        index = Array.from(charList).indexOf(char);
        return index > -1;
      });
      return found ? targetFont?.[index] : char;
    });
  }
  if (options?.reverse) {
    newText.reverse();
  }
  newText = options?.remove
    ? newText.map((char) =>
        char.replace(new RegExp(options.remove + "$", "u"), ""),
      )
    : newText;
  newText = options?.append
    ? newText.map((char) => char + options.append)
    : newText;
  newText = options?.clear
    ? newText.map((char) => char.replace(/\u035f|\u0333|\u0335|\u0336/gu, ""))
    : newText;

  return newText.join("");
}

export const userData = (name: string) => {
  if (!name) {
    return;
  }
  return [
    {
      profilePicture: "/assets/icons/LinkedIn.png",
      fullName: name,
      id: 1,
    },
  ];
};

export const isBoolean = (value: any) => "boolean" === typeof value;

export const getTimeFromUnixTimeStamp = (timestamp: number) => {
  if (!timestamp) {
    return;
  }
  return moment.unix(timestamp).format("MMM DD YYYY");
};

export function sortArrayByOwner(arr: UserEdge[]) {
  const list = ["Owner", "Admin", "Editor"];
  if (!arr) {
    return;
  }
  return arr.sort(
    (a, b) => list.indexOf(a.node.role.role) - list.indexOf(b.node.role.role),
  );
}

export function formatNumberToDecimalPlaces(
  number: string | number,
  decimalPlaces = 2,
) {
  return Number(number)?.toFixed(decimalPlaces);
}

export function formatDateWithDDMMYY(
  dateString: MomentInput,
): string | undefined {
  if (!dateString) {
    return undefined;
  }

  const date = moment(dateString, "D-M-YYYY");
  return date.format("DD-MM-YYYY");
}
export const convertArrayToKanbanBoards = (arr: any[]) => {
  const kanbanBoards: Record<string, BoardObj> = {};
  arr?.forEach((board: any) => {
    const { boardName, price, dealdata, id } = board;
    const boardObj = {
      name: boardName,
      title: boardName,
      price: price,
      profiles: [],
      item: dealdata,
      id: id,
    };
    kanbanBoards[boardName] = boardObj;
  });

  return kanbanBoards;
};

export const getButtonsConfigAlert = (onCancel: any, onDelete: any) => {
  return [
    {
      backgroundColor: "transparent",
      color: blackColor,
      outline: true,
      buttonText: "Cancel",
      onclick: onCancel,
    },
    {
      backgroundColor: redColor,
      color: whiteColor,
      outline: false,
      buttonText: "Delete",
      onclick: onDelete,
    },
  ];
};

export const deleteObjectById = (data: any, idToDelete: any) => {
  const newData = { ...data };
  for (const key in newData) {
    if (newData[key].id === idToDelete) {
      delete newData[key];
      break;
    }
  }
  return newData;
};

export const addObjectNextToId = (
  data: PipelineData,
  position: number,
  newObject: PipelineData[string],
  name: string,
): PipelineData => {
  const keys = Object.keys(data);
  return keys?.reduce((acc, key, index) => {
    if (index === position) {
      acc[key] = data[key];
      const newKey = name;
      acc[newKey] = newObject;
    } else {
      acc[key] = data[key];
    }
    return acc;
  }, {} as PipelineData);
};
export function getDataFromEdgesKey(data: { edges: { node: any }[] }) {
  return data?.edges?.map(({ node }) => ({ ...node })) ?? [];
}
export function getAllStageNames(obj: any) {
  return Object.values(obj)?.map((item: any) => item?.name);
}

export function mapToPipeLineLabelValue(
  items: { pipelineName: string; id: string }[],
) {
  return items.map((item) => ({
    label: item?.pipelineName,
    value: item.id,
  }));
}

export function mapBoardDataToStage(kanbanBoard: any[]) {
  return (
    kanbanBoard?.map((stage: { boardName: string; id: string }) => ({
      label: stage.boardName,
      value: stage.id,
    })) || []
  );
}
