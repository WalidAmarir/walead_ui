import { useAuth } from "@/context/auth/authContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export interface Props {
  params: any;
  children: React.ReactNode;
}

const withPrivateRoute = (Component: React.FC<Props>) => {
  return function ProtectedRoute({ ...props }: any) {
    const router = useRouter();
    const { isLoggedIn, data, loading, refetch } = useAuth();
    const isEmpty = data?.getUserDetailsById?.dealCount === "0";

    useEffect(() => {
      const handleEmptyBoard = () => {
        if (isEmpty) {
          router.push("/deals");
        }
      };

      if (isLoggedIn && data?.getUserDetailsById) {
        handleEmptyBoard();
      }

      if (!isLoggedIn) {
        router.push("/login");
      }
    }, [data, isLoggedIn, router, isEmpty]);
    const userDetailObj = {
      profiledata: data,
      profileRefecth: refetch,
      profileLoading: loading,
      isEmptyDeal: isEmpty,
    };

    return <Component {...props} userDetails={userDetailObj} />;
  };
};

export default withPrivateRoute;
