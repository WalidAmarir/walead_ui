import { pipe } from "fp-ts/lib/pipeable";
import { Option, getOrElse } from "fp-ts/lib/Option";
import { LeadFinder } from "@/types/global";
import * as XLSX from "xlsx";

interface DealStatus {
  isWon: boolean;
  isLost: boolean;
}

export interface BoardData {
  boardName: string;
  id: string;
  orderBy: string;
}

type List = Record<string, any>; // Define the type for the list object

export const getOptionValue = (value: Option<any>, defaultValue: any): any =>
  pipe(
    value,
    getOrElse(() => defaultValue),
  );

export const popularDomains = [
  "google",
  "youtube",
  "gmail",
  "facebook",
  "baidu",
  "wikipedia",
  "yahoo",
  "amazon",
  "qq",
  "twitter",
  "live",
  "instagram",
  "sina",
  "reddit",
  "linkedin",
  "msn",
  "pinterest",
  "tumblr",
  "netflix",
  "apple",
  "microsoft",
  "hotmail",
  "outlook",
  "cloud",
  "zonnet",
  "hey",
];

export function setDefaultTeamMembersPostUpdate(
  data: { teamMembers: string | any[] },
  profiledata: { getUserDetailsById: { id: any } },
) {
  return {
    ...data,
    teamMembers:
      data?.teamMembers?.length === 0
        ? [profiledata?.getUserDetailsById?.id]
        : data?.teamMembers,
  };
}

export const getDealStatus = (profileData: any): DealStatus => {
  const isWon: boolean = profileData?.dealManagement_status === "Won";
  const isLost: boolean = profileData?.dealManagement_status === "Lost";
  return { isWon, isLost };
};

export function filterById(idArray: string | any[], dataArray: any[]) {
  return dataArray?.filter((item) => idArray?.includes(item.id));
}

export function createInitialState(list: List): List {
  return Object.keys(list).reduce((acc, key) => {
    acc[key] = key;
    return acc;
  }, {} as List);
}

export function isBoardNamesUnique(data: BoardData[]): boolean {
  const boardNames: Record<string, boolean> = {};

  for (const item of data) {
    if (boardNames[item.boardName]) {
      return false; // If a duplicate boardName is found, return false
    }
    boardNames[item.boardName] = true;
  }

  return true; // If all boardNames are unique, return true
}

export function mergeArrays(arr1: any = [], arr2: any = []) {
  // Merge arrays
  const mergedArray = [...arr1, ...arr2];

  // Filter out duplicates based on the id property
  return mergedArray.filter(
    (item, index, self) =>
      index === self.findIndex((obj) => obj.id === item.id),
  );
}

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  delay: number,
) => {
  let timeoutId: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>): void => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      func(...args);
    }, delay);
  };
};

export function hideEmailAndPhoneNumber(input: string): string {
  // Hide email
  const hiddenEmail: string = input.replace(
    /(.*)@(.*)/,
    (match: string, p1: string, p2: string) => {
      const hiddenPart: string = p1.replace(/./g, "*");
      return hiddenPart + "@" + p2;
    },
  );

  // Hide phone number
  let hiddenPhoneNumber: string;
  if (/\d{10}/.test(hiddenEmail)) {
    hiddenPhoneNumber = hiddenEmail.replace(/(\d{2})\d+(\d{2})/, "$1*******$2"); // Shows first 2 and last 2 digits
  } else {
    hiddenPhoneNumber = hiddenEmail.replace(/\d(?=\d{4})/g, "*"); // Hides all digits except last 4
  }

  return hiddenPhoneNumber;
}

export function filterDataArray(dataArr: any[]) {
  return dataArr
    ?.map((item) => ({
      id: item.key,
      value: item.values.length >= 1 ? item.values : undefined,
    }))
    ?.filter((item) => item.value !== undefined);
}

export function getFullName(item: LeadFinder) {
  return item.firstName && item.lastName
    ? `${item.firstName} ${item.lastName}`
    : item.name;
}

const mapAndFormatItem = (item: any) => {
  const fullName = getFullName(item);
  const formattedEmail = hideEmailAndPhoneNumber(item.email);
  const formattedPhoneNumber = hideEmailAndPhoneNumber(item.phoneNumber);
  return {
    ...item,
    name: fullName,
    email: formattedEmail,
    phoneNumber: formattedPhoneNumber,
  };
};

// Function to map and format an array of items
export const mapAndFormatItemsOfLeads = (items: any[]) => {
  return items.map(mapAndFormatItem) ?? [];
};

export const deleteSubOptionFilters = (
  setDataArr: (arg0: (prevDataArr: any) => any) => void,
  setSelectedItems: (arg0: (prevSelectedItems: any) => any) => void,
) => {
  return (name: any, id: any) => {
    console.log(name, id);
    setDataArr(
      (prevDataArr: any[]) =>
        prevDataArr?.map((item: { name: any }) =>
          item.name === name ? { ...item, values: [] } : item,
        ),
    );
    setSelectedItems((prevSelectedItems: any[]) =>
      prevSelectedItems?.includes(id)
        ? prevSelectedItems?.filter((item: any) => item !== id)
        : [...prevSelectedItems, id],
    );
  };
};

export const formatNumber = (number: { toString: () => string }) => {
  return number?.toString()?.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

export const exportToExcel = (data: unknown[], fileName: string) => {
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "UsersData");
  const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });

  const blob = new Blob([excelBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });

  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();

  URL.revokeObjectURL(url);
  document.body.removeChild(a);
};
